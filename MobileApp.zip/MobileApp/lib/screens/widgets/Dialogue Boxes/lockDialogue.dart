import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:myapp/screens/widgets/Encryption/note_service.dart';

import '../../HomeScreen/store_notes.dart';

Future<bool> showLockDialog(BuildContext context) async {
  bool? confirmLock = await showDialog<bool>(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text('Lock Note'),
        content: const Text('Are you sure you want to lock this note?'),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Lock'),
          ),
        ],
      );
    },
  );
  return confirmLock ?? false; // If confirmLock is null, default to false
}

Future<void> moveNoteToLocked(
    BuildContext context,
    String userId,
    String categoryName,
    QueryDocumentSnapshot doc,
    TextEditingController titleController,
    TextEditingController contentController,
    {bool homeOrNot = false,
    Function()? refreshHomeScreen}) async {
  Map<String, dynamic> noteData;
  final encryptedContent = NoteService().encrypt(contentController.text);

  allNotes.remove(doc.id);

  noteData = {
    'note_title': titleController.text,
    'note_content': encryptedContent,
    'color_id': doc['color_id'],
    'creation_date': doc['creation_date'],
    'categoryName': categoryName,
    'pin': doc['pin'],
  };

  await FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection("LockedNotes")
      .add(noteData);

  final categoryQuery = await FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection("Categories")
      .where("Name", isEqualTo: categoryName)
      .get();

  if (categoryQuery.docs.isNotEmpty) {
    final categoryDoc = categoryQuery.docs.first;
    final categoryRef = categoryDoc.reference;
    await categoryRef.collection("Notes").doc(doc.id).delete();
    Navigator.pop(context);
    if (homeOrNot) {
      refreshHomeScreen!();
    }
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Category not found'),
        backgroundColor: Colors.red, // Set background color to red
      ),
    );
    return;
  }

  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(
      content: Text('Note locked successfully'),
      backgroundColor: Colors.green, // Set background color to green
    ),
  );
}

void deleteNoteCard(BuildContext context, String docId, String userId,
    String categoryName) async {
  final categoryQuery = await FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection("Categories")
      .where("Name", isEqualTo: categoryName)
      .get();

  if (categoryQuery.docs.isNotEmpty) {
    final categoryDoc = categoryQuery.docs.first;
    final categoryRef = categoryDoc.reference;
    await categoryRef.collection("Notes").doc(docId).delete();
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Category not found'),
        backgroundColor: Colors.red, // Set background color to red
      ),
    );
    return;
  }
}
