import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:myapp/user_profiles/login.dart';

import '../../HomeScreen/store_notes.dart';

Future<void> confirmSignOutDialog(BuildContext context) async {
  return showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: const Text('Confirm Sign Out'),
      content: const Text('Are you sure you want to sign out?'),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop(); // Close the dialog
          },
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () async {
            Navigator.of(context).pop(); // Close the dialog
            try {
              await FirebaseAuth.instance.signOut();
              allNotes = {};
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const LoginPage()),
              );
            } catch (e) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Error signing out: $e'),
                ),
              );
            }
          },
          child: const Text(
            'Sign Out',
            style: TextStyle(color: Colors.red), // Set the text color to red
          ),
        ),
      ],
    ),
  );
}
