import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:crypto/crypto.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:myapp/screens/Locked%20Note/lockednotescreen.dart';


void showPasswordDialog(BuildContext context, String userId)
{
  final TextEditingController passwordController = TextEditingController();
  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  bool isGridView = true;
  final TextEditingController searchController = TextEditingController();
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return FutureBuilder<SharedPreferences>(
        future: SharedPreferences.getInstance(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final prefs = snapshot.data!;
          final userPasswordHashKey = 'notesPasswordHash_$userId';
          final savedPasswordHash = prefs.getString(userPasswordHashKey);

          // Decide whether to show 'Set Password' or 'Enter Password' dialog
          final isSettingNewPassword = savedPasswordHash == null;
          final titleText = isSettingNewPassword ? 'Set Password' : 'Enter Password';

          List<Widget> columnChildren = [
            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: const InputDecoration(
                hintText: 'Password',
              ),
            ),
          ];

          if (!isSettingNewPassword) {
            columnChildren.add(
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  child: const Text('Forgot Password?'),
                  onPressed: () async {
                    // Declare outside the showDialog to retain the state across rebuilds
                    String errorMessage = '';
                    TextEditingController accountPasswordController = TextEditingController();

                    bool? result = await showDialog<bool>(
                      context: context,
                      builder: (context) {
                        return StatefulBuilder( // Use StatefulBuilder to manage state within the dialog
                          builder: (context, setState) {
                            return AlertDialog(
                              title: const Text("Verify Account Password"),
                              content: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  TextField(
                                    controller: accountPasswordController,
                                    obscureText: true,
                                    decoration: InputDecoration(
                                      labelText: "Account Password",
                                      // Update errorText based on the current state
                                      errorText: errorMessage.isNotEmpty ? errorMessage : null,
                                    ),
                                  ),
                                ],
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.of(context).pop(false),
                                  child: const Text("Cancel"),
                                ),
                                TextButton(
                                  onPressed: () async {
                                    bool isVerified = await verifyAccountPassword(
                                      accountPasswordController.text,
                                    );
                                    if (isVerified) {
                                      Navigator.of(context).pop(true); // Use true to indicate success
                                    } else {
                                      // Use the setState from StatefulBuilder to update the dialog's state
                                      setState(() {
                                        errorMessage = 'Incorrect password. Please try again.';
                                      });
                                    }
                                  },
                                  child: const Text("Proceed"),
                                ),
                              ],
                            );
                          },
                        );
                      },
                    );

                    if (result == true) {
                      // Proceed to show the update password dialog if verification was successful
                      showUpdatePasswordDialog(context, userId);
                    }
                  },
                ),
              ),
            );
          }

          return AlertDialog(
            title: Text(titleText),
            content: SingleChildScrollView(
              child: ListBody(children: columnChildren),
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () async {
                  var enteredPassword = passwordController.text;
                  var bytes = utf8.encode(enteredPassword);
                  var digest = sha256.convert(bytes);
                  if (isSettingNewPassword) {
                    await prefs.setString(userPasswordHashKey, digest.toString());
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(builder: (context) => LockedNotesScreen(userId: userId, searchController:searchController)));
                  } else if (savedPasswordHash == digest.toString()) {
                    Navigator.pop(context);
                    Navigator.push(context, MaterialPageRoute(builder: (context) => LockedNotesScreen(userId: userId, searchController:searchController)));
                  } else {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: const Text('Error'),
                          content: const Text('Incorrect password. Please try again.'),
                          actions: <Widget>[
                            TextButton(
                              child: const Text('OK'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                          ],
                        );
                      },
                    );
                  }
                },
                child: const Text('Submit'),
              ),
            ],
          );
        },
      );
    },
  );
}
Future<void> showUpdatePasswordDialog(BuildContext context, String userId) async {
  TextEditingController newPasswordController = TextEditingController();
  bool passwordUpdated = false;
  String errorMessage = ''; // To hold the validation error message

  await showDialog(
    context: context,
    builder: (BuildContext context) {
      return StatefulBuilder( // Allows updating the dialog's content
        builder: (BuildContext context, StateSetter setState) {
          return AlertDialog(
            title: const Text("Update Password"),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: newPasswordController,
                    obscureText: true,
                    decoration: InputDecoration(
                      labelText: "New Password",
                      errorText: errorMessage.isNotEmpty ? errorMessage : null, // Display the error message if not empty
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text("Cancel"),
              ),
              TextButton(
                onPressed: () async { // Mark this callback as async
                  String newPassword = newPasswordController.text;
                  // Validate the new password
                  if (newPassword.isEmpty) {
                    setState(() => errorMessage = 'Please enter a new password');
                  } else if (newPassword.length < 6) {
                    setState(() => errorMessage = "Min 6 characters");
                  } else if (!RegExp(r'(?=.*[A-Z])').hasMatch(newPassword)) {
                    setState(() => errorMessage = "Needs uppercase");
                  } else if (!RegExp(r'(?=.*\d)').hasMatch(newPassword)) {
                    setState(() => errorMessage = "Needs a digit");
                  } else {
                    // If validation passes, proceed with updating the password
                    var bytes = utf8.encode(newPassword); // Data being hashed
                    var digest = sha256.convert(bytes);
                    final prefs = await SharedPreferences.getInstance(); // This now works with async marked
                    await prefs.setString('notesPasswordHash_$userId', digest.toString());

                    Navigator.of(context).pop(); // Close the update password dialog
                    Navigator.of(context).pop();
                    showDialog(
                      context: context,
                      barrierDismissible: false,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: const Text("Password Updated"),
                          content: const SingleChildScrollView(
                            child: ListBody(
                              children: <Widget>[
                                Text("Your password has been successfully updated."),
                              ],
                            ),
                          ),
                          actions: <Widget>[
                            TextButton(
                              child: const Text('OK'),
                              onPressed: () => Navigator.of(context).pop(), // Close confirmation dialog
                            ),
                          ],
                        );
                      },
                    );

                    passwordUpdated = true; // Indicate password was updated
                  }
                },
                child: const Text("Update"),
              ),
            ],
          );
        },
      );
    },
  );
}


Future<bool> verifyAccountPassword(String password) async {
  try {
    User user = FirebaseAuth.instance.currentUser!;
    AuthCredential credential = EmailAuthProvider.credential(email: user.email!, password: password);
    await user.reauthenticateWithCredential(credential);
    return true;
  } catch (e) {
    // print("Error verifying account password: $e");
    return false;
  }
}

