import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

Future<String> showAddCategoryDialog(
    BuildContext context, String userId) async {
  TextEditingController categoryController = TextEditingController();
  bool cancelled = false;

  await showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text('Add Category'),
        content: TextField(
          controller: categoryController,
          decoration: const InputDecoration(hintText: 'Enter Category Name'),
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              cancelled = true;
              Navigator.of(context).pop();
            },
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              String categoryName = categoryController.text.trim();
              if (categoryName.isNotEmpty) {
                _checkCategoryExistsAndAdd(context, categoryName, userId);
              } else {
                showErrorMessage(context, 'Category name cannot be empty.');
              }
            },
            child: const Text('Add'),
          ),
        ],
      );
    },
  );

  if (cancelled) {
    return '';
  }
  return categoryController.text;
}

void _checkCategoryExistsAndAdd(
    BuildContext context, String categoryName, String userId) {
  FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection('Categories')
      .get()
      .then((QuerySnapshot querySnapshot) {
    List<String> categories = querySnapshot.docs.map((doc) => doc['Name'].toString().toLowerCase()).toList().cast<String>();
    if (categories.contains(categoryName.toLowerCase())) {
      showErrorMessage(context, 'Category already exists.');
    } else {
      _addCategoryToFirebase(context, categoryName, userId);
      Navigator.of(context).pop();
    }
  }).catchError((error) {
    showErrorMessage(
        context, 'Failed to check category existence:$error\n Please try again.');
  });
}


void _addCategoryToFirebase(
    BuildContext context, String categoryName, String userId) {
  String date = DateFormat('dd/MM/yy hh:mm:ss a').format(DateTime.now());

  FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection('Categories')
      .add({
    'Name': categoryName,
    'date': date,
  }).then((value) {
    // print('Category added successfully');
  }).catchError((error) {
    // print('Failed to add category: $error');
    showErrorMessage(context, 'Failed to add category. Please try again.');
  });
}

Future<void> updateCategoryDate(String categoryName, String userId) async {
  String updatedDate = DateFormat('dd/MM/yy hh:mm:ss a').format(DateTime.now());

  try {
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection('Categories')
        .where('Name', isEqualTo: categoryName)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      String categoryId = querySnapshot.docs.first.id;

      await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection('Categories')
          .doc(categoryId)
          .update({'date': updatedDate});

      // print('Category date updated successfully');
    } else {
      // print('Category not found');
    }
  } catch (error) {
    // print('Failed to update category date: $error');
  }
}

void showErrorMessage(BuildContext context, String message) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text('OK'),
          ),
        ],
      );
    },
  );
}
