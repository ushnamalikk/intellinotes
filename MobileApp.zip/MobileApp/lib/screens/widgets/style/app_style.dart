// ignore_for_file: prefer_const_constructors, non_constant_identifier_names

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppStyle {
  static Color getMainColor(bool isDarkMode) =>
      isDarkMode ? Colors.black : Color.fromARGB(255, 242, 247, 250);
  static Color getTextColor(bool isDarkMode) =>
      isDarkMode ? Colors.white : const Color.fromARGB(255, 0, 0, 0);
  static Color getfloatingButtonBackgroundColor(bool isDarkMode) =>
      isDarkMode ? Colors.white : Color.fromARGB(255, 30, 56, 74);
  static Color getfloatingButtonColor(bool isDarkMode) =>
      isDarkMode ? Colors.black : Colors.white;
  static Color getLeftDrawerColor(bool isDarkMode) =>
      isDarkMode ? Colors.white : Colors.black;
  static Color getnoteViewStyleColor(bool isDarkMode) =>
      isDarkMode ? Colors.white : Colors.black;
  static Color getSearchBarColor(bool isDarkMode) =>
      isDarkMode ? Color(0xFF4F4F4F) : Colors.black;
  static Color getSearchBarTextColor(bool isDarkMode) =>
      isDarkMode ? Color(0xFF4F4F4F) : Colors.black;
  static Color getFocusedSearchBarColor(bool isDarkMode) =>
      isDarkMode ? Colors.white : Colors.teal.shade200;
  static Color getCategoriesNameTextColor(bool isDarkMode) =>
      isDarkMode ? Colors.white : Color.fromARGB(255, 255, 255, 255);
  static Color getSelectedCategoriesNameColor(bool isDarkMode) => isDarkMode
      ? const Color.fromARGB(255, 179, 179, 179)
      : Color.fromARGB(255, 123, 142, 144);
  static Color getNoselectedCategoriesNameColor(bool isDarkMode) => isDarkMode
      ? const Color.fromARGB(255, 0, 0, 0)
      : Color.fromARGB(255, 54, 84, 106);
  static Color getaddNote_CategoryListBoxColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 0, 0, 0)
      : Color.fromARGB(255, 54, 84, 106);
  static Color getaddNote_CategoryListButtonColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 255, 255, 255)
      : Color.fromARGB(255, 255, 255, 255);

  static Color getbottomBarColor(bool isDarkMode) => isDarkMode
      ? const Color.fromARGB(255, 0, 0, 0)
      : Color.fromARGB(255, 30, 56, 74);

  static Color getAppDrawerFirstBoxTextColor(bool isDarkMode) =>
      isDarkMode ? Color.fromARGB(255, 255, 255, 255) : Colors.black;

  static Color getAppDrawerRemBoxTextColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 255, 255, 255)
      : Color.fromARGB(255, 0, 0, 0);

  static Color getAppDrawerSecondBoxColor(bool isDarkMode) =>
      isDarkMode ? Color(0xFF1e1e1e) : Color.fromARGB(255, 209, 222, 231);

  static Color getAppDrawerThirdBoxColor(bool isDarkMode) =>
      isDarkMode ? Color(0xFF3c3c3c) : Color.fromARGB(255, 123, 147, 164);

  static Color getCategoriesBoundaryColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 255, 255, 255)
      : Color.fromARGB(220, 0, 0, 0);

  static Color getbottomBarIconSelectionIndication(bool isDarkMode) =>
      isDarkMode ? Colors.white24 : Color.fromARGB(255, 123, 147, 164);

  static Color getbottomBarIconColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 168, 168, 168)
      : Color.fromARGB(255, 168, 168, 168);

  static Color getbottomBarSelectedIconColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 255, 255, 255)
      : Color.fromARGB(255, 255, 255, 255);

  static Color getBackArroworMenuColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 255, 255, 255)
      : Color.fromARGB(220, 0, 0, 0);

  static Color getEditIconAppDrawerColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 255, 255, 255)
      : Color.fromARGB(220, 0, 0, 0);

  static Color getForgotPasswordColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 255, 255, 255)
      : Color.fromARGB(220, 0, 0, 0);

  static Color getSettingsButtonsButtonBackGroundColor(bool isDarkMode) =>
      isDarkMode
          ? Color.fromARGB(255, 255, 255, 255)
          : Color.fromARGB(255, 30, 56, 74);

  static Color getSettingsButtonsButtonTextColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 0, 0, 0)
      : Color.fromARGB(220, 255, 255, 255);

  static Color getAppDrawerBorderColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 255, 255, 255)
      : Color.fromARGB(255, 30, 56, 74);

  static Color getTandCondContainerColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 226, 226, 226)
      : Color.fromARGB(255, 30, 56, 74);

  static Color getTandCondContainerTextColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 0, 0, 0)
      : Color.fromARGB(255, 255, 255, 255);

  static Color getFocusedPasswordBoxColor(bool isDarkMode) =>
      isDarkMode ? Color.fromARGB(255, 0, 255, 229) : Colors.teal.shade200;

  static Color getPopupBarTextColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 255, 255, 255)
      : Color.fromARGB(220, 255, 255, 255);

  static Color getPopupBarColor(bool isDarkMode) => isDarkMode
      ? Color(0xFF3c3c3c)
      : Color.fromARGB(255, 30, 56, 74);

  static Color getSignOutColor(bool isDarkMode) => isDarkMode
      ? Colors.red
      : Color.fromARGB(255, 218, 15, 0);

  static Color getStartedPageBox(bool isDarkMode) => isDarkMode
      ? const Color(0xFFFFF8E1)
      : Color.fromARGB(255, 30, 56, 74);

  static Color getMainPageTextColor(bool isDarkMode) => isDarkMode
      ? Color.fromARGB(255, 0, 0, 0)
      : Color.fromARGB(255, 255, 255, 255);

  static Color rename = Colors.blue;
  static Color delete = Colors.red;

  static List<Color> cardsColor = [
    const Color(0xFF53A7F4),
    const Color(0xFFF183A1),
    const Color(0xFFE06D2D),
    const Color(0xFF53A7F4),
    const Color.fromARGB(255, 45, 224, 99),
    const Color.fromARGB(255, 158, 83, 244),
    const Color(0xFFF183C1),
    const Color(0xFFEBE4C0),
    const Color(0xFFE06D2D),
    Colors.white,
    Colors.red.shade200,
    Colors.pink.shade200,
    Colors.orange.shade200,
    Colors.yellow.shade200,
    Colors.green.shade200,
    Colors.cyan.shade200,
    Colors.deepOrange.shade200,
    Colors.deepPurple.shade200,
    Colors.blue.shade200,
    Colors.teal.shade200,
    Colors.lime.shade200,
    Colors.lightBlue.shade200,
    Colors.amber.shade200,
    Colors.indigo.shade200,
    Colors.brown.shade200,
    Colors.grey.shade200,
  ];

  static TextStyle topHeadingTextStyle(bool isDarkMode) {
    return TextStyle(
      fontSize: 32.0,
      fontFamily: GoogleFonts.poppins().fontFamily,
      color: isDarkMode
          ? Colors.white
          : Colors.black, // Color changes based on the theme
      fontWeight: FontWeight.normal,
    );
  }

  static TextStyle mainTitle =
  GoogleFonts.poppins(fontSize: 18.0, fontWeight: FontWeight.bold);
  static TextStyle mainContent =
  GoogleFonts.poppins(fontSize: 16.0, fontWeight: FontWeight.normal);
  static TextStyle dateTitle =
  GoogleFonts.poppins(fontSize: 13.0, fontWeight: FontWeight.w500);
}