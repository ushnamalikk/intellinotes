// ignore_for_file: avoid_print

import 'dart:convert';
import 'dart:typed_data';

import 'package:encrypt/encrypt.dart';

class NoteService {
  final Key key = Key.fromUtf8('3bce49372e23074764d5345d2070f306');

// This should be a securely stored key

  // Encrypt note content
  String encrypt(String plainText) {
    if (plainText == "") {
      return "";
    }
    final iv =
        IV.fromSecureRandom(16); // Generates a new IV for each encryption
    final encrypter = Encrypter(AES(key, mode: AESMode.cbc, padding: 'PKCS7'));
    final encrypted = encrypter.encrypt(plainText, iv: iv);
    // Combine IV and encrypted data for storage or transmission
    return base64.encode(iv.bytes + encrypted.bytes);
  }

  String decrypt(String encryptedBase64) {
    if (encryptedBase64 == "") {
      return "";
    }
    final combined = base64.decode(encryptedBase64);
    final iv = IV(Uint8List.fromList(
        combined.take(16).toList())); // Extracts the IV from the beginning
    final encryptedData = Encrypted(Uint8List.fromList(
        combined.skip(16).toList())); // Extracts the encrypted data
    final encrypter = Encrypter(AES(key, mode: AESMode.cbc, padding: 'PKCS7'));
    return encrypter.decrypt(encryptedData, iv: iv);
  }
}
