// ignore_for_file: deprecated_member_use, prefer_typing_uninitialized_variables, library_private_types_in_public_api, invalid_return_type_for_catch_error, avoid_print, use_build_context_synchronously

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:myapp/screens/Note/note_options.dart';
import 'package:myapp/screens/widgets/Encryption/note_service.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';

import '../HomeScreen/store_notes.dart';

class NoteDetailView extends StatefulWidget {
  final String noteTitle;
  final String noteContent;
  final String docId;
  final int colorId;
  final String userId;
  final creationDate;
  const NoteDetailView({
    Key? key,
    required this.noteTitle,
    required this.noteContent,
    required this.docId,
    required this.colorId, // Add this line
    required this.userId,
    required this.creationDate,
  }) : super(key: key);

  @override
  _NoteDetailViewState createState() => _NoteDetailViewState();
}


class _NoteDetailViewState extends State<NoteDetailView> {
  late TextEditingController _titleController;
  late TextEditingController _contentController;
  int wordCount = 0;
  Color selectedColor = const Color(0xFFEBE4C0);
  Color backgroundColor = Colors.white;
  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.noteTitle);
    _contentController = TextEditingController(text: widget.noteContent);
    backgroundColor = AppStyle.cardsColor[widget.colorId];
    updateWordCount();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  void updateWordCount() {
    setState(() {
      wordCount = _contentController.text.trim().split(' ').where((element) => element.isNotEmpty).length;
    });
  }

  @override
  Widget build(BuildContext context) {
    DateTime creationDatea = DateFormat('dd/MM/yy hh:mm:ss a').parse(widget.creationDate);
    DateTime now = DateTime.now();
    Duration difference = now.difference(creationDatea);
    String formattedDate;
    if (difference.inHours < 24) {
      formattedDate = DateFormat('hh:mm a').format(creationDatea); // Show only hours and minutes
    } else {
      formattedDate = DateFormat('dd/MM/yy hh:mm a').format(creationDatea); // Show whole date and time
    }

    return WillPopScope(
      onWillPop: () async {
        updateLockNote(widget.docId, _titleController.text, _contentController.text, widget.userId);
        int count = 0;
        Navigator.popUntil(context, (route) {
          return count++ == 1;
        });
        return false;
      },
      child: Scaffold(
        backgroundColor: backgroundColor,
        appBar: AppBar(
          backgroundColor: backgroundColor,
          elevation: 0.0,
          iconTheme: const IconThemeData(color: Colors.black),
          actions: [
            IconButton(
              icon: const Icon(Icons.lock, color: Colors.black), // Changed to Icons.lock for closed lock
              onPressed: () async {
                // Show a confirmation dialog
                bool confirmUnlock = await showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text("Unlock Note",
                          style: TextStyle(
                              fontFamily:
                              GoogleFonts.poppins().fontFamily)),
                      content: Text("Do you want to unlock this note?",
                          style: TextStyle(
                              fontFamily:
                              GoogleFonts.poppins().fontFamily)),
                      actions: <Widget>[
                        TextButton(
                          onPressed: () => Navigator.of(context)
                              .pop(false), // User cancels
                          child: Text("Cancel",
                              style: TextStyle(
                                  fontFamily:
                                  GoogleFonts.poppins().fontFamily)),
                        ),
                        TextButton(
                          onPressed: () => Navigator.of(context)
                              .pop(true), // User confirms
                          child: Text("Unlock",
                              style: TextStyle(
                                  fontFamily:
                                  GoogleFonts.poppins().fontFamily)),
                        ),
                      ],
                    );
                  },
                ) ?? false; // Handle null (dialog dismissed)

                if (confirmUnlock) {
                  // Perform the unlock operation
                  try {
                    var noteDocument = await FirebaseFirestore.instance.collection('users').doc(widget.userId).collection('LockedNotes').doc(widget.docId).get();
                    Map<String, dynamic> noteData = noteDocument.data() as Map<String, dynamic>;

                    final categoryQuery = await FirebaseFirestore.instance
                        .collection('users')
                        .doc(widget.userId)
                        .collection("Categories")
                        .where("Name", isEqualTo: noteData['categoryName'])
                        .get();

                    if (categoryQuery.docs.isNotEmpty) {
                      final categoryDoc = categoryQuery.docs.first;
                      final categoryRef = categoryDoc.reference;

                      DocumentReference newNoteRef = await categoryRef.collection("Notes").add(noteData);
                      print("Hello");
                      print(newNoteRef.id);
                      QuerySnapshot notesSnapshot = await FirebaseFirestore.instance
                          .collection('users')
                          .doc(widget.userId)
                          .collection("Categories")
                          .doc(categoryDoc.id) // Using the ID obtained from the categoryDoc
                          .collection('Notes')
                          .where(FieldPath.documentId, isEqualTo: newNoteRef.id)
                          .get();
                      QueryDocumentSnapshot note = notesSnapshot.docs.first;
                      insertNote(newNoteRef.id, note);
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text("Category not found",
                              style: TextStyle(
                                  fontFamily:
                                  GoogleFonts.poppins().fontFamily)),
                          backgroundColor:
                          Colors.red, // Set background color to red
                          duration: const Duration(
                              seconds: 2), // Set duration to 2 seconds
                        ),
                      );

                      return;
                    }

                    FirebaseFirestore.instance
                        .collection('users')
                        .doc(widget.userId)
                        .collection('LockedNotes')
                        .doc(widget.docId)
                        .delete();

                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Note unlocked and moved to Notes",
                            style: TextStyle(
                                fontFamily: GoogleFonts.poppins().fontFamily)),
                        backgroundColor:
                        Colors.green, // Set background color to red
                        duration: const Duration(
                            seconds: 2), // Set duration to 2 seconds
                      ),
                    );

                    // Navigate back to the previous screen after the operation
                    Navigator.of(context)
                        .pop(); // This line navigates back after successful unlock
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Error unlocking note",
                            style: TextStyle(
                                fontFamily: GoogleFonts.poppins().fontFamily)),
                        backgroundColor:
                        Colors.red, // Set background color to red
                        duration: const Duration(
                            seconds: 2), // Set duration to 2 seconds
                      ),
                    );

                  }
                }
              },
            ),


            IconButton(
              icon: const Icon(Icons.delete, color: Colors.black),
              onPressed: () {
                confirmDelete(context, widget.docId, widget.userId);
              },
            ),
            PopupMenuButton<Color>(
              icon: const Icon(Icons.color_lens, color: Colors.black),
              onSelected: (color) {
                setState(() {
                  selectedColor = color;
                  backgroundColor = selectedColor;
                });
                updateNoteColor(AppStyle.cardsColor.indexOf(color));
              },
              itemBuilder: (BuildContext context) {
                return [
                  PopupMenuItem<Color>(
                    child: SizedBox(
                      width: MediaQuery.of(context).size.width * 0.8, // adjust width as needed
                      child: GridView.count(
                        shrinkWrap: true,
                        crossAxisCount: 4, // Adjust the number of columns as needed
                        children: AppStyle.cardsColor.map((Color color) {
                          return GestureDetector(
                            onTap: () {
                              Navigator.pop(context, color);
                            },
                            child: Container(
                              margin: const EdgeInsets.all(4),
                              width: 30,
                              height: 24,
                              color: color,
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ];
              },
            ),

          ],
        ),
        body: Padding(
          padding: const EdgeInsets.only(left: 16, right: 16, bottom: 24, top: 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _titleController,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: 'Title',
                  hintStyle: TextStyle(
                      color: Colors.black45,
                      fontSize: 32,
                      fontFamily: GoogleFonts.poppins().fontFamily),
                ),
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    fontFamily: GoogleFonts.poppins().fontFamily),
              ),
              Row(
                children: [
                  Text(
                    formattedDate,
                    style: AppStyle.dateTitle.copyWith(
                      color: Colors.black45,
                      fontFamily: GoogleFonts.poppins().fontFamily,
                    ),
                  ),
                  const SizedBox(width: 4.0),
                  Visibility(
                    visible: wordCount > 0,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: RichText(
                        text: TextSpan(
                          style: TextStyle(
                            color: Colors.black45,
                            fontSize: 13,
                            fontFamily: GoogleFonts.poppins().fontFamily,
                          ),
                          children: [
                            TextSpan(
                              text: '|',
                              style: TextStyle(
                                fontWeight: FontWeight.bold, // Making only the "|" character bold
                              ),
                            ),
                            TextSpan(
                              text: wordCount == 1 ? '   $wordCount word' : '   $wordCount words',
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 2.0),
              Expanded(
                child: TextField(
                  controller: _contentController,
                  onChanged: (value) => updateWordCount(),
                  keyboardType: TextInputType.multiline,
                  maxLines: null,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: 'Note Content',
                    hintStyle: TextStyle(
                        color: Colors.black45,
                        fontFamily: GoogleFonts.poppins().fontFamily),
                  ),
                  style: TextStyle(
                      color: Colors.black,
                      fontFamily: GoogleFonts.poppins().fontFamily),
                ),
              ),
              // Align(
              //   alignment: Alignment.bottomRight,
              //   child: Padding(
              //     padding: const EdgeInsets.only(top: 8.0),
              //     child: Visibility(
              //       visible: wordCount > 0,
              //       child: Text(
              //         wordCount == 1 ? '$wordCount word' : '$wordCount words',
              //         style: TextStyle(
              //             color: Colors.black45,
              //             fontSize: 16,
              //             fontFamily: GoogleFonts.poppins().fontFamily),
              //       ),
              //     ),
              //   ),
              // ),
              NoteOptions(
                onParaphrase: (text) {},
                titleController: _titleController,
                contentController: _contentController,
                docId: widget.docId,
                userId: widget.userId,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void updateNoteColor(int colorId) {
    FirebaseFirestore.instance
        .collection('users').doc(widget.userId)
        .collection("LockedNotes") // Changed to LockedNotes
        .doc(widget.docId) // Use the docId from the widget.
        .update({'color_id': colorId}).then((value) {
      print("Color updated successfully in Firebase for note with docId ${widget.docId}");
      setState(() {
        // Update the local UI to reflect the color change
        selectedColor = AppStyle.cardsColor[colorId];
      });
    }).catchError((error) {
      print("Failed to update color for note with docId ${widget.docId}: $error");
    });
  }
}



void confirmDelete(BuildContext context, String docId, String userId) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text("Delete Note",
            style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
        content: Text("Are you sure you want to delete this note?",
            style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text("Cancel",
                style:
                TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
          ),
          TextButton(
            onPressed: () {
              moveNoteToDeleted(context, docId, userId);
            },
            child: Text("Delete",
                style:
                TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
          ),
          TextButton(
            onPressed: () {
              deleteNoteCard(context, docId, userId);
            },
            child: Text(
              "Delete Permanently",
              style: TextStyle(
                  color: Colors.red,
                  fontFamily: GoogleFonts.poppins()
                      .fontFamily // Set the text color to red
              ),
            ),
          ),
        ],
      );
    },
  );
}

void moveNoteToDeleted(
    BuildContext context, String docId, String userId) async {
  FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection("LockedNotes")
      .doc(docId)
      .get()
      .then((docSnapshot) {
    if (docSnapshot.exists && docSnapshot.data() != null) {
      Map<String, dynamic> data = docSnapshot.data()!;
      // Add the 'deletedAt' timestamp field to the data
      data['deletedAt'] = FieldValue.serverTimestamp();
      print(data);

      FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection("DeletedNotes")
          .doc(docId)
          .set(data)
          .then((_) {
        deleteNoteCard(context, docId, userId);
      }).catchError((error) => print("Failed to move Note: $error"));
    } else {
      print("Note does not exist or is already deleted.");
    }
  });
}

void deleteNoteCard(BuildContext context, String docId, String userId) {
  FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection("LockedNotes")
      .doc(docId)
      .delete()
      .then((value) {
    Navigator.of(context).pop();
    Navigator.of(context).pop();
  }).catchError((error) => print("Failed to delete Note: $error"));
}

void updateLockNote(
    String docId, String title, String content, String userId) {
    String encryptedContent = NoteService().encrypt(content);
  FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection("LockedNotes")
      .doc(docId)
      .update({
    "note_title": title,
    "note_content": encryptedContent,
  }).then((_) {
    print('Note updated successfully');
  }).catchError((error) {
    print("Failed to update note: $error");
  });
}
