// ignore_for_file: library_private_types_in_public_api, deprecated_member_use, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:myapp/screens/Locked%20Note/lockedNoteCard.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:myapp/screens/widgets/Encryption/note_service.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:myapp/screens/App%20Drawer/appDrawer.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/screens/HomeScreen/homeScreen.dart';
import 'package:myapp/screens/categories/categoriesList.dart';
import '../HomeScreen/store_notes.dart';
import 'package:provider/provider.dart';
import '../Note/note_options.dart';
import '../ToDoList/todolist_screen.dart';

class LockedNotesScreen extends StatefulWidget {
  final String userId;
  final TextEditingController searchController;

  const LockedNotesScreen(
      {super.key, required this.userId, required this.searchController});

  @override
  _LockedNotesScreenState createState() => _LockedNotesScreenState();
}

class _LockedNotesScreenState extends State<LockedNotesScreen> {
  bool isGridMode =
      true; // Flag to determine if the grid or list view is active
  final FocusNode _focusNode = FocusNode();
  TextEditingController searchController =
      TextEditingController(); // Focus node for the search bar

  @override
  void dispose() {
    _focusNode.dispose();
    widget.searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    return WillPopScope(
      onWillPop: () async {
        if (Navigator.of(context).canPop()) {
          Navigator.of(context).pop();
          if (Navigator.of(context).canPop()) {
            Navigator.of(context).pop();
          }
        }
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          toolbarHeight: 65.0, // Adjust the toolbar height as needed
          leading: Builder(
            builder: (context) => Padding(
              padding: const EdgeInsets.only(
                  left: 10.0), // Adjust the padding value as needed
              child: IconButton(
                icon: Icon(
                  Icons.menu,
                  color: AppStyle.getBackArroworMenuColor(isDarkMode),
                  size: 37,
                ),
                onPressed: () => Scaffold.of(context).openDrawer(),
              ),
            ),
          ),
          title: Align(
            alignment: const Alignment(-1.0,
                -0.9), // Adjust the alignment as needed for both icon and text
            child: Text(
              'Locked Notes',
              style: GoogleFonts.poppins(
                fontSize: 32.0,
                color: AppStyle.getTextColor(isDarkMode),
              ),
            ),
          ),
          backgroundColor: AppStyle.getMainColor(isDarkMode),
        ),
        drawer: appDrawer(context, widget.userId, "", lockscreen: true),
        body: Column(
          children: [
            const SizedBox(height: 20),
            Container(
              margin: const EdgeInsets.only(left: 16.0, right: 16.0),
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(50),
                border: Border.all(
                  color: searchController.text.isNotEmpty && _focusNode.hasFocus
                      ? AppStyle.getFocusedSearchBarColor(isDarkMode)
                      : AppStyle.getSearchBarColor(isDarkMode),
                  width: 2,
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 16.0),
                      child: TextField(
                        controller: searchController,
                        focusNode: _focusNode,
                        style:
                            TextStyle(color: AppStyle.getTextColor(isDarkMode)),
                        onChanged: (value) {
                          setState(() {});
                        },
                        textAlignVertical: TextAlignVertical.center,
                        decoration: InputDecoration(
                          hintText: 'Search notes',
                          hintStyle: TextStyle(
                              color: AppStyle.getSearchBarTextColor(isDarkMode),
                              fontFamily: GoogleFonts.poppins().fontFamily),
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Icon(isGridMode ? Icons.list : Icons.grid_view),
                    color: AppStyle.getnoteViewStyleColor(isDarkMode),
                    onPressed: () {
                      setState(() => isGridMode = !isGridMode);
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('users')
                    .doc(widget.userId)
                    .collection('LockedNotes')
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  }
                  if (snapshot.hasError) {
                    return Center(
                      child: Text('Error: ${snapshot.error}'),
                    );
                  }
                  if (snapshot.data == null || snapshot.data!.docs.isEmpty) {
                    return Center(
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 80.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            // Replace this with your actual logo widget
                            const Icon(Icons.article_outlined,
                                size: 90.0, color: Colors.grey),
                            Padding(
                              padding: const EdgeInsets.only(
                                  top:
                                      10.0), // Adjust the top padding as needed
                              child: Text(
                                'No Locked notes',
                                style: TextStyle(
                                  fontSize: 16.0,
                                  color: Colors
                                      .grey, // You would define this method in your AppStyle class
                                  fontFamily: GoogleFonts.poppins().fontFamily,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }
                  // Extract documents
                  List<DocumentSnapshot> allNotes = snapshot.data!.docs;
                  List<DocumentSnapshot> filteredNotes =
                      allNotes.where((noteSnapshot) {
                    final note = noteSnapshot.data() as Map<String, dynamic>;
                    final decryptedContent =
                        NoteService().decrypt(note['note_content']);
                    final title = note['note_title'] ?? '';
                    final content = decryptedContent;
                    final query = searchController.text.toLowerCase();
                    return title.toLowerCase().contains(query) ||
                        content.toLowerCase().contains(query);
                  }).toList();
                  // Sort notes based on pinned status and creation date
                  filteredNotes.sort((a, b) {
                    bool aIsPinned = a['pin'] ?? false;
                    bool bIsPinned = b['pin'] ?? false;

                    if (aIsPinned && !bIsPinned) {
                      return -1; // a comes before b
                    } else if (!aIsPinned && bIsPinned) {
                      return 1; // b comes before a
                    }

                    // If both are pinned or both are not pinned, sort by creation date
                    return b['creation_date'].compareTo(a['creation_date']);
                  });

                  // Display locked notes
                  return isGridMode
                      ? GridView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 3.0,
                            mainAxisSpacing: 3.0,
                          ),
                          itemCount: filteredNotes.length,
                          itemBuilder: (context, index) {
                            var noteSnapshot = filteredNotes[index];
                            var note = filteredNotes[index];
                            final decryptedContent =
                                NoteService().decrypt(note['note_content']);
                            String docId = noteSnapshot.id;
                            String content = decryptedContent;
                            int wordcount = content
                                .split(RegExp(r'\s+'))
                                .where((s) => s.isNotEmpty)
                                .length;

                            return NoteCardWidget(
                              title: note['note_title'],
                              content: decryptedContent,
                              docId: docId,
                              colorId: note['color_id'],
                              userId: widget.userId,
                              creationDate: note['creation_date'],
                              wordcount: wordcount,
                              isPinned: note['pin'] ?? false,
                              categoryName: note['categoryName'],
                              isGrid: isGridMode,
                            );
                          },
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          itemCount: filteredNotes.length,
                          itemBuilder: (context, index) {
                            var noteSnapshot = filteredNotes[index];
                            var note = filteredNotes[index];
                            String docId = noteSnapshot.id;
                            final decryptedContent =
                                NoteService().decrypt(note['note_content']);
                            String content = decryptedContent;
                            int wordcount = content
                                .split(RegExp(r'\s+'))
                                .where((s) => s.isNotEmpty)
                                .length;

                            return NoteCardWidget(
                              title: note['note_title'],
                              content: decryptedContent,
                              docId: docId,
                              colorId: note['color_id'],
                              userId: widget.userId,
                              creationDate: note['creation_date'],
                              wordcount: wordcount,
                              isPinned: note['pin'] ?? false,
                              categoryName: note['categoryName'],
                              isGrid: isGridMode,
                            );
                          },
                        );
                },
              ),
            ),
          ],
        ),
        backgroundColor: AppStyle.getMainColor(isDarkMode),
        bottomNavigationBar: BottomAppBar(
          color: AppStyle.getbottomBarColor(isDarkMode),
          shape: const CircularNotchedRectangle(),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              IconButton(
                icon: Icon(Icons.article_outlined,
                    size: 36,
                    color: AppStyle.getbottomBarIconColor(isDarkMode)),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => HomeScreen(
                        userId: widget.userId,
                      ),
                    ),
                  );
                },
              ),
              IconButton(
                icon: Icon(Icons.category_outlined,
                    size: 32,
                    color: AppStyle.getbottomBarIconColor(isDarkMode)),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          CategoriesList(userId: widget.userId),
                    ),
                  );
                },
              ),
              IconButton(
                icon: Icon(FontAwesomeIcons.listCheck,
                    size: 28,
                    color: AppStyle.getbottomBarIconColor(isDarkMode)),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => TaskListScreen(
                        userId: widget.userId,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NoteDetailView extends StatefulWidget {
  final String noteTitle;
  final String noteContent;
  final String docId;
  final int colorId;
  final String userId;
  final creationDate;
  const NoteDetailView({
    Key? key,
    required this.noteTitle,
    required this.noteContent,
    required this.docId,
    required this.colorId, // Add this line
    required this.userId,
    required this.creationDate,
  }) : super(key: key);

  @override
  _NoteDetailViewState createState() => _NoteDetailViewState();
}

class _NoteDetailViewState extends State<NoteDetailView> {
  late TextEditingController _titleController;
  late TextEditingController _contentController;
  int wordCount = 0;
  Color selectedColor = Color(0xFFEBE4C0);
  Color backgroundColor = Colors.white;
  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.noteTitle);
    _contentController = TextEditingController(text: widget.noteContent);
    backgroundColor = AppStyle.cardsColor[widget.colorId];
    updateWordCount();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  void updateWordCount() {
    setState(() {
      wordCount = _contentController.text
          .trim()
          .split(' ')
          .where((element) => element.isNotEmpty)
          .length;
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        updateLockNote(widget.docId, _titleController.text,
            _contentController.text, widget.userId);
        int count = 0;
        Navigator.popUntil(context, (route) {
          return count++ == 1;
        });
        return false;
      },
      child: Scaffold(
        backgroundColor: backgroundColor,
        appBar: AppBar(
          backgroundColor: backgroundColor,
          elevation: 0.0,
          iconTheme: const IconThemeData(color: Colors.black),
          actions: [
            IconButton(
              icon: Icon(Icons.lock,
                  color: Colors.black), // Changed to Icons.lock for closed lock
              onPressed: () async {
                // Show a confirmation dialog
                bool confirmUnlock = await showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: Text("Unlock Note",
                              style: TextStyle(
                                  fontFamily:
                                      GoogleFonts.poppins().fontFamily)),
                          content: Text("Do you want to unlock this note?",
                              style: TextStyle(
                                  fontFamily:
                                      GoogleFonts.poppins().fontFamily)),
                          actions: <Widget>[
                            TextButton(
                              onPressed: () => Navigator.of(context)
                                  .pop(false), // User cancels
                              child: Text("Cancel",
                                  style: TextStyle(
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily)),
                            ),
                            TextButton(
                              onPressed: () => Navigator.of(context)
                                  .pop(true), // User confirms
                              child: Text("Unlock",
                                  style: TextStyle(
                                      fontFamily:
                                          GoogleFonts.poppins().fontFamily)),
                            ),
                          ],
                        );
                      },
                    ) ??
                    false; // Handle null (dialog dismissed)

                if (confirmUnlock) {
                  // Perform the unlock operation
                  try {
                    var noteDocument = await FirebaseFirestore.instance
                        .collection('users')
                        .doc(widget.userId)
                        .collection('LockedNotes')
                        .doc(widget.docId)
                        .get();
                    Map<String, dynamic> noteData =
                        noteDocument.data() as Map<String, dynamic>;

                    final categoryQuery = await FirebaseFirestore.instance
                        .collection('users')
                        .doc(widget.userId)
                        .collection("Categories")
                        .where("Name", isEqualTo: noteData['categoryName'])
                        .get();

                    if (categoryQuery.docs.isNotEmpty) {
                      final categoryDoc = categoryQuery.docs.first;
                      final categoryRef = categoryDoc.reference;

                      DocumentReference newNoteRef =
                          await categoryRef.collection("Notes").add(noteData);
                      QuerySnapshot notesSnapshot = await FirebaseFirestore
                          .instance
                          .collection('users')
                          .doc(widget.userId)
                          .collection("Categories")
                          .doc(categoryDoc
                              .id) // Using the ID obtained from the categoryDoc
                          .collection('Notes')
                          .where(FieldPath.documentId, isEqualTo: newNoteRef.id)
                          .get();
                      QueryDocumentSnapshot note = notesSnapshot.docs.first;
                      insertNote(newNoteRef.id, note);
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text("Category not found",
                              style: TextStyle(
                                  fontFamily:
                                      GoogleFonts.poppins().fontFamily)),
                          backgroundColor:
                              Colors.red, // Set background color to red
                          duration: const Duration(
                              seconds: 2), // Set duration to 2 seconds
                        ),
                      );

                      return;
                    }

                    FirebaseFirestore.instance
                        .collection('users')
                        .doc(widget.userId)
                        .collection('LockedNotes')
                        .doc(widget.docId)
                        .delete();

                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Note unlocked and moved to Notes",
                            style: TextStyle(
                                fontFamily: GoogleFonts.poppins().fontFamily)),
                        backgroundColor:
                            Colors.green, // Set background color to red
                        duration: const Duration(
                            seconds: 2), // Set duration to 2 seconds
                      ),
                    );

                    // Navigate back to the previous screen after the operation
                    Navigator.of(context)
                        .pop(); // This line navigates back after successful unlock
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Error unlocking note",
                            style: TextStyle(
                                fontFamily: GoogleFonts.poppins().fontFamily)),
                        backgroundColor:
                            Colors.red, // Set background color to red
                        duration: const Duration(
                            seconds: 2), // Set duration to 2 seconds
                      ),
                    );
                  }
                }
              },
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.black),
              onPressed: () {
                confirmDelete(context, widget.docId, widget.userId);
              },
            ),
            PopupMenuButton<Color>(
              icon: const Icon(Icons.color_lens, color: Colors.black),
              onSelected: (color) {
                print("ASd");
                print(selectedColor);
                print(widget.colorId);
                setState(() {
                  selectedColor = color;
                  backgroundColor = selectedColor;
                });
                updateNoteColor(AppStyle.cardsColor.indexOf(color));
              },
              itemBuilder: (BuildContext context) {
                return [
                  PopupMenuItem<Color>(
                    child: SizedBox(
                      width: MediaQuery.of(context).size.width *
                          0.8, // adjust width as needed
                      child: GridView.count(
                        shrinkWrap: true,
                        crossAxisCount:
                            4, // Adjust the number of columns as needed
                        children: AppStyle.cardsColor.map((Color color) {
                          return GestureDetector(
                            onTap: () {
                              Navigator.pop(context, color);
                            },
                            child: Container(
                              margin: EdgeInsets.all(4),
                              width: 30,
                              height: 24,
                              color: color,
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ];
              },
            ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _titleController,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: 'Title',
                  hintStyle: TextStyle(
                      color: Colors.black45,
                      fontSize: 32,
                      fontFamily: GoogleFonts.poppins().fontFamily),
                ),
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    fontFamily: GoogleFonts.poppins().fontFamily),
              ),
              const SizedBox(
                height: 8.0,
              ),
              Text(
                widget.creationDate,
                style: AppStyle.dateTitle.copyWith(color: Colors.black45),
              ),
              const SizedBox(height: 8.0),
              Expanded(
                child: TextField(
                  controller: _contentController,
                  onChanged: (value) => updateWordCount(),
                  keyboardType: TextInputType.multiline,
                  maxLines: null,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: 'Note Content',
                    hintStyle: TextStyle(
                        color: Colors.black45,
                        fontFamily: GoogleFonts.poppins().fontFamily),
                  ),
                  style: TextStyle(
                      color: Colors.black,
                      fontFamily: GoogleFonts.poppins().fontFamily),
                ),
              ),
              Align(
                alignment: Alignment.bottomRight,
                child: Padding(
                  padding: const EdgeInsets.only(top: 8.0),
                  child: Visibility(
                    visible: wordCount > 0,
                    child: Text(
                      wordCount == 1 ? '$wordCount word' : '$wordCount words',
                      style: TextStyle(
                          color: Colors.black45,
                          fontSize: 16,
                          fontFamily: GoogleFonts.poppins().fontFamily),
                    ),
                  ),
                ),
              ),
              NoteOptions(
                onParaphrase: (text) {},
                titleController: _titleController,
                contentController: _contentController,
                docId: widget.docId,
                userId: widget.userId,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void updateNoteColor(int colorId) {
    FirebaseFirestore.instance
        .collection('users')
        .doc(widget.userId)
        .collection("LockedNotes") // Changed to LockedNotes
        .doc(widget.docId) // Use the docId from the widget.
        .update({'color_id': colorId}).then((value) {
      print(
          "Color updated successfully in Firebase for note with docId ${widget.docId}");
      setState(() {
        // Update the local UI to reflect the color change
        selectedColor = AppStyle.cardsColor[colorId] ?? Colors.white;
      });
    }).catchError((error) {
      print(
          "Failed to update color for note with docId ${widget.docId}: $error");
    });
  }
}

void confirmDelete(BuildContext context, String docId, String userId) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text("Delete Note",
            style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
        content: Text("Are you sure you want to delete this note?",
            style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text("Cancel",
                style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
          ),
          TextButton(
            onPressed: () {
              moveNoteToDeleted(context, docId, userId);
            },
            child: Text("Delete",
                style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
          ),
          TextButton(
            onPressed: () {
              deleteNoteCard(context, docId, userId);
            },
            child: Text(
              "Delete Permanently",
              style: TextStyle(
                  color: Colors.red,
                  fontFamily: GoogleFonts.poppins()
                      .fontFamily // Set the text color to red
                  ),
            ),
          ),
        ],
      );
    },
  );
}

void moveNoteToDeleted(
    BuildContext context, String docId, String userId) async {
  FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection("LockedNotes")
      .doc(docId)
      .get()
      .then((docSnapshot) {
    if (docSnapshot.exists && docSnapshot.data() != null) {
      Map<String, dynamic> data = docSnapshot.data()!;
      // Add the 'deletedAt' timestamp field to the data
      data['deletedAt'] = FieldValue.serverTimestamp();
      print(data);

      FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection("DeletedNotes")
          .doc(docId)
          .set(data)
          .then((_) {
        deleteNoteCard(context, docId, userId);
      }).catchError((error) => print("Failed to move Note: $error"));
    } else {
      print("Note does not exist or is already deleted.");
    }
  });
}

void deleteNoteCard(BuildContext context, String docId, String userId) {
  FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection("LockedNotes")
      .doc(docId)
      .delete()
      .then((value) {
    Navigator.of(context).pop();
    Navigator.of(context).pop();
  }).catchError((error) => print("Failed to delete Note: $error"));
}

void updateLockNote(String docId, String title, String content, String userId) {
  FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection("LockedNotes")
      .doc(docId)
      .update({
    "note_title": title,
    "note_content": content,
  }).then((_) {
    print('Note updated successfully');
  }).catchError((error) {
    print("Failed to update note: $error");
  });
}
