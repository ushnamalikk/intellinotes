// ignore_for_file: invalid_return_type_for_catch_error, avoid_print, use_build_context_synchronously, prefer_typing_uninitialized_variables

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:myapp/screens/Locked%20Note/NoteDetailView.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:myapp/screens/widgets/Encryption/note_service.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:provider/provider.dart';

import '../HomeScreen/store_notes.dart';

class NoteCardWidget extends StatelessWidget {
  final String title;
  final String content;
  final String docId;
  final int colorId;
  final String userId;
  final creationDate;
  final int wordcount;
  final bool isPinned;
  final String categoryName;
  final bool isGrid;

  const NoteCardWidget({
    required this.title,
    required this.content,
    required this.docId,
    required this.colorId,
    required this.userId,
    required this.creationDate,
    required this.wordcount,
    required this.isPinned,
    required this.categoryName,
    required this.isGrid,
    Key? key,
  }) : super(key: key);

  Future<void> unlockNote(BuildContext context, String userId, String docId) async {
    bool confirmUnlock = await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Unlock Note"),
          content: const Text("Do you want to unlock this note?"),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(false), // User cancels
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true), // User confirms
              child: const Text("Unlock"),
            ),
          ],
        );
      },
    ) ?? false; // Handle null (dialog dismissed)

    if (confirmUnlock) {
      // Perform the unlock operation
      try {
        var noteDocument = await FirebaseFirestore.instance.collection('users').doc(userId).collection('LockedNotes').doc(docId).get();
        Map<String, dynamic> noteData = noteDocument.data() as Map<String, dynamic>;

        final categoryQuery = await FirebaseFirestore.instance
            .collection('users')
            .doc(userId)
            .collection("Categories")
            .where("Name", isEqualTo: noteData['categoryName'])
            .get();

        if (categoryQuery.docs.isNotEmpty) {
          final categoryDoc = categoryQuery.docs.first;
          final categoryRef = categoryDoc.reference;
          DocumentReference newNoteRef = await categoryRef.collection("Notes").add(noteData);
          print("Hello");
          print(newNoteRef.id);
          QuerySnapshot notesSnapshot = await FirebaseFirestore.instance
              .collection('users')
              .doc(userId)
              .collection("Categories")
              .doc(categoryDoc.id) // Using the ID obtained from the categoryDoc
              .collection('Notes')
              .where(FieldPath.documentId, isEqualTo: newNoteRef.id)
              .get();
          QueryDocumentSnapshot note = notesSnapshot.docs.first;
          insertNote(newNoteRef.id, note);
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Category not found'),
              backgroundColor: Colors.red, // Set background color to red
              duration: Duration(seconds: 2), // Set duration to 2 seconds
            ),
          );
          return;
        }

        await FirebaseFirestore.instance
            .collection('users')
            .doc(userId)
            .collection('LockedNotes')
            .doc(docId)
            .delete();

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Note unlocked and moved to Notes"),
            backgroundColor: Colors.green, // Set background color to red
            duration: Duration(seconds: 2), // Set duration to 2 seconds
          ),
        );


        // Navigate back to the previous screen after the operation
        Navigator.of(context).pop(); // This line navigates back after successful unlock
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Error unlocking note"),
            backgroundColor: Colors.red, // Set background color to red
            duration: Duration(seconds: 2), // Set duration to 2 seconds
          ),
        );

      }
    }
  }

  Future<void> togglePin(
      BuildContext context, String userId, String docId, bool isPinned) async {
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection('LockedNotes')
          .doc(docId)
          .update({'pin': !isPinned});
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Note unlocked and moved to Notes",
            style: TextStyle(
              fontFamily: GoogleFonts.poppins().fontFamily,
            ),
          ),
          backgroundColor: Colors.green,
          duration: const Duration(seconds: 2),
        ),
      );

      Navigator.of(context).pop();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Error unlocking note",
            style: TextStyle(
              fontFamily: GoogleFonts.poppins().fontFamily,
            ),
          ),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;

    String titleToShow = title;
    if (titleToShow.isEmpty) {
      // Use content's first line as title if the title is empty
      List<String> contentLines = content.split('\n');
      if (contentLines.isNotEmpty) {
        titleToShow = contentLines.first;
      }
    }

    DateTime creationDate2 = DateFormat('dd/MM/yy hh:mm:ss a').parse(creationDate);

    DateTime currentDate = DateTime.now();
    String formattedDate;

    if (currentDate.difference(creationDate2).inHours < 24) {
      // Within 24 hours, display in hours and minutes
      formattedDate = DateFormat('h:mm a').format(creationDate2);
    } else {
      // Older than 24 hours, display in full date and time
      formattedDate = DateFormat('dd/MM/yy h:mm a').format(creationDate2);
    }


    return InkWell(
      onTap: () {
        Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => NoteDetailView(noteTitle: title, noteContent: content, docId: docId, colorId: colorId, userId: userId, creationDate:creationDate),
        ));
      },
      child: GestureDetector(
        onLongPress: () {
          showModalBottomSheet(
            context: context,
            builder: (BuildContext context) {
              return Container(
                height: 75,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  color: AppStyle.getPopupBarColor(isDarkMode),
                  borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(0)), // No rounding on top
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    IconButton(
                      icon: Icon(
                        Icons.lock_open,
                        color: AppStyle.getPopupBarTextColor(isDarkMode),
                        size: 25.5,
                      ),
                      onPressed: () => unlockNote(context, userId, docId),
                    ),
                    IconButton(
                      icon: Icon(
                        Icons.delete,
                        color: AppStyle.getPopupBarTextColor(isDarkMode),
                        size: 27,
                      ),
                      onPressed: () => confirmDelete(context, docId, userId),
                    ),
                    IconButton(
                      icon: isPinned
                          ? Icon(
                        Icons.push_pin_outlined,
                        color: AppStyle.getPopupBarTextColor(isDarkMode),
                        size: 27,
                      )
                          : Icon(
                        Icons.push_pin,
                        color: AppStyle.getPopupBarTextColor(isDarkMode),
                        size: 27,
                      ),
                      onPressed: () =>
                          togglePin(context, userId, docId, isPinned),
                    ),
                  ],
                ),
              );
            },
          );
        },
        child: Card(
          color: AppStyle.cardsColor[colorId],
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            titleToShow,
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 19,
                              fontWeight: FontWeight.w600,
                              fontFamily: GoogleFonts.poppins().fontFamily,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (isPinned) ...[
                          Transform.rotate(
                            angle: 40 * 3.1415926535 / 180,
                            child: const Icon(
                              Icons.push_pin,
                              color: Colors.black,
                              size: 16,
                            ),
                          ),
                          const SizedBox(width: 4),
                        ],
                      ],
                    ),
                    const SizedBox(height: 6.0,),
                    Row(
                      children: [
                        Icon(
                          Icons.folder_open_rounded,
                          color: Colors.black.withOpacity(0.6),
                          size: 16,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          categoryName,
                          style: AppStyle.mainTitle.copyWith(
                            color: Colors.black.withOpacity(0.6),
                            fontSize: 12,
                            fontFamily: GoogleFonts.poppins()
                                .fontFamily, // Specify the fontFamily
                          ),
                          maxLines: 1,
                        ),
                      ],
                    ),
                    Text(
                      formattedDate,
                      style: TextStyle(
                        color: Colors.black.withOpacity(0.6),
                        fontSize: isGrid ? 10 : 11,
                        fontWeight: FontWeight.normal,
                        fontFamily: GoogleFonts.poppins().fontFamily,
                      ),
                    ),
                    const SizedBox(
                      height: 4.0,
                    ),
                    Text(
                      content,
                      style: TextStyle(
                        color: Colors.black.withOpacity(0.7),
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        fontFamily: GoogleFonts.poppins().fontFamily,
                      ),
                      overflow: TextOverflow.ellipsis,
                      maxLines: isGrid? 3 : 1,
                    ),
                  ],
                ),
                Positioned(
                  right: 4.0,
                  bottom: 4.0,
                  child: Visibility(
                    visible: isGrid && wordcount > 0,
                    child: Text(
                      wordcount == 1 ? '$wordcount word' : '$wordcount words',
                      style: TextStyle(
                          color: Colors.black45,
                          fontSize: 11,
                          fontFamily: GoogleFonts.poppins().fontFamily),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void confirmDelete(BuildContext context, String docId, String userId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Delete Note",
              style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
          content: Text("Are you sure you want to delete this note?",
              style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text("Cancel",
                  style:
                      TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
            ),
            TextButton(
              onPressed: () {
                moveNoteToDeleted(context, docId, userId);
              },
              child: Text("Delete",
                  style:
                      TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
            ),
            TextButton(
              onPressed: () {
                deleteNoteCard(context, docId, userId);
              },
              child: Text(
                "Delete Permanently",
                style: TextStyle(
                    color: Colors.red,
                    fontFamily: GoogleFonts.poppins()
                        .fontFamily // Set the text color to red
                    ),
              ),
            ),
          ],
        );
      },
    );
  }

  void moveNoteToDeleted(
      BuildContext context, String docId, String userId) async {
    FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection("LockedNotes")
        .doc(docId)
        .get()
        .then((docSnapshot) {
      if (docSnapshot.exists && docSnapshot.data() != null) {
        Map<String, dynamic> data = docSnapshot.data()!;
        // Add the 'deletedAt' timestamp field to the data
        data['deletedAt'] = FieldValue.serverTimestamp();
        print(data);

        FirebaseFirestore.instance
            .collection('users')
            .doc(userId)
            .collection("DeletedNotes")
            .doc(docId)
            .set(data)
            .then((_) {
          deleteNoteCard(context, docId, userId);
        }).catchError((error) => print("Failed to move Note: $error"));
      } else {
        print("Note does not exist or is already deleted.");
      }
    });
  }

  void deleteNoteCard(BuildContext context, String docId, String userId) {
    FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection("LockedNotes")
        .doc(docId)
        .delete()
        .then((value) {
      Navigator.of(context).pop();
      Navigator.of(context).pop();
    }).catchError((error) => print("Failed to delete Note: $error"));
  }

  void updateLockNote(
      String docId, String title, String content, String userId) {
        String encryptedContent = NoteService().encrypt(content);
    FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection("LockedNotes")
        .doc(docId)
        .update({
      "note_title": title,
      "note_content": encryptedContent,
    }).then((_) {
      print('Note updated successfully');
    }).catchError((error) {
      print("Failed to update note: $error");
    });
  }
}
