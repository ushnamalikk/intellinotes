import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../HomeScreen/store_notes.dart';

Future<bool> confirmDelete(BuildContext context, String docId, String userId, String categoryName, {bool homeOrNot = false, Function()? refreshHomeScreen}) async {
  bool deleteConfirmed = await showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text("Delete Note"),
        content: Text("Are you sure you want to delete this note?"),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(false); // Return false if canceled
            },
            child: Text("Cancel"),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop(true); // Return true if confirmed
            },
            child: Text("Delete"),
          ),
        ],
      );
    },
  );

  if (deleteConfirmed) {
    await moveNoteToDeleted(context, docId, userId, categoryName, homeOrNot: homeOrNot, refreshHomeScreen: refreshHomeScreen);
    return true;
  }
  return false;
}

Future<void> moveNoteToDeleted(BuildContext context, String docId, String userId, String categoryName, {bool homeOrNot = false, Function()? refreshHomeScreen}) async {
  print(docId);
  print("adsd");
  QuerySnapshot querySnapshot = await FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection("Categories")
      .where("Name", isEqualTo: categoryName)
      .get();

  if (querySnapshot.docs.isNotEmpty) {
    print("CHECK 1");
    // Assuming there's only one category with this name
    var categoryDoc = querySnapshot.docs.first;
    var categoryRef = categoryDoc.reference;

    DocumentSnapshot docSnapshot = await categoryRef.collection("Notes").doc(docId).get();
    if (docSnapshot.exists && docSnapshot.data() != null) {
      // Use type casting to ensure data is of type Map<String, dynamic>
      Map<String, dynamic> data = docSnapshot.data() as Map<String, dynamic>; // Type casting
      print(categoryDoc.id);
      data['deletedAt'] = Timestamp.now(); // Timestamp for the current time
      data['categoryName'] = categoryName;
      print(docSnapshot.id);
      await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .collection("DeletedNotes")
          .doc(docId)
          .set(data);
      allNotes.remove(docId);
      if (refreshHomeScreen != null) {
        refreshHomeScreen();
      }
      deleteNoteCard(context, docId, userId, categoryName, categoryRef, homeOrNot: homeOrNot, refreshHomeScreen: refreshHomeScreen);
    } else {
      print("Note does not exist or is already deleted.");
    }
  } else {
    print("Category $categoryName not found.");
  }
}


Future<void> deleteNoteCard(BuildContext context, String docId, String userId, String categoryName, categoryRef, {bool homeOrNot = false, Function()? refreshHomeScreen}) async {
  print(categoryName);
  try {
    await categoryRef.collection("Notes").doc(docId).delete();
    if (homeOrNot) {
      Navigator.of(context).pop();
      refreshHomeScreen!();
    }
    else {
      Navigator.of(context).pop();
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Note deleted successfully'),
        backgroundColor: Colors.green, // Set background color to green for success
        duration: Duration(seconds: 1), // Set duration to 2 seconds
      ),
    );
  } catch (error) {
    print("Failed to delete Note: $error");
    ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error deleting note'),
          backgroundColor: Colors.red, // Set background color to red for error
          duration: Duration(seconds: 1), // Set duration to 2 seconds
        ),
    );
  }
}
