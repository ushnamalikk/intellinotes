// ignore: file_names
// ignore_for_file: prefer_typing_uninitialized_variables

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';

class NoteDetailScreen extends StatelessWidget {
  final String noteTitle;
  final String noteContent;
  final int colorId;
  final creationDate;
  final int wordcount;

  const NoteDetailScreen({
    Key? key,
    required this.noteTitle,
    required this.noteContent,
    required this.colorId,
    required this.creationDate,
    required this.wordcount,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color backgroundColor = AppStyle.cardsColor[colorId];
    DateTime creationDatea = DateFormat('dd/MM/yy hh:mm:ss a').parse(creationDate);
    DateTime now = DateTime.now();
    Duration difference = now.difference(creationDatea);
    String formattedDate;
    if (difference.inHours < 24) {
      formattedDate = DateFormat('hh:mm a').format(creationDatea); // Show only hours and minutes
    } else {
      formattedDate = DateFormat('dd/MM/yy hh:mm a').format(creationDatea); // Show whole date and time
    }

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor:
            backgroundColor, // Match AppBar color with the background
        elevation: 0, // Optional: Remove shadow for a flat design
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: Padding(
        padding: const EdgeInsets.only(left: 16, right: 16, bottom: 24, top: 0),
        child: Stack(
          fit: StackFit.expand, // Ensure the Stack fills the screen
          children: [
            SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    noteTitle.isNotEmpty ? noteTitle : 'Untitled Note',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      fontFamily: GoogleFonts.poppins().fontFamily,
                    ),
                  ),
                  const SizedBox(height: 8.0),
                  Row(
                    children: [
                      Text(
                        formattedDate,
                        style: AppStyle.dateTitle.copyWith(
                          color: Colors.black45,
                          fontFamily: GoogleFonts.poppins().fontFamily,
                        ),
                      ),
                      const SizedBox(width: 4.0),
                      Visibility(
                        visible: wordcount > 0,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 8.0),
                          child: RichText(
                            text: TextSpan(
                              style: TextStyle(
                                color: Colors.black45,
                                fontSize: 13,
                                fontFamily: GoogleFonts.poppins().fontFamily,
                              ),
                              children: [
                                TextSpan(
                                  text: '|',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold, // Making only the "|" character bold
                                  ),
                                ),
                                TextSpan(
                                  text: wordcount == 1 ? '   $wordcount word' : '   $wordcount words',
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8.0),
                  Text(
                    noteContent,
                    style: TextStyle(
                      color: Colors.black,
                      fontFamily: GoogleFonts.poppins().fontFamily,
                    ),
                  ),
                  const SizedBox(
                      height: 80), // Provide extra space for the word count
                ],
              ),
            ),
            // Positioned(
            //   bottom: 16.0,
            //   right: 16.0,
            //   child: Visibility(
            //     visible: wordcount > 0,
            //     child: Text(
            //       wordcount == 1 ? '$wordcount word' : '$wordcount words',
            //       style: TextStyle(color: Colors.black45, fontSize: 16,  fontFamily: GoogleFonts.poppins().fontFamily,),
            //
            //     ),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }
}