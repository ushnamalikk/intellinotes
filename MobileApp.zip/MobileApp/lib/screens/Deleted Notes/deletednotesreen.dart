// ignore_for_file: library_private_types_in_public_api, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:myapp/screens/HomeScreen/store_notes.dart';
import 'package:myapp/screens/Deleted%20Notes/noteDetail.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:myapp/screens/widgets/Encryption/note_service.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:myapp/screens/Note/addCategoryWhileRecovering.dart';
import 'package:provider/provider.dart';
import '../HomeScreen/homeScreen.dart';
import '../ToDoList/todolist_screen.dart';
import '../categories/categoriesList.dart';
import 'package:myapp/screens/App%20Drawer/appDrawer.dart';
import 'package:google_fonts/google_fonts.dart';

void deleteExpiredNotes(String userId) async {
  final cutoff = DateTime.now().subtract(const Duration(days: 30));
  final expiredNotesQuery = FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection('DeletedNotes')
      .where('deletedAt', isLessThanOrEqualTo: Timestamp.fromDate(cutoff));

  final querySnapshot = await expiredNotesQuery.get();

  for (var doc in querySnapshot.docs) {
    await doc.reference.delete();
  }
}

class DeletedNotesScreen extends StatefulWidget {
  final String userId;
  final bool homeOrNot;
  final String categoryName;
  final TextEditingController searchController;

  DeletedNotesScreen(
      {required this.userId,
      required this.homeOrNot,
      required this.categoryName,
      required this.searchController});

  @override
  _DeletedNotesScreenState createState() => _DeletedNotesScreenState();
}

class _DeletedNotesScreenState extends State<DeletedNotesScreen> {
  final Map<String, bool> _selectedNotes = {};
  bool isGridMode = true;
  final FocusNode _focusNode = FocusNode();
  TextEditingController searchController = TextEditingController();

  @override
  void dispose() {
    _focusNode.dispose();
    searchController.dispose();
    super.dispose();
  }

  void showOptionsBottomSheet(
      BuildContext context, String docId, bool isDarkMode) {
    showModalBottomSheet(
      context: context,
      backgroundColor:
          AppStyle.getPopupBarColor(isDarkMode), // Change the color here
      builder: (BuildContext context) {
        return Wrap(
          children: <Widget>[
            ListTile(
              contentPadding: const EdgeInsets.only(
                  top: 8.0, left: 15.0), // Add padding from the top here
              leading: const Icon(
                Icons.restore,
                color: Colors.white,
              ),
              title: Text(
                'Recover',
                style: TextStyle(
                    fontFamily: GoogleFonts.poppins().fontFamily,
                    color: AppStyle.getPopupBarTextColor(isDarkMode)),
              ),
              onTap: () {
                Navigator.pop(context);
                _recoverNote(docId);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_forever, color: Colors.red),
              title: Text(
                'Permanently Delete',
                style: TextStyle(
                  fontFamily: GoogleFonts.poppins().fontFamily,
                  color: Colors.red,
                ),
              ),
              onTap: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('Confirm Deletion',
                          style: TextStyle(
                              fontFamily: GoogleFonts.poppins().fontFamily)),
                      content: Text(
                          'Are you sure you want to permanently delete this note?',
                          style: TextStyle(
                              fontFamily: GoogleFonts.poppins().fontFamily)),
                      actions: <Widget>[
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop(); // Close the dialog
                          },
                          child: Text('No',
                              style: TextStyle(
                                  fontFamily:
                                      GoogleFonts.poppins().fontFamily)),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pop(); // Close the dialog
                            _deleteNotePermanently(
                                docId); // Call delete function
                          },
                          child: Text('Yes',
                              style: TextStyle(
                                  fontFamily:
                                      GoogleFonts.poppins().fontFamily)),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ],
        );
      },
    );
  }

  void _toggleNoteSelection(String docId) {
    setState(() {
      if (_selectedNotes.containsKey(docId)) {
        _selectedNotes.remove(docId);
      } else {
        _selectedNotes[docId] = true;
      }
    });
  }

  void _deleteNotePermanently(String docId) async {
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.userId)
          .collection('DeletedNotes')
          .doc(docId)
          .delete();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Note permanently deleted',
              style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
          backgroundColor:
              Colors.green, // Set background color to green for success
          duration: const Duration(seconds: 2), // Set duration to 2 seconds
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error deleting note',
              style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
          backgroundColor: Colors.red, // Set background color to red for error
          duration: const Duration(seconds: 2), // Set duration to 2 seconds
        ),
      );
    }
  }

  void _recoverNote(String docId) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.userId)
          .collection('DeletedNotes')
          .doc(docId)
          .get();

      if (snapshot.exists) {
        final noteData = snapshot.data() as Map<String, dynamic>;
        final categoryName = noteData['categoryName'];

        await checkCategoryExistsAndAdd(context, widget.userId, categoryName);

        // Remove 'deletedAt'
        noteData.remove('deletedAt');

        final categoryQuery = await FirebaseFirestore.instance
            .collection('users')
            .doc(widget.userId)
            .collection("Categories")
            .where("Name", isEqualTo: categoryName)
            .get();

        if (categoryQuery.docs.isNotEmpty) {
          final categoryDoc = categoryQuery.docs.first;
          final categoryRef = categoryDoc.reference;
          DocumentReference newNoteRef =
              await categoryRef.collection("Notes").add(noteData);

          QuerySnapshot notesSnapshot = await FirebaseFirestore.instance
              .collection('users')
              .doc(widget.userId)
              .collection("Categories")
              .doc(categoryDoc.id) // Using the ID obtained from the categoryDoc
              .collection('Notes')
              .where(FieldPath.documentId, isEqualTo: newNoteRef.id)
              .get();
          QueryDocumentSnapshot note = notesSnapshot.docs.first;
          insertNote(newNoteRef.id, note);

          FirebaseFirestore.instance
              .collection('users')
              .doc(widget.userId)
              .collection('DeletedNotes')
              .doc(docId)
              .delete();

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Note restored successfully',
                  style:
                      TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
              backgroundColor:
                  Colors.green, // Set background color to green for success
              duration: const Duration(seconds: 2), // Set duration to 2 seconds
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Category not found',
                  style:
                      TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
              backgroundColor:
                  Colors.red, // Set background color to red for error
              duration: const Duration(seconds: 2), // Set duration to 2 seconds
            ),
          );
          return;
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Note not found',
                style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
            backgroundColor:
                Colors.red, // Set background color to red for error
            duration: const Duration(seconds: 2), // Set duration to 2 seconds
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error restoring note: $e',
              style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
          backgroundColor: Colors.red, // Set background color to red for error
          duration: const Duration(seconds: 2), // Set duration to 2 seconds
        ),
      );
    }
  }

  void _deselectNotes() {
    setState(() {
      _selectedNotes.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 65.0, // Adjust the toolbar height as needed
        leading: Builder(
          builder: (context) => Padding(
            padding: const EdgeInsets.only(
                left: 10.0), // Adjust the padding value as needed
            child: IconButton(
              icon: Icon(Icons.menu,
                  color: AppStyle.getBackArroworMenuColor(isDarkMode)),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        ),

        title: Align(
          alignment: const Alignment(-1.0,
              -0.9), // Adjust the alignment as needed for both icon and text
          child: Text(
            'Recently Deleted',
            style: GoogleFonts.poppins(
              fontSize: 32.0,
              color: AppStyle.getTextColor(isDarkMode),
            ),
          ),
        ),
        iconTheme: const IconThemeData(size: 35),
        backgroundColor: AppStyle.getMainColor(isDarkMode),
      ),

      backgroundColor: AppStyle.getMainColor(isDarkMode),
      drawer: appDrawer(context, widget.userId, "",
          recentlyscreen: true), // Add the app drawer here
      bottomNavigationBar: BottomAppBar(
        color: AppStyle.getbottomBarColor(isDarkMode),
        shape: const CircularNotchedRectangle(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            IconButton(
              icon: Icon(Icons.article_outlined,
                  size: 36, color: AppStyle.getbottomBarIconColor(isDarkMode)),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => HomeScreen(
                      userId: widget.userId,
                    ),
                  ),
                );
              },
            ),
            IconButton(
              icon: Icon(Icons.category_outlined,
                  size: 32, color: AppStyle.getbottomBarIconColor(isDarkMode)),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => CategoriesList(userId: widget.userId),
                  ),
                );
              },
            ),
            IconButton(
              icon: Icon(FontAwesomeIcons.listCheck,
                  size: 28, color: AppStyle.getbottomBarIconColor(isDarkMode)),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => TaskListScreen(
                      userId: widget.userId,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          const SizedBox(height: 15),
          Container(
            margin: const EdgeInsets.only(left: 16.0, right: 16.0),
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(50),
              border: Border.all(
                color: searchController.text.isNotEmpty && _focusNode.hasFocus
                    ? AppStyle.getFocusedSearchBarColor(isDarkMode)
                    : AppStyle.getSearchBarColor(isDarkMode),
                width: 2,
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 16.0),
                    child: TextField(
                      controller: searchController,
                      focusNode: _focusNode,
                      style:
                          TextStyle(color: AppStyle.getTextColor(isDarkMode)),
                      onChanged: (value) {
                        setState(() {});
                      },
                      textAlignVertical: TextAlignVertical.center,
                      decoration: InputDecoration(
                        hintText: 'Search notes',
                        hintStyle: TextStyle(
                            color: AppStyle.getSearchBarTextColor(isDarkMode),
                            fontFamily: GoogleFonts.poppins().fontFamily),
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(isGridMode ? Icons.list : Icons.grid_view),
                  color: AppStyle.getnoteViewStyleColor(isDarkMode),
                  onPressed: () {
                    setState(() => isGridMode = !isGridMode);
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: GestureDetector(
              onTap: _deselectNotes, // Deselect notes when tapping empty space
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('users')
                    .doc(widget.userId)
                    .collection('DeletedNotes')
                    .orderBy('deletedAt',
                        descending:
                            true) // Sort by deletion timestamp in descending order
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (snapshot.hasError) {
                    return Center(child: Text('Error: ${snapshot.error}'));
                  }
                  if (snapshot.data == null || snapshot.data!.docs.isEmpty) {
                    // return Center(
                    //   child: Padding(
                    //     padding: const EdgeInsets.only(bottom: 80.0),
                    //     child: Column(
                    //       mainAxisSize: MainAxisSize.min,
                    //       children: <Widget>[
                    //         Image.asset(
                    //           'assets/images/NoNote.jpeg', // Make sure you have added the right path to your asset image in your pubspec.yaml
                    //           width: 80.0, // Set your desired image width
                    //           height: 80.0, // Set your desired image height
                    //           color: Colors
                    //               .grey, // This applies a color filter to the image, remove this line if you don't want to change the image color
                    //         ),
                    //         Text(
                    //           'No deleted notes found',
                    //           style: TextStyle(
                    //             fontSize: 16.0,
                    //             color: AppStyle.getTextColor(
                    //                 isDarkMode), // Make sure the AppStyle.getTextColor method is defined to get the correct color
                    //             fontFamily: GoogleFonts.poppins().fontFamily,
                    //           ),
                    //         ),
                    //       ],
                    //     ),
                    //   ),
                    // );
                    return Center(
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 80.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            // Replace this with your actual logo widget
                            const Icon(Icons.article_outlined,
                                size: 90.0, color: Colors.grey),
                            Padding(
                              padding: const EdgeInsets.only(
                                  top:
                                      10.0), // Adjust the top padding as needed
                              child: Text(
                                'No deleted notes',
                                style: TextStyle(
                                  fontSize: 16.0,
                                  color: Colors
                                      .grey, // You would define this method in your AppStyle class
                                  fontFamily: GoogleFonts.poppins().fontFamily,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }

                  List<DocumentSnapshot> allNotes = snapshot.data!.docs;
                  List<DocumentSnapshot> filteredNotes =
                      allNotes.where((noteSnapshot) {
                    final note = noteSnapshot.data() as Map<String, dynamic>;
                    final decryptedContent =
                        NoteService().decrypt(note['note_content']);
                    final title = note['note_title'] ?? '';
                    final content = decryptedContent;
                    final query = searchController.text.toLowerCase();
                    return title.toLowerCase().contains(query) ||
                        content.toLowerCase().contains(query);
                  }).toList();

                  return isGridMode
                      ? GridView.builder(
                          padding: const EdgeInsets.all(8),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                          ),
                          itemCount: filteredNotes.length,
                          itemBuilder: (context, index) {
                            var doc = filteredNotes[index];
                            var note = doc.data() as Map<String, dynamic>;
                            String abc = note['creation_date'];
                            DateTime creationDate =
                                DateFormat('dd/MM/yy hh:mm:ss a').parse(abc);
                            DateTime now = DateTime.now();
                            Duration difference = now.difference(creationDate);
                            String formattedDate;
                            if (difference.inHours < 24) {
                              formattedDate = DateFormat('hh:mm a').format(
                                  creationDate); // Show only hours and minutes
                            } else {
                              formattedDate = DateFormat('dd/MM/yy hh:mm a')
                                  .format(
                                      creationDate); // Show whole date and time
                            }

                            _selectedNotes.containsKey(doc.id);
                            var noteSnapshot = filteredNotes[index];
                            String docId = noteSnapshot.id;
                            final decryptedContent =
                                NoteService().decrypt(note['note_content']);
                            String content = decryptedContent;
                            int wordcount = content
                                .split(RegExp(r'\s+'))
                                .where((s) => s.isNotEmpty)
                                .length;

                            return GestureDetector(
                              onTap: () {
                                if (_selectedNotes.isNotEmpty) {
                                  _toggleNoteSelection(doc.id);
                                } else {
                                  Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (context) => NoteDetailScreen(
                                        noteTitle: note['note_title'].isNotEmpty
                                            ? note['note_title']
                                            : 'Untitled Note',
                                        noteContent: decryptedContent.isEmpty
                                            ? 'No content available'
                                            : decryptedContent,
                                        colorId: note['color_id'] ?? 0,
                                        creationDate: note['creation_date'],
                                        wordcount: wordcount,
                                      ),
                                    ),
                                  );
                                }
                              },
                              onLongPress: () {
                                showOptionsBottomSheet(
                                    context, doc.id, isDarkMode);
                              },
                              child: Card(
                                color: _selectedNotes.containsKey(docId)
                                    ? Colors.grey.withOpacity(0.5)
                                    : AppStyle.cardsColor[note['color_id']],
                                margin: const EdgeInsets.all(6.0),
                                elevation: 2,
                                child: Stack(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Expanded(
                                                child: Text(
                                                  note['note_title'].isNotEmpty
                                                      ? note['note_title']
                                                      : decryptedContent
                                                          .split('\n')
                                                          .first,
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.w700,
                                                    fontFamily:
                                                        GoogleFonts.poppins()
                                                            .fontFamily,
                                                    color: Colors.black,
                                                    fontSize: 19,
                                                  ),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                              ),
                                              if (_selectedNotes
                                                  .containsKey(docId))
                                                Icon(Icons.check_circle,
                                                    color: Colors.green),
                                            ],
                                          ),
                                          SizedBox(height: 6.0),
                                          Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(
                                                Icons.folder_open_rounded,
                                                color: Colors.black
                                                    .withOpacity(0.6),
                                                weight: 8,
                                                size: 16,
                                              ),
                                              SizedBox(width: 4),
                                              Text(
                                                note['categoryName'],
                                                style: GoogleFonts.poppins(
                                                  textStyle: AppStyle.mainTitle
                                                      .copyWith(
                                                    color: Colors.black
                                                        .withOpacity(0.6),
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: 12,
                                                    fontFamily:
                                                        GoogleFonts.poppins()
                                                            .fontFamily,
                                                  ),
                                                ),
                                                maxLines: 1,
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 4.0),
                                          Text(
                                            formattedDate,
                                            style: TextStyle(
                                              color:
                                                  Colors.black.withOpacity(0.6),
                                              fontSize: 10.5,
                                              fontWeight: FontWeight.normal,
                                              fontFamily: GoogleFonts.poppins()
                                                  .fontFamily,
                                            ),
                                          ),
                                          SizedBox(height: 8.0),
                                          Text(
                                            content.length > 2 * 30
                                                ? '${content.substring(0, 2 * 30)}...'
                                                : content,
                                            maxLines: 3,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              color: Colors.black
                                                  .withOpacity(0.65),
                                              fontFamily: GoogleFonts.poppins()
                                                  .fontFamily,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 13,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Positioned(
                                      right: 10,
                                      bottom: 10,
                                      child: Visibility(
                                        visible: wordcount > 0,
                                        child: Text(
                                          wordcount == 1
                                              ? '$wordcount word'
                                              : '$wordcount words',
                                          style: TextStyle(
                                            color: Colors.black45,
                                            fontSize: 11,
                                            fontFamily: GoogleFonts.poppins()
                                                .fontFamily,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: filteredNotes.length,
                          itemBuilder: (context, index) {
                            var noteSnapshot = filteredNotes[index];
                            var note =
                                noteSnapshot.data() as Map<String, dynamic>;
                            String docId = noteSnapshot.id;
                            final decryptedContent =
                                NoteService().decrypt(note['note_content']);
                            String content = decryptedContent;
                            int wordcount = content
                                .split(RegExp(r'\s+'))
                                .where((s) => s.isNotEmpty)
                                .length;
                            String abc = note['creation_date'];
                            DateTime creationDate =
                                DateFormat('dd/MM/yy hh:mm:ss a').parse(abc);
                            DateTime now = DateTime.now();
                            Duration difference = now.difference(creationDate);
                            String formattedDate;
                            if (difference.inHours < 24) {
                              formattedDate = DateFormat('hh:mm a').format(
                                  creationDate); // Show only hours and minutes
                            } else {
                              formattedDate = DateFormat('dd/MM/yy hh:mm a')
                                  .format(
                                      creationDate); // Show whole date and time
                            }

                            return GestureDetector(
                              onTap: () {
                                if (_selectedNotes.isNotEmpty) {
                                  _toggleNoteSelection(docId);
                                } else {
                                  Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (context) => NoteDetailScreen(
                                        noteTitle: note['note_title'].isNotEmpty
                                            ? note['note_title']
                                            : 'Untitled Note',
                                        noteContent: decryptedContent.isEmpty
                                            ? 'No content available'
                                            : decryptedContent,
                                        colorId: note['color_id'] ?? 0,
                                        creationDate: note['creation_date'],
                                        wordcount: wordcount,
                                      ),
                                    ),
                                  );
                                }
                              },
                              onLongPress: () {
                                showOptionsBottomSheet(
                                    context, docId, isDarkMode);
                              },
                              child: Card(
                                color: _selectedNotes.containsKey(docId)
                                    ? Colors.grey.withOpacity(0.5)
                                    : AppStyle.cardsColor[note['color_id']],
                                margin: const EdgeInsets.symmetric(
                                    vertical: 4, horizontal: 4),
                                elevation: 2,
                                child: Stack(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            note['note_title'].isNotEmpty
                                                ? note['note_title']
                                                : decryptedContent
                                                    .split('\n')
                                                    .first,
                                            style: TextStyle(
                                              fontSize: 19,
                                              fontWeight: FontWeight.w600,
                                              fontFamily: GoogleFonts.poppins()
                                                  .fontFamily,
                                              color: Colors.black,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                          SizedBox(height: 4.0),
                                          Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(
                                                Icons.folder_open_rounded,
                                                color: Colors.black
                                                    .withOpacity(0.6),
                                                size: 16,
                                              ),
                                              SizedBox(width: 4),
                                              Text(
                                                note['categoryName'],
                                                style:
                                                    AppStyle.mainTitle.copyWith(
                                                  color: Colors.black
                                                      .withOpacity(0.6),
                                                  fontSize: 12,
                                                  fontFamily:
                                                      GoogleFonts.poppins()
                                                          .fontFamily,
                                                ),
                                                maxLines: 1,
                                              ),
                                            ],
                                          ),
                                          SizedBox(height: 4.0),
                                          Text(
                                            formattedDate,
                                            style: AppStyle.dateTitle.copyWith(
                                                color: Colors.black
                                                    .withOpacity(0.6),
                                                fontSize: 12,
                                                fontWeight: FontWeight.normal,
                                                fontFamily:
                                                    GoogleFonts.poppins()
                                                        .fontFamily),
                                          ),
                                          SizedBox(height: 6.0),
                                          Text(
                                            content,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              color:
                                                  Colors.black.withOpacity(0.7),
                                              fontSize: 13,
                                              fontWeight: FontWeight.bold,
                                              fontFamily: GoogleFonts.poppins()
                                                  .fontFamily,
                                            ),
                                            softWrap: false,
                                          ),
                                          if (_selectedNotes.containsKey(docId))
                                            Icon(Icons.check_circle,
                                                color: Colors.green),
                                        ],
                                      ),
                                    ),
                                    // Positioned(
                                    //   right: 4.0,
                                    //   bottom: 4.0,
                                    //   child: Visibility(
                                    //     visible: wordcount > 0,
                                    //     child: Text(
                                    //       wordcount == 1
                                    //           ? '$wordcount word'
                                    //           : '$wordcount words',
                                    //       style: const TextStyle(
                                    //           color: Colors.black45,
                                    //           fontSize: 11),
                                    //     ),
                                    //   ),
                                    // ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
