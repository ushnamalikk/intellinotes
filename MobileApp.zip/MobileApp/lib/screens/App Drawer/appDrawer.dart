import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:myapp/screens/categories/categoriesList.dart';
import 'package:myapp/screens/HomeScreen/homeScreen.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:myapp/screens/Setting%20Screen/settingscreen.dart';
import 'package:myapp/screens/Deleted%20Notes/deletednotesreen.dart';
import 'package:myapp/screens/widgets/Dialogue%20Boxes/passwordDialogue.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:myapp/screens/categories/viewCategoryNotes.dart';
import 'package:myapp/screens/widgets/Dialogue%20Boxes/confirm_signout_dialogue.dart';
import 'package:provider/provider.dart';
import 'package:myapp/screens/widgets/Dialogue%20Boxes/add_category_dialogue.dart';
import 'package:myapp/screens/Password Recovery/security_questions.dart';

Widget appDrawer(BuildContext context, String userId, String categoryName,
    {bool homescreen = false,
    bool lockscreen = false,
    bool recentlyscreen = false}) {
  final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;

  void navigateToCategoryNotes(String categoryName) {
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) =>
              ViewCategoryNotes(userId: userId, categoryName: categoryName)),
    );
  }

  return FutureBuilder<List<String>>(
    future: fetchCategories(userId),
    builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) {
        return const Drawer(
          child: Center(
            child: CircularProgressIndicator(),
          ),
        );
      } else if (snapshot.hasError) {
        return Drawer(
          child: Center(
            child: Text('Error fetching categories: ${snapshot.error}'),
          ),
        );
      } else {
        List<String> categories = snapshot.data ?? [];
        return Drawer(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 285,
                color: AppStyle.getMainColor(isDarkMode),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 75, vertical: 15),
                      title: Text(
                        'IntelliNotes',
                        style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.w500,
                            color: AppStyle.getAppDrawerFirstBoxTextColor(
                                isDarkMode),
                            fontFamily: GoogleFonts.poppins().fontFamily),
                      ),
                    ),
                    ListTile(
                      leading: Icon(Icons.article,
                          color: AppStyle.getAppDrawerFirstBoxTextColor(
                              isDarkMode)),
                      title: Text(
                        'All Notes',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.normal,
                            color: AppStyle.getAppDrawerFirstBoxTextColor(
                                isDarkMode),
                            fontFamily: GoogleFonts.poppins().fontFamily),
                      ),
                      onTap: () {
                        if (homescreen) {
                          Navigator.pop(context);
                        } else {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    HomeScreen(userId: userId)),
                          );
                        }
                      },
                    ),
                    ListTile(
                      leading: Icon(
                        Icons.lock,
                        color:
                            AppStyle.getAppDrawerFirstBoxTextColor(isDarkMode),
                      ),
                      title: Text(
                        'Locked Notes',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.normal,
                            color: AppStyle.getAppDrawerFirstBoxTextColor(
                                isDarkMode),
                            fontFamily: GoogleFonts.poppins().fontFamily),
                      ),
                      onTap: () {
                        if (lockscreen) {
                          Navigator.pop(context);
                        } else {
                          showPasswordDialog(context, userId);
                        }
                      },
                    ),
                    ListTile(
                      leading: Icon(
                        Icons.delete,
                        color:
                            AppStyle.getAppDrawerFirstBoxTextColor(isDarkMode),
                      ),
                      title: Text(
                        'Recently Deleted',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.normal,
                            color: AppStyle.getAppDrawerFirstBoxTextColor(
                                isDarkMode),
                            fontFamily: GoogleFonts.poppins().fontFamily),
                      ),
                      onTap: () {
                        if (recentlyscreen) {
                          Navigator.pop(context);
                        } else {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => DeletedNotesScreen(
                                      userId: userId,
                                      homeOrNot: homescreen,
                                      categoryName: categoryName,
                                      searchController: TextEditingController(),
                                    )),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  color: AppStyle.getAppDrawerSecondBoxColor(isDarkMode),
                  border: Border(
                    top: BorderSide(
                        color: AppStyle.getAppDrawerBorderColor(isDarkMode)), // Set the top border color
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: ListTile(
                        title: Text(
                          'Categories',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w500,
                            color: AppStyle.getAppDrawerRemBoxTextColor(
                                isDarkMode),
                            fontFamily: GoogleFonts.poppins().fontFamily,
                          ),
                        ),
                        // contentPadding: EdgeInsets.only(left: 16, right: 8, bottom: 0),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                CategoriesList(userId: userId),
                          ),
                        );
                      },
                      child: const Padding(
                        padding: EdgeInsets.only(right: 20.0),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: DecoratedBox(
                  decoration: BoxDecoration(
                      color: AppStyle.getAppDrawerSecondBoxColor(isDarkMode),
                      // border: const Border(
                      //     top: BorderSide(
                      //         color: Color.fromARGB(255, 255, 255, 255)))
                      ),
                  child: SingleChildScrollView(
                    // Wrap with SingleChildScrollView
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SingleChildScrollView(
                          // Wrap with SingleChildScrollView
                          scrollDirection: Axis.vertical,
                          child: ListView.builder(
                            padding: const EdgeInsets.only(top: 0.0),
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: categories.length,
                            itemBuilder: (context, index) {
                              return Container(
                                decoration: BoxDecoration(
                                  color: categories[index] == categoryName
                                      ? AppStyle
                                          .getbottomBarIconSelectionIndication(
                                              isDarkMode) // Color for the selected category
                                      : Colors.transparent,
                                  // A subtle white overlay indicating selection
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: ListTile(
                                  leading: categories[index] == categoryName
                                      ? Icon(
                                          Icons.category_outlined,
                                          size: 26,
                                          color: AppStyle
                                              .getEditIconAppDrawerColor(
                                                  isDarkMode),
                                        ) // Use filled icon if category is selected
                                      : Icon(Icons.category_outlined,
                                          color: AppStyle
                                              .getEditIconAppDrawerColor(
                                                  isDarkMode)),
                                  title: categories[index] == categoryName
                                      ? Text(
                                          categories[index],
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            color: AppStyle
                                                .getAppDrawerFirstBoxTextColor(
                                                    isDarkMode), // Use default color for other categories
                                            fontFamily: GoogleFonts.poppins()
                                                .fontFamily,
                                          ),
                                        )
                                      : Text(
                                          categories[index],
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.normal,
                                            color: AppStyle
                                                .getAppDrawerFirstBoxTextColor(
                                                    isDarkMode), // Use default color for other categories
                                            fontFamily: GoogleFonts.poppins()
                                                .fontFamily,
                                          ),
                                        ),
                                  onTap: () {
                                    Navigator.pop(context); // Close the drawer
                                    // Perform action for the tapped category
                                    // For example, navigate to a screen with notes under this category
                                    navigateToCategoryNotes(categories[index]);
                                  },
                                ),
                              );
                            },
                          ),
                        ),
                        ListTile(
                          leading: Padding(
                            padding: const EdgeInsets.only(
                                left: 2), // Adjust left padding as needed
                            child: Icon(Icons.add, size: 21, color: AppStyle.getEditIconAppDrawerColor(isDarkMode)),
                          ),
                          title: Text(
                            'Create New Category',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.normal,
                              color: AppStyle.getAppDrawerFirstBoxTextColor(
                                  isDarkMode),
                              fontFamily: GoogleFonts.poppins().fontFamily,
                              fontStyle: FontStyle.italic, // Add this line
                            ),
                          ),
                          onTap: () async {
                            String newCategory =
                                await showAddCategoryDialog(context, userId);
                            if (newCategory.isNotEmpty) {
                              Navigator.pop(context);
                              navigateToCategoryNotes(newCategory);
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  color: AppStyle.getAppDrawerThirdBoxColor(isDarkMode),
                  border:  Border(top: BorderSide(color: AppStyle.getAppDrawerBorderColor(isDarkMode))),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    ListTile(
                      leading: Icon(Icons.settings,
                          color:
                              AppStyle.getAppDrawerRemBoxTextColor(isDarkMode)),
                      title: Text(
                        'Settings',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.normal,
                            color: AppStyle.getAppDrawerRemBoxTextColor(
                                isDarkMode),
                            fontFamily: GoogleFonts.poppins().fontFamily),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SettingsScreen(
                                    userId: userId,
                                  )),
                        );
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.lock,
                          color:
                              AppStyle.getAppDrawerRemBoxTextColor(isDarkMode)),
                      title: Text(
                       'Password Recovery',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.normal,
                            color: AppStyle.getAppDrawerRemBoxTextColor(
                                isDarkMode),
                            fontFamily: GoogleFonts.poppins().fontFamily),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SecurityQuestionScreen(userId: userId),
                          ),
                        );
                      },
                    ),
                    ListTile(
                      leading: Icon(
                        Icons.logout,
                        color: AppStyle.getSignOutColor(isDarkMode), // Set the icon color to red
                      ),
                      title: Text(
                        'Sign Out',
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.normal,
                            color: AppStyle.getSignOutColor(isDarkMode),
                            fontFamily: GoogleFonts.poppins().fontFamily),
                      ),
                      onTap: () {
                        confirmSignOutDialog(
                            context);
                      },
                    )
                  ],
                ),
              ),
            ],
          ),
        );
      }
    },
  );
}

Future<List<String>> fetchCategories(String userId) async {
  try {
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection('Categories')
        .get();

    final List<QueryDocumentSnapshot> sortedDocuments = querySnapshot.docs;
    sortedDocuments.sort((a, b) {
      final String dateStringA = a['date'] as String;
      final String dateStringB = b['date'] as String;
      final DateTime dateTimeA =
          DateFormat('dd/MM/yy hh:mm:ss a').parse(dateStringA);
      final DateTime dateTimeB =
          DateFormat('dd/MM/yy hh:mm:ss a').parse(dateStringB);
      final comparisonResult =
          dateTimeB.compareTo(dateTimeA); // Sort in descending order
      return comparisonResult;
    });

    List<String> orderedlist =
        sortedDocuments.map((doc) => doc['Name'].toString()).toList();

    return orderedlist;
  } catch (e) {
    rethrow;
  }
}

