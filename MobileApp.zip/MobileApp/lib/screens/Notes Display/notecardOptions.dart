// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:myapp/screens/Deleted%20Notes/notedelete.dart';
import 'package:myapp/screens/HomeScreen/store_notes.dart';
import 'package:myapp/screens/categories/viewCategoryNotes.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:myapp/screens/widgets/Dialogue%20Boxes/lockDialogue.dart';
import 'package:myapp/screens/Note/moveNote.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:provider/provider.dart';

void showOptions(
    BuildContext context,
    QueryDocumentSnapshot note,
    String userId,
    String categoryName,
    String docId,
    bool homeOrNot,
    bool isGrid,
    Function()? refreshHomeScreen) {
  bool isPinned = note['pin'] ?? false;

  showModalBottomSheet(
    context: context,
    builder: (BuildContext context) {
      final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;

      return Container(
        height: 75,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          color: AppStyle.getPopupBarColor(isDarkMode),
          borderRadius: const BorderRadius.vertical(
              top: Radius.circular(0)), // No rounding on top
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            IconButton(
              icon: isPinned
                  ? const Icon(
                      Icons.push_pin_outlined,
                      size: 27,
                    )
                  : const Icon(
                      Icons.push_pin,
                      size: 27,
                    ),
              onPressed: () async {
                await FirebaseFirestore.instance
                    .collection('users')
                    .doc(userId)
                    .collection("Categories")
                    .where("Name", isEqualTo: categoryName)
                    .get()
                    .then((QuerySnapshot querySnapshot) {
                  if (querySnapshot.docs.isNotEmpty) {
                    var categoryDoc = querySnapshot.docs.first;
                    categoryDoc.reference
                        .collection("Notes")
                        .doc(docId)
                        .update({
                      'pin': !isPinned,
                    }).then((_) async {
                      QuerySnapshot notesSnapshot = await FirebaseFirestore
                          .instance
                          .collection('users')
                          .doc(userId)
                          .collection("Categories")
                          .doc(categoryDoc
                              .id) // Using the ID obtained from the categoryDoc
                          .collection('Notes')
                          .where(FieldPath.documentId, isEqualTo: docId)
                          .get();
                      QueryDocumentSnapshot note = notesSnapshot.docs.first;
                      insertNote(docId, note);
                      refreshHomeScreen!();
                      print(
                          'Note ${isPinned ? 'pinned' : 'unpinned'} successfully');
                    }).catchError((error) {
                      print(
                          "Failed to ${isPinned ? 'unpin' : 'pin'} note: $error");
                    });
                  }
                }).catchError((error) {
                  print("Error fetching category: $error");
                });

                Navigator.of(context).pop();

                if (homeOrNot) {
                  refreshHomeScreen!();
                } else {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ViewCategoryNotes(
                        userId: userId,
                        categoryName: categoryName,
                        isGrid: isGrid,
                      ),
                    ),
                  );
                }
              },
            ),
            IconButton(
              icon: const Icon(
                Icons.lock,
                size: 25.5,
              ),
              onPressed: () async {
                final confirmLock = await showLockDialog(context);
                if (confirmLock == true) {
                  Map<String, dynamic> noteData = {
                    'note_title': note['note_title'],
                    'note_content': note['note_content'],
                    'color_id': note['color_id'],
                    'creation_date': note['creation_date'],
                    'categoryName': categoryName,
                    'pin': note['pin'],
                  };

                  allNotes.remove(docId);

                  await FirebaseFirestore.instance
                      .collection('users')
                      .doc(userId)
                      .collection("LockedNotes")
                      .add(noteData);

                  final categoryQuery = await FirebaseFirestore.instance
                      .collection('users')
                      .doc(userId)
                      .collection("Categories")
                      .where("Name", isEqualTo: categoryName)
                      .get();

                  if (categoryQuery.docs.isNotEmpty) {
                    final categoryDoc = categoryQuery.docs.first;
                    final categoryRef = categoryDoc.reference;
                    await categoryRef.collection("Notes").doc(docId).delete();
                    Navigator.pop(context);
                    if (homeOrNot) {
                      refreshHomeScreen!();
                    }
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Category not found'),
                        backgroundColor:
                            Colors.red, // Set background color to red
                      ),
                    );
                    return;
                  }

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Note locked successfully'),
                      backgroundColor:
                          Colors.green, // Set background color to green
                    ),
                  );
                }
              },
            ),
            IconButton(
              icon: const Icon(
                Icons.swap_horiz,
                size: 31,
              ),
              onPressed: () async {
                await selectCategoryForMove(context, userId, docId, note,
                    categoryName, homeOrNot, refreshHomeScreen);
                Navigator.pop(context);

                if (homeOrNot) {
                  refreshHomeScreen!();
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Category not found'),
                      backgroundColor:
                          Colors.red, // Set background color to red
                    ),
                  );
                  return;
                }

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Note moved successfully'),
                    backgroundColor:
                        Colors.green, // Set background color to green
                  ),
                );
              },
            ),
            IconButton(
              icon: const Icon(
                Icons.delete,
                size: 27,
              ),
              onPressed: () async {
                Navigator.of(context).pop();
                bool deleted =
                    await confirmDelete(context, note.id, userId, categoryName);
                if (deleted) {
                  if (homeOrNot) {
                    refreshHomeScreen!();
                  } else {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ViewCategoryNotes(
                          userId: userId,
                          categoryName: categoryName,
                        ),
                      ),
                    );
                  }
                }
              },
            ),
          ],
        ),
      );
    },
  );
}
