// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, use_build_context_synchronously, must_be_immutable, unused_field, avoid_print, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:myapp/screens/HomeScreen/store_notes.dart';
import 'package:myapp/screens/Note/moveNote.dart';
import 'package:myapp/screens/widgets/Encryption/note_service.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:myapp/Classes/noteclass.dart';
import 'package:myapp/screens/Deleted%20Notes/notedelete.dart';
import 'package:myapp/screens/Note/noteUpdate.dart';
import 'package:myapp/screens/Note/note_options.dart';
import 'package:myapp/screens/widgets/Dialogue%20Boxes/lockDialogue.dart';
import '../widgets/Dialogue Boxes/add_category_dialogue.dart';

class NoteView extends StatefulWidget {
  QueryDocumentSnapshot doc;
  String categoryName;
  final String userId;
  final bool? homeOrNot;
  final Function()? refreshHomeScreen;
  List<String> categoryList;

  NoteView({
    Key? key,
    required this.doc,
    required this.categoryName,
    required this.userId,
    this.homeOrNot,
    this.refreshHomeScreen,
    required this.categoryList,
  }) : super(key: key);

  @override
  State<NoteView> createState() => _NoteViewState();
}

class _NoteViewState extends State<NoteView> {
  late TextEditingController _titleController;
  late TextEditingController _contentController;
  bool isNoteLocked = false;
  int wordcount = 0;
  Color selectedColor = Color(0xFFEBE4C0);
  String? _selectedCategory;
  String? _selectedText;
  String? categoryNameOld;
  String? oldId;
  bool isPalette = false;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.doc['note_title']);
    _contentController = TextEditingController(
        text: NoteService().decrypt(widget.doc['note_content']));
    updateWordCount();
    _contentController.addListener(updateWordCount);
    setColorFromDoc();
    _selectedCategory = widget.categoryName;
    categoryNameOld = widget.categoryName;
    oldId = widget.doc.id;
  }

  Future<void> _onCategorySelected(String? newValue) async {
    _selectedCategory = newValue;
    widget.doc = await moveNoteToCategory(
      widget.userId,
      widget.doc.id,
      newValue!,
      widget.categoryName,
      _titleController.text,
      _contentController.text,
      widget.doc['color_id'],
      widget.doc['pin'],
      refresh: widget.refreshHomeScreen,
    );
    widget.categoryName = newValue;
    setState(() {});
  }

  void setColorFromDoc() {
    int colorId = widget.doc['color_id'];
    if (colorId >= 0 && colorId < AppStyle.cardsColor.length) {
      setState(() {
        selectedColor = AppStyle.cardsColor[colorId];
      });
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  void updateWordCount() {
    setState(() {
      wordcount =
          Note(title: _titleController.text, content: _contentController.text)
              .getWordCount(_contentController.text);
    });
  }

  void _showLockDialog() async {
    final confirmLock = await showLockDialog(
        context); // Use the function from lock_dialogue.dart

    if (confirmLock == true) {
      moveNoteToLocked(
        context,
        widget.userId,
        widget.categoryName,
        widget.doc,
        _titleController,
        _contentController,
        homeOrNot: widget.homeOrNot ?? false,
        refreshHomeScreen: widget.refreshHomeScreen,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final decryptedContent = NoteService().decrypt(widget.doc['note_content']);
    String abc = widget.doc['creation_date'];
    DateTime creationDate = DateFormat('dd/MM/yy hh:mm:ss a').parse(abc);
    DateTime now = DateTime.now();
    Duration difference = now.difference(creationDate);
    String formattedDate;
    if (difference.inHours < 24) {
      formattedDate = DateFormat('hh:mm a').format(creationDate); // Show only hours and minutes
    } else {
      formattedDate = DateFormat('dd/MM/yy hh:mm a').format(creationDate); // Show whole date and time
    }
    // final decryptedTitle = NoteService().decrypt(widget.doc['note_title']);
    return WillPopScope(
      onWillPop: () async {
        if (widget.doc['note_title'] == _titleController.text &&
            decryptedContent == _contentController.text &&
            widget.categoryName == categoryNameOld) {
          return true;
        } else {
          updateNote(
            widget.doc.id,
            _titleController.text,
            _contentController.text,
            widget.userId,
            widget.categoryName,
            refresh: widget.refreshHomeScreen,
          );
        }
        return true;
      },
      child: Scaffold(
        backgroundColor: selectedColor,
        appBar: AppBar(
          backgroundColor: selectedColor,
          elevation: 0.0,
          toolbarHeight: 30,
          iconTheme: const IconThemeData(color: Colors.black),
          actions: [
            IconButton(
              icon: Icon(isNoteLocked ? Icons.lock : Icons.lock_open,
                  color: Colors.black),
              onPressed: () {
                if (isNoteLocked) {
                } else {
                  _showLockDialog();
                }
              },
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.black),
              onPressed: () => confirmDelete(
                context,
                widget.doc.id,
                widget.userId,
                widget.categoryName,
                homeOrNot: widget.homeOrNot ?? false,
                refreshHomeScreen: widget.refreshHomeScreen,
              ),
            ),
            PopupMenuButton<Color>(
              icon: const Icon(Icons.color_lens, color: Colors.black),
              onSelected: (color) {
                setState(() {
                  selectedColor = color;
                });
                updateNoteColor(AppStyle.cardsColor.indexOf(color),
                    widget.categoryName, widget.userId);
              },
              itemBuilder: (BuildContext context) {
                return [
                  PopupMenuItem<Color>(
                    child: SizedBox(
                      width: MediaQuery.of(context).size.width * 0.8, // adjust width as needed
                      height: 100, // adjust height as needed
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal, // scroll horizontally
                        child: Row(
                          children: AppStyle.cardsColor.map((Color color) {
                            return GestureDetector(
                              onTap: () {
                                Navigator.pop(context, color);
                              },
                              child: Container(
                                margin: EdgeInsets.all(4),
                                width: 30,
                                height: 24,
                                color: color,
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ),
                ];
              },
            ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: _titleController,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: 'Title',
                  hintStyle: TextStyle(
                      color: Colors.black45,
                      fontSize: 28,
                      fontFamily: GoogleFonts.poppins().fontFamily),
                ),
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    fontFamily: GoogleFonts.poppins().fontFamily),
              ),
              Container(
                height: 36,
                width: 142,
                decoration: BoxDecoration(
                  color: Colors.black45.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(
                      25.0), // Adjust the border radius as needed
                  border: Border.all(color: Colors.black45.withOpacity(0.7)),
                ),
                child: SingleChildScrollView(
                  physics:
                      AlwaysScrollableScrollPhysics(), // Ensure the dropdown menu is always scrollable
                  child: DropdownButtonFormField<String>(
                    borderRadius: BorderRadius.circular(25),
                    value: _selectedCategory,
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 12.2,
                        height: 1.5,
                        fontFamily: GoogleFonts.poppins().fontFamily),
                    padding: EdgeInsets.zero, // Remove internal padding
                    icon: Padding(
                      padding: EdgeInsets.only(
                          top: 0), // Add bottom padding to the dropdown arrow
                      child: Icon(
                          Icons.arrow_drop_down_sharp), // Dropdown arrow icon
                    ), // Dropdown arrow icon
                    iconSize: 15, // Adjust the icon size as needed
                    iconEnabledColor:
                        Colors.white, // Color of the dropdown arrow
                    dropdownColor: Colors.black45.withOpacity(
                        0.7), // Background color of the dropdown menu
                    decoration: InputDecoration(
                      border: InputBorder
                          .none, // Remove the border around the dropdown field
                      contentPadding: EdgeInsets.fromLTRB(
                          14, 0, 10, 16), // Adjust the internal content padding
                    ),
                    items: [
                      DropdownMenuItem<String>(
                        value: _selectedCategory,
                        // child: Text("$_selectedCategory"),
                        child: Text(
                          _selectedCategory == 'Create New Category'
                              ? "Add Category"
                              : "$_selectedCategory",
                        ),
                      ),
                      ...widget.categoryList
                          .where((category) => category != _selectedCategory)
                          .map((category) {
                        return DropdownMenuItem<String>(
                          value: category,
                          child: Text(
                            category,
                            overflow: TextOverflow
                                .ellipsis, // Ellipsis for long texts
                            maxLines: 1, // Display only one line of text
                          ),
                        );
                      }),
                      DropdownMenuItem<String>(
                        value: 'Create New Category',
                        child: Row(
                          children: [
                            Icon(
                              Icons.add,
                              size: 15,
                            ), // Add the prefix icon here
                            SizedBox(
                                width:
                                    8), // Add some spacing between the icon and text
                            Expanded(
                              child: Text(
                                'Add Category',
                                overflow: TextOverflow
                                    .ellipsis, // Set overflow property
                                maxLines: 1, // Set maxLines property
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                    onChanged: (newValue) async {
                      if (newValue != categoryNameOld) {
                        String newCategory = newValue!;
                        if (newValue == 'Create New Category') {
                          newCategory = await showAddCategoryDialog(
                              context, widget.userId);
                        }
                        _onCategorySelected(newCategory);
                        setState(() {});
                      }
                      widget.refreshHomeScreen!();
                    },
                    isExpanded:
                        true, // Ensure the dropdown button expands to fit the content
                    menuMaxHeight: 300,
                  ),
                ),
              ),
              const SizedBox(
                height: 16.0,
              ),
              Row(
                children: [
                  Text(
                    formattedDate,
                    style: AppStyle.dateTitle.copyWith(
                      color: Colors.black45,
                      fontFamily: GoogleFonts.poppins().fontFamily,
                    ),
                  ),
                  const SizedBox(width: 4.0),
                  Visibility(
                    visible: wordcount > 0,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0),
                      child: RichText(
                        text: TextSpan(
                          style: TextStyle(
                            color: Colors.black45,
                            fontSize: 13,
                            fontFamily: GoogleFonts.poppins().fontFamily,
                          ),
                          children: [
                            TextSpan(
                              text: '|',
                              style: TextStyle(
                                fontWeight: FontWeight.bold, // Making only the "|" character bold
                              ),
                            ),
                            TextSpan(
                              text: wordcount == 1 ? '   $wordcount word' : '   $wordcount words',
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8.0),
              Expanded(
                child: TextField(
                  controller: _contentController,
                  onChanged: (value) => updateWordCount(),
                  keyboardType: TextInputType.multiline,
                  maxLines: null,
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    hintText: 'Note Content',
                    hintStyle: TextStyle(color: Colors.black45),
                  ),
                  style: TextStyle(
                      color: Colors.black,
                      fontFamily: GoogleFonts.poppins().fontFamily),
                ),
              ),
              NoteOptions(
                onParaphrase: (text) {},
                titleController: _titleController,
                contentController: _contentController,
                docId: widget.doc.id,
                userId: widget.userId,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> updateNoteColor(
      int colorId, String categoryName, String userId) async {
    String date = DateFormat('dd/MM/yy hh:mm:ss a').format(DateTime.now());

    await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection("Categories")
        .where("Name", isEqualTo: categoryName)
        .get()
        .then((QuerySnapshot categorySnapshot) {
      if (categorySnapshot.docs.isNotEmpty) {
        // Assume there's only one category with this name.
        var categoryDoc = categorySnapshot.docs.first;

        // Update the category's date first
        categoryDoc.reference.update({'date': date}).then((_) {
          print("Category date updated successfully for $categoryName");

          // Proceed to update the color of the note
          categoryDoc.reference
              .collection('Notes')
              .doc(widget.doc.id)
              .update({'color_id': colorId}).then((value) async {
            QuerySnapshot notesSnapshot = await FirebaseFirestore.instance
                .collection('users')
                .doc(userId)
                .collection("Categories")
                .doc(categoryDoc
                    .id) // Using the ID obtained from the categoryDoc
                .collection('Notes')
                .where(FieldPath.documentId, isEqualTo: widget.doc.id)
                .get();
            QueryDocumentSnapshot note = notesSnapshot.docs.first;
            insertNote(widget.doc.id, note);
            widget.refreshHomeScreen!();
            print("Color updated successfully for category $categoryName");
          }).catchError((error) {
            print("Failed to update color for category $categoryName: $error");
          });
        }).catchError((error) {
          print("Failed to update category date for $categoryName: $error");
        });
      } else {
        print("Category $categoryName not found");
      }
    }).catchError((error) {
      print("Failed to get categories: $error");
    });

    if (widget.homeOrNot ?? false) {
      widget.refreshHomeScreen!();
    }
  }
}
