import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:myapp/Classes/noteclass.dart';
import 'package:myapp/screens/widgets/Encryption/note_service.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:myapp/screens/Notes Display/notecardOptions.dart';

class NoteCard extends StatefulWidget {
  final VoidCallback onTap;
  final QueryDocumentSnapshot note;
  final String userId;
  final String categoryName;
  final String docId;
  final bool homeOrNot;
  final bool? isGrid;
  final Function()? refreshHomeScreen;
  final bool? isSelected;
  final Function(bool)? onSelect;

  const NoteCard({
    required this.onTap,
    required this.note,
    required this.userId,
    required this.categoryName,
    required this.docId,
    required this.homeOrNot,
    this.isGrid,
    this.refreshHomeScreen,
    this.isSelected,
    this.onSelect,
    Key? key,
  }) : super(key: key);

  @override
  _NoteCardState createState() => _NoteCardState();
}

class _NoteCardState extends State<NoteCard> {
  bool isPinned = false;

  @override
  void initState() {
    super.initState();
    isPinned = widget.note['pin'] ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final decryptedContent = NoteService().decrypt(widget.note['note_content']);
    Note myNote = Note(
      title: widget.note['note_title'],
      content: decryptedContent,
    );
    int wordcount = myNote.getWordCount(myNote.content);

    String titleToShow = widget.note['note_title'];
    if (titleToShow.isEmpty) {
      // Use content's first line as title if the title is empty
      List<String> contentLines = decryptedContent.split('\n');
      if (contentLines.isNotEmpty) {
        titleToShow = contentLines.first;
      }
    }

    String abc = widget.note['creation_date'];
    DateTime creationDate = DateFormat('dd/MM/yy hh:mm:ss a').parse(abc);
    DateTime now = DateTime.now();
    Duration difference = now.difference(creationDate);
    String formattedDate;
    if (difference.inHours < 24) {
      formattedDate = DateFormat('hh:mm a').format(creationDate); // Show only hours and minutes
    } else {
      formattedDate = DateFormat('dd/MM/yy hh:mm a').format(creationDate); // Show whole date and time
    }

    if (widget.isGrid ?? true) {
      return GestureDetector(
        onTap: widget.onTap,
        onLongPress: () => showOptions(
            context,
            widget.note,
            widget.userId,
            widget.categoryName,
            widget.docId,
            widget.homeOrNot,
            widget.isGrid ?? true,
            widget.refreshHomeScreen),
        child: Card(
          color: AppStyle.cardsColor[widget.note['color_id']],
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            titleToShow,
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 19,
                              fontWeight: FontWeight.w700,
                              fontFamily: GoogleFonts.poppins().fontFamily,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow
                                .ellipsis, // Handle overflow gracefully
                          ),
                        ),
                        if (isPinned) ...[
                          Transform.rotate(
                            angle: 40 * 3.1415926535 / 180,
                            child: const Icon(
                              Icons.push_pin,
                              color: Colors.black,
                              size: 16,
                            ),
                          ),
                          const SizedBox(width: 4),
                        ],
                      ],
                    ),
                    const SizedBox(width: 12),
                    Padding(
                      padding: const EdgeInsets.only(
                          top: 6.0), // Add top padding here
                      child: Row(
                        children: [
                          Icon(
                            Icons.folder_open_rounded,
                            color: Colors.black.withOpacity(0.6),
                            size: 16,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            widget.categoryName,
                            style: AppStyle.mainTitle.copyWith(
                              color: Colors.black.withOpacity(0.6),
                              fontSize: 12,
                              fontFamily: GoogleFonts.poppins().fontFamily,
                            ),
                            maxLines: 1,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 4.0,
                    ),
                    Text(
                      formattedDate,
                      style: TextStyle(
                        color: Colors.black.withOpacity(0.6),
                        fontSize: 10,
                        fontWeight: FontWeight.normal,
                        fontFamily: GoogleFonts.poppins().fontFamily,
                      ),
                    ),
                    const SizedBox(
                      height: 8.0,
                    ),
                    Text(
                      decryptedContent,
                      style: TextStyle(
                        color: Colors.black.withOpacity(0.7),
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        fontFamily: GoogleFonts.poppins().fontFamily,
                      ),
                      maxLines: 3,
                    ),
                  ],
                ),
                Positioned(
                  right: 4.0,
                  bottom: 0,
                  child: Visibility(
                    visible: wordcount > 0,
                    child: Text(
                      wordcount == 1 ? '$wordcount word' : '$wordcount words',
                      style: TextStyle(
                        color: Colors.black45,
                        fontSize: 11,
                        fontFamily: GoogleFonts.poppins().fontFamily,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    } else {
      return GestureDetector(
        onTap: widget.onTap,
        onLongPress: () => showOptions(
            context,
            widget.note,
            widget.userId,
            widget.categoryName,
            widget.docId,
            widget.homeOrNot,
            widget.isGrid ?? true,
            widget.refreshHomeScreen),
        child: Card(
          color: AppStyle.cardsColor[widget.note['color_id']],
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            titleToShow,
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 19,
                              fontWeight: FontWeight.w600,
                              fontFamily: GoogleFonts.poppins().fontFamily,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow
                                .ellipsis, // Handle overflow gracefully
                          ),
                        ),
                        if (isPinned) ...[
                          Transform.rotate(
                            angle: 40 * 3.1415926535 / 180,
                            child: const Icon(
                              Icons.push_pin,
                              color: Colors.black,
                              size: 16,
                            ),
                          ),
                          const SizedBox(width: 4),
                        ],
                      ],
                    ),
                    const SizedBox(width: 12),
                    Padding(
                      padding: const EdgeInsets.only(
                          top: 4.0), // Add top padding here
                      child: Row(
                        children: [
                          Icon(
                            Icons.folder_open_rounded,
                            color: Colors.black.withOpacity(0.6),
                            size: 16,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            widget.categoryName,
                            style: AppStyle.mainTitle.copyWith(
                              color: Colors.black.withOpacity(0.6),
                              fontSize: 12,
                              fontFamily: GoogleFonts.poppins().fontFamily,
                            ),
                            maxLines: 1,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 4.0,
                    ),
                    Text(
                      formattedDate,
                      style: AppStyle.dateTitle.copyWith(
                          color: Colors.black.withOpacity(0.6),
                          fontSize: 12,
                          fontWeight: FontWeight.normal,
                          fontFamily: GoogleFonts.poppins().fontFamily),
                    ),
                    const SizedBox(
                      height: 4.0,
                    ),
                    Text(
                      decryptedContent,
                      style: TextStyle(
                        color: Colors.black.withOpacity(0.7),
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        fontFamily: GoogleFonts.poppins().fontFamily,
                      ),
                      maxLines: 1,
                      overflow:
                          TextOverflow.ellipsis, // Set overflow to ellipsis
                      softWrap: false, // Disable soft wrapping
                    ),
                  ],
                ),
                // Positioned(
                //   right: 4.0,
                //   top: 90.0,
                //   child: Visibility(
                //     visible: wordcount > 0,
                //     child: Text(
                //       wordcount == 1 ? '$wordcount word' : '$wordcount words',
                //       style: TextStyle(
                //         color: Colors.black45,
                //         fontSize: 11,
                //         fontFamily: GoogleFonts.poppins().fontFamily,
                //       ),
                //     ),
                //   ),
                // ),
                const SizedBox(
                  height: 80.0,
                ),
              ],
            ),
          ),
        ),
      );
    }
  }
}
