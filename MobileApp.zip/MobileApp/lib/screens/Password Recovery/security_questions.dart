import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:provider/provider.dart';

class SecurityQuestionScreen extends StatefulWidget {
  final String userId;

  const SecurityQuestionScreen({Key? key, required this.userId})
      : super(key: key);

  @override
  _SecurityQuestionScreenState createState() => _SecurityQuestionScreenState();
}

class _SecurityQuestionScreenState extends State<SecurityQuestionScreen> {
  TextEditingController answerController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool isLoading = false;
  String? selectedQuestion;
  String? existingQuestion;
  String? existingAnswer;

  List<String> securityQuestions = [
    'What is your mother\'s maiden name?',
    'What is the name of your first pet?',
    'In what city were you born?',
    'What is your favorite book?',
    'What is your favorite movie?',
  ];

  @override
  void initState() {
    super.initState();
    // Fetch existing security question and answer
    fetchExistingData();
  }

  void fetchExistingData() async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('security_questions')
          .doc(widget.userId)
          .get();
      if (snapshot.exists) {
        setState(() {
          existingQuestion = snapshot.data()?['selected_question'];
          existingAnswer = snapshot.data()?['answer'];
          answerController.text = existingAnswer ?? '';
        });
      }
    } catch (e) {
      print("Error fetching existing data: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.only(top: 11.0, left: 12),
          child: IconButton(
            icon: Icon(Icons.arrow_back,
                size: 30, color: AppStyle.getBackArroworMenuColor(isDarkMode)),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ),
        title: Padding(
          padding: const EdgeInsets.only(top: 12.0),
          child: Text(
            'Security Question',
            style: TextStyle(
              fontSize: 23.0,
              fontFamily: GoogleFonts.poppins().fontFamily,
              color: isDarkMode
                  ? Colors.white
                  : Colors.black,
              fontWeight: FontWeight.normal,
            ),
          ),
        ),
        backgroundColor: AppStyle.getMainColor(isDarkMode),
      ),
      backgroundColor: AppStyle.getMainColor(isDarkMode),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Select Security Question:',
                    style: TextStyle(
                      fontSize: 18.0,
                      fontFamily: 'Poppins',
                      color: isDarkMode ? Colors.white : Colors.black,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Container(
                  child: SingleChildScrollView(
                    child: Column(
                      children: securityQuestions.map((String question) {
                        return RadioListTile<String>(
                          title: Text(
                            question,
                            style: TextStyle(
                              color: isDarkMode ? Colors.white : Colors.black,
                            ),
                          ),
                          value: question,
                          groupValue: selectedQuestion,
                          onChanged: (String? value) {
                            setState(() {
                              selectedQuestion = value;
                              answerController.clear();
                            });
                          },
                          selected: selectedQuestion == question,
                          activeColor: isDarkMode ? Colors.white : Colors.black, // Set the color of the radio button
                        );
                      }).toList(),
                    ),
                  ),
                ),

                const SizedBox(height: 20),
                TextFormField(
                  controller: answerController,
                  decoration: InputDecoration(
                    labelText: 'Answer',
                    prefixIcon: Icon(Icons.lock_open,
                        color: AppStyle.getTextColor(isDarkMode)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: Colors.black,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: AppStyle.getFocusedPasswordBoxColor(
                            isDarkMode), // Focused border color
                      ),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: Colors.red, // Error border color
                      ),
                    ),
                    focusedErrorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: AppStyle.getFocusedPasswordBoxColor(
                            isDarkMode), // Focused error border color
                      ),
                    ),
                    errorStyle: GoogleFonts.poppins(
                      fontSize: 12.0,
                      color: Colors.red, // Error text color
                    ),
                    labelStyle: GoogleFonts.poppins(
                      color: AppStyle.getTextColor(isDarkMode),
                    ),
                  ),
                  style: TextStyle(
                    color: AppStyle.getTextColor(isDarkMode), // Text input color
                  ),
                  cursorColor: AppStyle.getTextColor(isDarkMode), // Cursor color
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter the answer';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: isLoading
                      ? null
                      : () async {
                    if (_formKey.currentState!.validate()) {
                      String selectedQuestion =
                          this.selectedQuestion ?? existingQuestion!;
                      String answer = answerController.text;

                      try {
                        setState(() {
                          isLoading = true;
                        });

                        // Store the selected question and answer in Firebase
                        await FirebaseFirestore.instance
                            .collection('security_questions')
                            .doc(widget.userId)
                            .set({
                          'user_id': widget.userId,
                          'selected_question': selectedQuestion,
                          'answer': answer,
                        });

                        setState(() {
                          isLoading = false;
                        });

                        // Show a dialog indicating the security question has been set
                        showDialog(
                          context: context,
                          builder: (context) {
                            return AlertDialog(
                              title: Text('Security Question Set'),
                              content: Text(
                                  'Your security question has been set. If you forget your account password, you can use this to recover it.'),
                              actions: <Widget>[
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                    Navigator.of(context).pop();
                                  },
                                  child: Text('OK'),
                                ),
                              ],
                            );
                          },
                        );
                      } catch (e) {
                        // Handle errors
                        print("Error: $e");
                        setState(() {
                          isLoading = false;
                        });
                      }
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                    AppStyle.getSettingsButtonsButtonBackGroundColor(
                        isDarkMode), // Set background color
                  ),
                  child: isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : Text(
                    'Save',
                    style: TextStyle(
                      color:
                      AppStyle.getSettingsButtonsButtonTextColor(
                          isDarkMode),
                      fontFamily: 'Poppins',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
