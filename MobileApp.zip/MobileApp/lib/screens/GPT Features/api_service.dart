
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'chat_request.dart';
import 'chat_response.dart';

class ApiService {
  static const String gptApiKey = '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';
  static final Uri chatUri = Uri.parse('https://api.openai.com/v1/chat/completions');

  static final Map<String, String> headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ${gptApiKey}',
  };

  static Future<String?> paraphraseText(String text, int wordCount) async {
    // Refine the text parameter by removing unwanted characters
    String cleanText = text;
    if (wordCount > 200) {
      List<String> textChunks = _splitTextIntoChunks(cleanText);
      List<String?> responses = [];

      try {
        for (int i = 0; i < textChunks.length; i++) {
          String chunk = textChunks[i];
          String prompt = "$chunk Paraphrase this text. Provide a simplified version without changing the original meaning. Do not create new paragraphs. Do not respond as a chat bot or use first person pronouns.";
          if (prompt.isNotEmpty) {
            ChatRequest request = ChatRequest(model: "gpt-3.5-turbo", maxTokens: 150, messages: [Message(role: "system", content: prompt)]);
            http.Response response = await http.post(
              chatUri,
              headers: headers,
              body: request.toJson(),
            );
            ChatResponse chatResponse = ChatResponse.fromResponse(response);
            responses.add(chatResponse.choices?[0].message?.content);
          }
        }

        String? combinedResponse = responses.join();
        return combinedResponse;
      } catch (e) {
        print("error $e");
        return null;
      }
    } else {
      // Perform normal call
      String prompt = "$cleanText \nParaphrase this text. Provide a simplified version without changing the original meaning. Do not create new information. Make appropriate paragraphs and understandable text. Do not respond as a chat bot or use first person pronouns.";
      try {
        ChatRequest request = ChatRequest(model: "gpt-3.5-turbo", maxTokens: 150, messages: [Message(role: "system", content: prompt)]);
        if (prompt.isNotEmpty) {
          http.Response response = await http.post(
            chatUri,
            headers: headers,
            body: request.toJson(),
          );
          ChatResponse chatResponse = ChatResponse.fromResponse(response);
          return chatResponse.choices?[0].message?.content;
        }
      } catch (e) {
        print("error $e");
      }
      return null;
    }
  }

  static List<String> _splitTextIntoChunks(String text) {
    int chunkSize = 150; // Define your chunk size here
    List<String> chunks = [];
    for (int i = 0; i < text.length; i += chunkSize) {
      chunks.add(text.substring(i, i + chunkSize < text.length ? i + chunkSize : text.length));
    }
    return chunks;
  }

  static Future<String?> summarizeText(String text, int wordCount) async {
    // Refine the text parameter by removing unwanted characters
    String cleanText = text.replaceAll(RegExp(r'[^\w\s]'), '');
    // Construct the prompt with the cleaned text
    String prompt = "$cleanText \nSummarize this text. Provide a concise summary, reducing the word count by half. Do not include any new information. Make appropriate paragraphs and provide understandable text. Do not respond as a chat bot or use first person pronouns.";
    try {
      ChatRequest request = ChatRequest(model: "gpt-3.5-turbo", maxTokens: 150, messages: [Message(role: "system", content: prompt)]);
      if (prompt.isEmpty) {
        return null;
      }
      http.Response response = await http.post(
        chatUri,
        headers: headers,
        body: request.toJson(),
      );
      ChatResponse chatResponse = ChatResponse.fromResponse(response);
      return chatResponse.choices?[0].message?.content;
    } catch (e) {
      print("error $e");
    }
    return null;
  }

  static Future<String?> generateTitle(String text) async {
    // Refine the text parameter by removing unwanted characters
    String cleanText = text.replaceAll(RegExp(r'[^\w\s]'), '');
    // Construct the prompt with the cleaned text
    String prompt = "$cleanText \nGenerate titles for this text. Provide distinct and appropriate titles in a numbered format. Each title should stand out and be relevant. Do not respond as a chat bot.";
    try {
      ChatRequest request = ChatRequest(model: "gpt-3.5-turbo", maxTokens: 150, messages: [Message(role: "system", content: prompt)]);
      if (prompt.isEmpty) {
        return null;
      }
      http.Response response = await http.post(
        chatUri,
        headers: headers,
        body: request.toJson(),
      );
      ChatResponse chatResponse = ChatResponse.fromResponse(response);
      return chatResponse.choices?[0].message?.content;
    } catch (e) {
      // print("error $e");
    }
    return null;
  }
}
