import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void showResponseDialog(BuildContext context, String requestType, String? response, TextEditingController contentController) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return Dialog(
        backgroundColor: Colors.black,
        insetPadding: EdgeInsets.symmetric(horizontal: 16.0),
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.7), // Adjust the value as needed
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: Icon(Icons.android, color: Colors.white),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    Expanded(
                      child: Text(
                        requestType,
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.close, color: Colors.white),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
              ),
              Flexible(
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Text(
                      response ?? 'Failed to get response',
                      style: TextStyle(color: Colors.white),
                      textAlign: response != null ? TextAlign.justify : TextAlign.center,
                    ),
                  ),
                ),
              ),
              if (response != null)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 16.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      if (requestType == "Paraphrase" || requestType == "Summarize")
                        OutlinedButton(
                          onPressed: () {
                            final selection = contentController.selection;
                            final text = contentController.text;
                            final newText = selection.isCollapsed
                                ? response // If no selection, replace all text
                                : text.replaceRange(selection.start, selection.end, response); // Replace only selected text
                            contentController.text = newText;
                            if (!selection.isCollapsed) {
                              // Update the selection to new text
                              contentController.selection = TextSelection.fromPosition(
                                TextPosition(offset: selection.start + response.length),
                              );
                            }
                            Navigator.of(context).pop();
                          },
                          style: OutlinedButton.styleFrom(side: BorderSide(color: Colors.white)),
                          child: Text('Replace', style: TextStyle(color: Colors.white)),
                        ),
                      OutlinedButton(
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: response));
                          Navigator.of(context).pop();
                        },
                        style: OutlinedButton.styleFrom(side: BorderSide(color: Colors.white)),
                        child: Text('Copy', style: TextStyle(color: Colors.white)),
                      ),
                      if (requestType == "Generate Title")
                        SizedBox(width: 36.0),
                    ],
                  ),
                ),
            ],
          ),
        ),
      );
    },
  );
}
