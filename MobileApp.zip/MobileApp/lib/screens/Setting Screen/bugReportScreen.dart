// ignore_for_file: unused_field, prefer_const_constructors, use_build_context_synchronously

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class BugReportScreen extends StatefulWidget {
  final String userId;

  BugReportScreen({required this.userId});

  @override
  _BugReportScreenState createState() => _BugReportScreenState();
}

class _BugReportScreenState extends State<BugReportScreen> {
  final _formKey = GlobalKey<FormState>();
  String _bugDescription = '';
  String _stepsToReproduce = '';
  String _suggestion = ''; // Field for suggestions
  String _contactEmail = ''; // Optional contact email

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;

    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.only(top: 4.0, left: 12),
          child: IconButton(
            icon: Icon(Icons.arrow_back,
                size: 30, color: AppStyle.getBackArroworMenuColor(isDarkMode)),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ),
        title: Text(
          'Report Bugs',
          style: GoogleFonts.poppins(
            fontSize: 23.0,
            fontWeight: FontWeight.normal,
            color: AppStyle.getTextColor(
                isDarkMode), // Ensure this method returns the correct color
          ),
        ),
        backgroundColor: AppStyle.getMainColor(isDarkMode), // AppBar color
      ),

      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              _buildCustomTextField(
                label: 'Describe the bug:',
                hintText: 'Please tell us about the problem...',
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'This field is required.'
                    : null,
                onSaved: (value) => _bugDescription = value!,
              ),
              _buildCustomTextField(
                label: 'Tell Us What Happened:',
                hintText:
                    'Please describe the steps you took when the problem occurred...',
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'This field is required.'
                    : null,
                onSaved: (value) => _stepsToReproduce = value!,
              ),
              _buildCustomTextField(
                label: 'Suggest an improvement (optional):',
                hintText: '',
                onSaved: (value) => _suggestion = value!,
              ),
              _buildCustomTextField(
                label: 'Your email (optional):',
                hintText: '',
                onSaved: (value) => _contactEmail = value!,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor:
                      AppStyle.getSettingsButtonsButtonBackGroundColor(
                          isDarkMode), // Button color
                  shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(12.0), // Make button circular
                  ),
                ),
                onPressed: _submitFeedback,
                child: Text(
                  'Submit Feedback',
                  style: GoogleFonts.poppins(
                    color:
                        AppStyle.getSettingsButtonsButtonTextColor(isDarkMode),
                    // Ensure this method returns the correct color
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      backgroundColor:
          AppStyle.getMainColor(isDarkMode), // Set background color
    );
  }

  Widget _buildCustomTextField({
    required String label,
    required String hintText,
    required Function(String?) onSaved,
    String? Function(String?)? validator,
  }) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.poppins(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: AppStyle.getTextColor(isDarkMode)),
        ),
        SizedBox(height: 8),
        TextFormField(
          maxLines: label == 'Tell Us What Happened:' ? 5 : 1,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
              borderSide: BorderSide(
                color: AppStyle.getFocusedPasswordBoxColor(
                    isDarkMode), // Focused border color
              ),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
              borderSide: BorderSide(
                color: Colors.red, // Error border color
              ),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.0),
              borderSide: BorderSide(
                color: AppStyle.getFocusedPasswordBoxColor(
                    isDarkMode), // Focused error border color
              ),
            ),
            errorStyle: GoogleFonts.poppins(
              fontSize: 12.0,
              color: Colors.red, // Error text color
            ),
            hintText: hintText,
            hintStyle: GoogleFonts.poppins(
              // Apply Poppins font style to hintText
              color: const Color.fromARGB(255, 123, 122,
                  122), // Set hintText color to dynamic text color based on theme
            ),
          ),
          style: GoogleFonts.poppins(
            // Apply Poppins font style to text entered by the user
            color: AppStyle.getTextColor(
                isDarkMode), // Set text color to dynamic text color based on theme
          ), // Apply Poppins font style here
          validator: validator,
          onSaved: onSaved,
        ),
        SizedBox(height: 16),
      ],
    );
  }

  void _submitFeedback() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      await FirebaseFirestore.instance.collection('user_feedback').doc().set({
        'user_id': widget.userId,
        'bug_description': _bugDescription,
        'steps_to_reproduce': _stepsToReproduce,
        'suggestion': _suggestion,
        'contact_email': _contactEmail,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Feedback submitted successfully!",
            style: GoogleFonts.poppins(), // Apply Poppins font style here
          ),
          backgroundColor: Colors.green, // Set background color to green
          duration: Duration(seconds: 2), // Set duration to 2 seconds
        ),
      );

      _formKey.currentState!.reset();
    }
  }
}
