// ignore_for_file: library_private_types_in_public_api, prefer_const_constructors, annotate_overrides, unused_local_variable, sort_child_properties_last, prefer_const_literals_to_create_immutables, use_build_context_synchronously, unnecessary_cast

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:myapp/screens/HomeScreen/homeScreen.dart';
import 'package:myapp/screens/Setting%20Screen/TermsAndConditionsScreen.dart';
import 'package:myapp/screens/Setting%20Screen/bugReportScreen.dart';
import 'package:myapp/screens/ToDoList/todolist_screen.dart';
import 'package:myapp/screens/categories/categoriesList.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:myapp/screens/Setting%20Screen/setNewPassword.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:myapp/screens/App%20Drawer/appDrawer.dart';
import 'package:myapp/screens/widgets/Dialogue%20Boxes/confirm_signout_dialogue.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:google_fonts/google_fonts.dart';

String userImage = 'assets/images/image.jpeg';

class SettingsScreen extends StatefulWidget {
  final String userId;

  const SettingsScreen({Key? key, required this.userId}) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String username = '';
  String email = '';
  bool isDarkModeEnabled = true;
  @override
  void initState() {
    super.initState();
    _fetchUserData();
    _loadUserImagePath();
  }

  Future<void> _pickUserImage(ImageSource source) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: source,
      imageQuality: 85,
      maxWidth: 600,
    );

    if (pickedFile != null) {
      // Save the image path with the user's ID as part of the key
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('userImagePath_${widget.userId}', pickedFile.path);

      setState(() {
        userImage = pickedFile.path;
      });
    } else {
      setState(() {
        userImage = 'assets/images/image.jpeg';
      });
    }
  }

  void _removeImage() {
    setState(() {
      userImage = 'assets/images/image.jpeg';
    });

    // Remove the image path associated with the current user's ID
    SharedPreferences.getInstance().then((prefs) {
      prefs.remove('userImagePath_${widget.userId}');
    });
  }

  Future<void> _loadUserImagePath() async {
    final prefs = await SharedPreferences.getInstance();
    final savedImagePath = prefs.getString('userImagePath_${widget.userId}');

    if (savedImagePath != null) {
      setState(() {
        userImage = savedImagePath;
      });
    }
  }

  Future<void> _fetchUserData() async {
    final DocumentSnapshot userDoc = await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.userId)
        .get();
    if (userDoc.exists) {
      setState(() {
        username = userDoc['username'] ?? 'No Username';
        email = userDoc['email'] ?? 'No Email';
      });
    }
  }

  void _showImageOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return SafeArea(
          child: Wrap(
            children: <Widget>[
              ListTile(
                  leading: Icon(Icons.photo_library),
                  title: Text('Gallery'),
                  onTap: () {
                    Navigator.of(context).pop();
                    _pickUserImage(ImageSource.gallery);
                  }),
              ListTile(
                leading: Icon(Icons.photo_camera),
                title: Text('Camera'),
                onTap: () {
                  Navigator.of(context).pop();
                  _pickUserImage(ImageSource.camera);
                },
              ),
              if (userImage !=
                  'assets/images/image.jpeg') // Show delete option only if a custom image is set
                ListTile(
                  leading: Icon(Icons.delete),
                  title: Text('Remove Image'),
                  onTap: () {
                    Navigator.of(context).pop();
                    _removeImage();
                  },
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _themeToggleTile() {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;

    return _settingsTile(
      isDarkMode
          ? 'Switch to Light Mode'
          : 'Switch to Dark Mode', // Text changes based on current theme
      isDarkMode
          ? Icons.wb_sunny
          : Icons.nights_stay, // Icon changes based on current theme
      () {
        // Use Provider to toggle the theme mode
        final provider = Provider.of<DarkModeProvider>(context, listen: false);
        provider.isDarkMode = !provider.isDarkMode;

        // The setState call is to trigger a rebuild of the UI to reflect the change.
        setState(() {});
      },
      tileColor: isDarkMode
          ? Color.fromARGB(255, 159, 184, 202)
          : const Color(
              0xFF4D4D4D), // Pastel color for light mode, darker color for dark mode
    );
  }

  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    double avatarRadius = 60;
    double iconSize = 30; // The size of your icon
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80.0, // Adjust the toolbar height as needed
        leading: Builder(
          builder: (context) => Padding(
            padding: const EdgeInsets.only(
                left: 12.0, top: 2.0), // Adjust padding as needed
            child: IconButton(
              icon: Icon(Icons.menu,
                  color: AppStyle.getBackArroworMenuColor(isDarkMode)),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        ),
        title: Align(
          alignment: Alignment(-1.0, -0.9),
          child: Text(
            'Settings',
            style: GoogleFonts.poppins(
              fontSize: 32.0,
              color: AppStyle.getTextColor(isDarkMode),
            ),
          ),
        ),
        iconTheme: IconThemeData(size: 35),
        backgroundColor: AppStyle.getMainColor(isDarkMode),
      ),
      drawer: appDrawer(context, widget.userId, ""),
      body: Container(
        color: AppStyle.getMainColor(isDarkMode), // Set background color
        child: Stack(
          children: [
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: <Widget>[
                  SizedBox(height: 10),
                  Stack(
                    alignment:
                        Alignment.center, // Align the stack in the center
                    children: [
                      CircleAvatar(
                        radius: avatarRadius,
                        backgroundColor: Colors.grey.shade300,
                        backgroundImage: userImage.startsWith('http')
                            ? NetworkImage(userImage) as ImageProvider
                            : userImage != 'assets/images/image.jpeg'
                                ? FileImage(File(userImage)) as ImageProvider
                                : AssetImage(userImage),
                      ),
                      Positioned(
                        right: 7, // Spacing from the right
                        bottom: 7, // Spacing from the bottom
                        child: GestureDetector(
                          onTap: () => _showImageOptions(
                              context), // Replace this with your method
                          child: Container(
                            decoration: BoxDecoration(
                              color: AppStyle.getfloatingButtonBackgroundColor(
                                  isDarkMode), // Circle color
                              shape: BoxShape.circle, // Circular shape
                            ),
                            child: Icon(
                              Icons.add_a_photo,
                              size: 19, // Further reduced icon size
                              color: AppStyle.getfloatingButtonColor(
                                  isDarkMode), // Icon color
                            ),
                            padding:
                                EdgeInsets.all(7), // Padding inside the circle
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 5),
                  Text(username,
                      style: GoogleFonts.poppins(
                          fontSize: 24,
                          fontWeight: FontWeight.w500,
                          color: AppStyle.getTextColor(isDarkMode))),
                  ListView(
                    shrinkWrap: true,
                    padding: EdgeInsets.only(
                        top:
                            23), // Increased top padding to move the tiles down
                    physics: NeverScrollableScrollPhysics(),
                    children: <Widget>[
                      _settingsTile('Manage Lock Notes Password', Icons.lock,
                          () => navigateToSetNewPassword(widget.userId),
                          tileColor: isDarkMode
                              ? Color.fromARGB(255, 255, 255, 255)
                              : Color.fromARGB(255, 209, 222, 231)),
                      SizedBox(height: 5),
                      _themeToggleTile(),
                      SizedBox(height: 5),
                      _settingsTile(
                        'Report Bugs',
                        Icons.bug_report,
                        () => Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (context) => BugReportScreen(
                                  userId: widget.userId)), // Pass the userId
                        ),
                        tileColor: isDarkMode
                            ? Color.fromARGB(255, 255, 255, 255)
                            : Color.fromARGB(255, 156, 181, 199),
                      ),
                      SizedBox(height: 5),
                      _settingsTile(
                          'Terms & Conditions',
                          Icons.description,
                          () => Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) =>
                                  TermsAndConditionsScreen())),
                          tileColor: isDarkMode
                              ? Color.fromARGB(255, 255, 255, 255)
                              : Color.fromARGB(255, 75, 112, 139)),
                    ],
                  ),
                ],
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 16,
              child: _settingsTile('Sign Out', Icons.exit_to_app,
                  () => confirmSignOutDialog(context),
                  tileColor: Color.fromARGB(255, 151, 33, 20)),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: AppStyle.getbottomBarColor(isDarkMode),
        shape: const CircularNotchedRectangle(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            // This is the "Home" button that should appear active
            IconButton(
              icon: Icon(Icons.article_outlined,
                  size: 36, color: AppStyle.getbottomBarIconColor(isDarkMode)),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => HomeScreen(
                            userId: widget.userId,
                          )),
                );
              },
            ),

            IconButton(
              icon: const Icon(Icons.category_outlined, size: 32),
              color: AppStyle.getbottomBarIconColor(isDarkMode),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          CategoriesList(userId: widget.userId)),
                );
              },
            ),
            IconButton(
              icon: const Icon(FontAwesomeIcons.listCheck, size: 28),
              color: AppStyle.getbottomBarIconColor(isDarkMode),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => TaskListScreen(
                            userId: widget.userId,
                          )),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _settingsTile(String title, IconData icon, VoidCallback onTap,
      {Color tileColor = const Color(0xFFFFC0CB),
      Color shadowColor = Colors.grey}) {
    // Added shadowColor parameter with default
    return Card(
      elevation: 8.0,
      margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15.0),
        side: BorderSide(
            // color: Color.fromARGB(255, 22, 69, 102),
            width: 0), // Optional, you can add a border if needed
      ),
      color: tileColor,
      shadowColor: const Color.fromARGB(255, 147, 147, 147), // Set the shadow color here
      child: InkWell(
        onTap: onTap,
        splashColor: Colors.white.withAlpha(30),
        highlightColor: Colors.white.withAlpha(20),
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Icon(icon, color: Colors.black87, size: 28),
              SizedBox(width: 24),
              Text(
                title,
                style: GoogleFonts.poppins(
                  color: Colors.black87,
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void navigateToSetNewPassword(String userId) {
    Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => SetNewPasswordScreen(userId: userId)));
  }
}
