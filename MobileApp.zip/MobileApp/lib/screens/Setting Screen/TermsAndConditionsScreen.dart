// ignore_for_file: prefer_const_constructors

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:provider/provider.dart';

class TermsAndConditionsScreen extends StatelessWidget {
  const TermsAndConditionsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.only(top: 3.0, left: 12),
          child: IconButton(
            icon: Icon(Icons.arrow_back,
                size: 30, color: AppStyle.getBackArroworMenuColor(isDarkMode)),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ),
        title: Text(
          'Terms & Conditions',
          style: TextStyle(
              fontSize: 23.0,
              fontFamily: GoogleFonts.poppins().fontFamily,
              fontWeight: FontWeight.normal,
              color: AppStyle.getTextColor(isDarkMode)),
        ),
        backgroundColor: AppStyle.getMainColor(isDarkMode),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.0),
            color: AppStyle.getTandCondContainerColor(
                isDarkMode), // Maintain the light grey background for contrast
          ),
          padding: EdgeInsets.all(30.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSectionTitle("Terms and Conditions", isDarkMode),
              _buildLastUpdated("Last updated: 1 April 2024", isDarkMode),
              _buildSectionContent(
                  "Please read these Terms and Conditions carefully before using the IntelliNotes mobile application operated by Null Studios. Your access to and use of the Service is conditioned upon your acceptance of and compliance with these Terms. These Terms apply to all visitors, users, and others who wish to access or use the Service. By accessing or using the Service you agree to be bound by these Terms. If you disagree with any part of the terms then you do not have permission to access the Service.",
                  isDarkMode),
              _buildSectionTitle("Accounts", isDarkMode),
              _buildSectionContent(
                  "When you create an account with us, you guarantee that the information you provide us is accurate, complete, and current at all times. Inaccurate, incomplete, or obsolete information may result in the immediate termination of your account on the Service. You are responsible for maintaining the confidentiality of your account and password, including but not limited to the restriction of access to your computer and/or account. You agree to accept responsibility for any and all activities or actions that occur under your account and/or password. You must notify us immediately upon becoming aware of any breach of security or unauthorized use of your account.",
                  isDarkMode),
              _buildSectionTitle("Intellectual Property", isDarkMode),
              _buildSectionContent(
                  "The Service and its original content (excluding Content provided by users), features, and functionality are and will remain the exclusive property of IntelliNotes Inc. and its licensors. The Service is protected by copyright, trademarks, and other laws of both Pakistan and foreign countries. Our trademarks and trade dress may not be used in connection with any product or service without the prior written consent of IntelliNotes Inc.",
                  isDarkMode),
              _buildSectionTitle("Prohibited Uses", isDarkMode),
              _buildSectionContent(
                  "You may use the Service only for lawful purposes and in accordance with these Terms. You agree not to use the Service: In any way that violates any applicable national or international law or regulation. For the purpose of exploiting, harming, or attempting to exploit or harm minors in any way by exposing them to inappropriate content or otherwise. To transmit, or procure the sending of, any advertising or promotional material, including any \"junk mail\", \"chain letter,\" \"spam,\" or any other similar solicitation. To impersonate or attempt to impersonate IntelliNotes, an IntelliNotes employee, another user, or any other person or entity.",
                  isDarkMode),
              _buildSectionTitle("Termination", isDarkMode),
              _buildSectionContent(
                  "We may terminate or suspend your account and bar access to the Service immediately, without prior notice or liability, under our sole discretion, for any reason whatsoever and without limitation, including but not limited to a breach of the Terms. All provisions of the Terms which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity, and limitations of liability.",
                  isDarkMode),
              _buildSectionTitle("Governing Law", isDarkMode),
              _buildSectionContent(
                  "These Terms shall be governed and construed in accordance with the laws of Pakistan, without regard to its conflict of law provisions. Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights. If any provision of these Terms is held to be invalid or unenforceable by a court, the remaining provisions of these Terms will remain in effect.",
                  isDarkMode),
              _buildSectionTitle("Changes", isDarkMode),
              _buildSectionContent(
                  "We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.",
                  isDarkMode),
              _buildSectionTitle("Contact Us", isDarkMode),
              _buildSectionContent(
                  "If you have any questions about these Terms, please contact us at the following number: 0320-4482626",
                  isDarkMode),
            ],
          ),
        ),
      ),
      backgroundColor: AppStyle.getMainColor(isDarkMode),
    );
  }

  Widget _buildSectionTitle(String text, bool isDarkMode) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        text,
        style: GoogleFonts.poppins(
          fontSize: 20.0,
          fontWeight: FontWeight.w500,
          color: AppStyle.getTandCondContainerTextColor(isDarkMode),
        ),
      ),
    );
  }

  Widget _buildLastUpdated(String text, bool isDarkMode) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Text(
        text,
        style: GoogleFonts.poppins(
          fontSize: 14.0,
          color: AppStyle.getTandCondContainerTextColor(isDarkMode),
        ),
      ),
    );
  }

  Widget _buildSectionContent(String text, bool isDarkMode) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: Text(
        text,
        style: GoogleFonts.poppins(
          fontSize: 16.0,
          color: AppStyle.getTandCondContainerTextColor(isDarkMode),
        ),
        textAlign: TextAlign.justify,
      ),
    );
  }
}
