// ignore_for_file: prefer_const_constructors, use_build_context_synchronously

import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:provider/provider.dart';

class SetNewPasswordScreen extends StatefulWidget {
  final String userId; // Assuming you pass the userId to this screen

  const SetNewPasswordScreen({Key? key, required this.userId})
      : super(key: key);

  @override
  _SetNewPasswordScreenState createState() => _SetNewPasswordScreenState();
}

class _SetNewPasswordScreenState extends State<SetNewPasswordScreen> {
  TextEditingController oldPasswordController = TextEditingController();
  TextEditingController newPasswordController = TextEditingController();
  TextEditingController confirmNewPasswordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool isLoading = false;
  String? savedPasswordHash;

  @override
  void initState() {
    super.initState();
    _loadSavedPasswordHash();
  }

  Future<void> _loadSavedPasswordHash() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final userPasswordHashKey = 'notesPasswordHash_${widget.userId}';
    setState(() {
      savedPasswordHash = prefs.getString(userPasswordHashKey);
    });
  }

  Future<void> setNewPassword(String newPassword) async {
    setState(() {
      isLoading = true;
    });
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var bytes = utf8.encode(newPassword);
    var digest = sha256.convert(bytes);
    final userPasswordHashKey = 'notesPasswordHash_${widget.userId}';
    await prefs.setString(userPasswordHashKey, digest.toString());
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("Password changed successfully"),
        backgroundColor: Colors.green, // Set background color to red
        duration: Duration(seconds: 1), // Set duration to 2 seconds
      ),
    );
    Navigator.pop(context);
    setState(() {
      isLoading = false;
    });
  }

  Future<void> showUpdatePasswordDialog(
      BuildContext context, String userId) async {
    TextEditingController newPasswordController = TextEditingController();
    String errorMessage = ''; // To hold the validation error message

    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          // Allows updating the dialog's content
          builder: (BuildContext context, StateSetter setState) {
            return AlertDialog(
              title: const Text("Update Password"),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: newPasswordController,
                      obscureText: true,
                      decoration: InputDecoration(
                        labelText: "New Password",
                        errorText: errorMessage.isNotEmpty
                            ? errorMessage
                            : null, // Display the error message if not empty
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text("Cancel"),
                ),
                TextButton(
                  onPressed: () async {
                    // Mark this callback as async
                    String newPassword = newPasswordController.text;
                    // Validate the new password
                    if (newPassword.isEmpty) {
                      setState(
                          () => errorMessage = 'Please enter a new password');
                    } else if (newPassword.length < 6) {
                      setState(() => errorMessage = "Min 6 characters");
                    } else if (!RegExp(r'(?=.*[A-Z])').hasMatch(newPassword)) {
                      setState(() => errorMessage = "Needs uppercase");
                    } else if (!RegExp(r'(?=.*\d)').hasMatch(newPassword)) {
                      setState(() => errorMessage = 'Needs a digit');
                    } else {
                      // If validation passes, proceed with updating the password
                      var bytes = utf8.encode(newPassword); // Data being hashed
                      var digest = sha256.convert(bytes);
                      final prefs = await SharedPreferences
                          .getInstance(); // This now works with async marked
                      await prefs.setString(
                          'notesPasswordHash_$userId', digest.toString());

                      Navigator.of(context)
                          .pop(); // Close the update password dialog
                      // Show a confirmation dialog
                      showDialog(
                        context: context,
                        barrierDismissible: false,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: const Text("Password Updated"),
                            content: const SingleChildScrollView(
                              child: ListBody(
                                children: <Widget>[
                                  Text(
                                      "Your password has been successfully updated."),
                                ],
                              ),
                            ),
                            actions: <Widget>[
                              TextButton(
                                  child: const Text('OK'),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                    Navigator.of(context).pop();
                                  }),
                            ],
                          );
                        },
                      );
                    }
                  },
                  child: const Text("Update"),
                ),
              ],
            );
          },
        );
      },
    );

    // Optionally do something with the passwordUpdated status outside of the dialog
  }

  bool verifyOldPassword(String enteredPassword) {
    var bytes = utf8.encode(enteredPassword);
    var digest = sha256.convert(bytes);
    return savedPasswordHash == digest.toString();
  }

  void _showForgotPasswordDialog() {
    TextEditingController accountPasswordController = TextEditingController();
    String errorMessage = '';

    showDialog(
      context: context,
      builder: (context) {
        // Use StatefulBuilder to manage dialog state
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return AlertDialog(
              title: const Text("Verify Account Password"),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: accountPasswordController,
                    obscureText: true,
                    decoration: InputDecoration(
                      labelText: "Account Password",
                      // Display the error message if not empty
                      errorText: errorMessage.isNotEmpty ? errorMessage : null,
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text("Cancel"),
                ),
                TextButton(
                  onPressed: () async {
                    bool isVerified = await verifyAccountPassword(
                        accountPasswordController.text);
                    if (isVerified) {
                      Navigator.of(context)
                          .pop(); // Close the dialog on success
                      await showUpdatePasswordDialog(context, widget.userId);
                    } else {
                      // Update the error message state if password verification fails
                      setState(() => errorMessage =
                          'Incorrect password. Please try again.');
                      // Optionally, keep the dialog open for another attempt or provide feedback
                    }
                  },
                  child: const Text("Proceed"),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<bool> verifyAccountPassword(String password) async {
    try {
      User user = FirebaseAuth.instance.currentUser!;
      AuthCredential credential =
          EmailAuthProvider.credential(email: user.email!, password: password);
      await user.reauthenticateWithCredential(credential);
      return true;
    } catch (e) {
      print("Error verifying account password: $e");
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.only(top: 11.0, left: 12),
          child: IconButton(
            icon: Icon(Icons.arrow_back,
                size: 30, color: AppStyle.getBackArroworMenuColor(isDarkMode)),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ),
        title: Padding(
          padding: const EdgeInsets.only(top: 12.0),
          child: Text(
            savedPasswordHash == null ? 'Set New Password' : 'Change Password',
            style: TextStyle(
              fontSize: 23.0,
              fontFamily: GoogleFonts.poppins().fontFamily,
              color: isDarkMode
                  ? Colors.white
                  : Colors.black, // Color changes based on the theme
              fontWeight: FontWeight.normal,
            ),
            // Set the font to Google Fonts Poppins
          ),
        ),
        backgroundColor: AppStyle.getMainColor(isDarkMode),
      ),
      backgroundColor:
          AppStyle.getMainColor(isDarkMode), // Set the background color
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                if (savedPasswordHash != null) ...[
                  TextFormField(
                    controller: oldPasswordController,
                    decoration: InputDecoration(
                      labelText: 'Old Password',
                      labelStyle: GoogleFonts.poppins(
                        color: AppStyle.getTextColor(isDarkMode),
                      ),
                      prefixIcon: Icon(
                        Icons.lock,
                        color: AppStyle.getTextColor(isDarkMode),
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12.0),
                        borderSide: BorderSide(
                          color: Colors.black, // Default border color
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12.0),
                        borderSide: BorderSide(
                          color: AppStyle.getFocusedPasswordBoxColor(
                              isDarkMode), // Focused border color
                        ),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12.0),
                        borderSide: BorderSide(
                          color: Colors.red, // Error border color
                        ),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12.0),
                        borderSide: BorderSide(
                          color: AppStyle.getFocusedPasswordBoxColor(
                              isDarkMode), // Focused error border color
                        ),
                      ),
                      errorStyle: GoogleFonts.poppins(
                        fontSize: 12.0,
                        color: Colors.red, // Error text color
                      ),
                    ),
                    style: TextStyle(
                      color:
                          AppStyle.getTextColor(isDarkMode), // Text input color
                    ),
                    cursorColor:
                        AppStyle.getTextColor(isDarkMode), // Cursor color
                    obscureText: true,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your old password';
                      } else if (!verifyOldPassword(value)) {
                        return 'Old password is incorrect';
                      }
                      return null;
                    },
                  ),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: _showForgotPasswordDialog,
                      child: Text(
                        'Forgot Password?',
                        style: TextStyle(
                          fontSize: 17.0,
                          fontFamily: GoogleFonts.poppins().fontFamily,
                          color: AppStyle.getForgotPasswordColor(
                              isDarkMode), // Set the color directly
                          fontWeight: FontWeight.normal,
                        ),
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 20),
                TextFormField(
                  controller: newPasswordController,
                  decoration: InputDecoration(
                    labelText: 'New Password',
                    prefixIcon: Icon(Icons.lock_open,
                        color: AppStyle.getTextColor(isDarkMode)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: const Color.fromARGB(
                            255, 179, 0, 0), // Default border color
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: AppStyle.getFocusedPasswordBoxColor(
                            isDarkMode), // Focused border color
                      ),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: Colors.red, // Error border color
                      ),
                    ),
                    focusedErrorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: AppStyle.getFocusedPasswordBoxColor(
                            isDarkMode), // Focused error border color
                      ),
                    ),
                    errorStyle: GoogleFonts.poppins(
                      fontSize: 12.0,
                      color: Colors.red, // Error text color
                    ),
                    labelStyle: GoogleFonts.poppins(
                      color: AppStyle.getTextColor(isDarkMode),
                    ),
                  ),
                  style: TextStyle(
                    color: AppStyle.getTextColor(isDarkMode),
                  ),
                  cursorColor: AppStyle.getTextColor(isDarkMode),
                  obscureText: true,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a new password';
                    } else if (value.length < 6) {
                      return 'Password must be at least 6 characters long';
                    } else if (!RegExp(r'(?=.*[A-Z])').hasMatch(value)) {
                      return 'Password must contain at least one uppercase letter';
                    } else if (!RegExp(r'(?=.*\d)').hasMatch(value)) {
                      return 'Password must contain at least one number';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                TextFormField(
                  controller: confirmNewPasswordController,
                  decoration: InputDecoration(
                    labelText: 'Confirm New Password',
                    prefixIcon: Icon(Icons.lock_outline,
                        color: AppStyle.getTextColor(isDarkMode)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: Color.fromARGB(
                            255, 227, 51, 51), // Default border color
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: AppStyle.getFocusedPasswordBoxColor(
                            isDarkMode), // Focused border color
                      ),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: Colors.red, // Error border color
                      ),
                    ),
                    focusedErrorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: AppStyle.getFocusedPasswordBoxColor(
                            isDarkMode), // Focused error border color
                      ),
                    ),
                    errorStyle: GoogleFonts.poppins(
                      fontSize: 12.0,
                      color: Colors.red, // Error text color
                    ),
                    labelStyle: GoogleFonts.poppins(
                      color: AppStyle.getTextColor(
                          isDarkMode), // Set the color of the label text
                    ),
                  ),
                  style: TextStyle(
                    color:
                        AppStyle.getTextColor(isDarkMode), // Text input color
                  ),
                  cursorColor:
                      AppStyle.getTextColor(isDarkMode), // Cursor color
                  obscureText: true,
                  validator: (value) {
                    if (value != newPasswordController.text) {
                      return 'Passwords do not match';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: isLoading
                      ? null
                      : () async {
                          if (_formKey.currentState!.validate()) {
                            await setNewPassword(newPasswordController.text);
                          }
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        AppStyle.getSettingsButtonsButtonBackGroundColor(
                            isDarkMode), // Set background color
                  ),
                  child: isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : Text(
                          savedPasswordHash == null
                              ? 'Set New Password'
                              : 'Change Password',
                          style: TextStyle(
                            color: AppStyle.getSettingsButtonsButtonTextColor(
                                isDarkMode),
                            fontFamily: 'Poppins',
                          ),
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
