import 'package:flutter/material.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:myapp/user_profiles/auth_service.dart';
import 'package:myapp/screens/HomeScreen/homeScreen.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:provider/provider.dart';

class GetStartedPage extends StatelessWidget {
  final String userId;
  const GetStartedPage({required this.userId, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    return Scaffold(
      backgroundColor: AppStyle.getMainColor(isDarkMode),
      body: Padding(
        padding: const EdgeInsets.only(
          left: 16.0,
          right: 16.0,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 30),
                  child: Text(
                    'Intelli\n  Notes',
                    style: GoogleFonts.poppins(
                        fontSize: 45,
                        fontWeight: FontWeight.w400,
                        color: AppStyle.getTextColor(isDarkMode)
                    ),
                  ),
                ),
                const SizedBox(width: 80),
                Container(
                  padding: const EdgeInsets.only(top: 20),
                  child: FaIcon(
                    FontAwesomeIcons.pencil,
                    color: AppStyle.getMainColor(isDarkMode),
                    size: 93,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.only(right: 106.0),
                  child: Container(
                    width: 245,
                    height: 285,
                    decoration: BoxDecoration(
                      color: AppStyle.getMainColor(isDarkMode),
                      borderRadius: BorderRadius.circular(38),
                    ),
                  ),
                ),
                Positioned(
                  top: 0,
                  left: 10,
                  child: Container(
                    width: 245,
                    height: 225,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE06D2D),
                      borderRadius: BorderRadius.circular(38),
                    ),
                  ),
                ),
                Positioned(
                  top: 60,
                  left: 105,
                  child: Container(
                    width: 245,
                    height: 225,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE5DF53),
                      borderRadius: BorderRadius.circular(38),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 15), // Add some space
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: Text(
                'all of your notes, in one place',
                style: GoogleFonts.poppins(
                  fontSize: 30,
                  fontWeight: FontWeight.normal,
                  color: AppStyle.getTextColor(isDarkMode),
                ),
              ),
            ),
            const SizedBox(height: 10), // Add some space
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: Text(
                'jot down on wherever and whatever you want, and  leave the rest upto us',
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.w300,
                  color: AppStyle.getTextColor(isDarkMode),
                ),
              ),
            ),
            const SizedBox(
              height: 20,
              width: 196,
            ),
            GestureDetector(
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) =>  HomeScreen(userId: userId)),
                );
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                decoration: BoxDecoration(
                  color: AppStyle.getStartedPageBox(isDarkMode),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: AppStyle.getTextColor(isDarkMode), width: 2),
                ),
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'Get Started',
                      style: TextStyle(
                        fontFamily: GoogleFonts.poppins().fontFamily,
                        color: AppStyle.getMainPageTextColor(isDarkMode),
                        fontSize: 25,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}