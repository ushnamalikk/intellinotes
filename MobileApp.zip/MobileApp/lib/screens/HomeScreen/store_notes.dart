import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
//
// List<QueryDocumentSnapshot> allNotes = [];
//
// void insertNote(QueryDocumentSnapshot note) {
//   allNotes.add(note);
//
//   // Sort the notes after adding the new note
//   allNotes.sort((a, b) {
//     // First, prioritize pinned notes
//     bool aIsPinned = a['pin'] ?? false;
//     bool bIsPinned = b['pin'] ?? false;
//
//     if (aIsPinned && !bIsPinned) {
//       return -1; // a comes before b
//     } else if (!aIsPinned && bIsPinned) {
//       return 1; // b comes before a
//     }
//
//     final String dateStringA = a['creation_date'] as String;
//     final String dateStringB = b['creation_date'] as String;
//     final DateTime dateTimeA = DateFormat('dd/MM/yy hh:mm:ss a').parse(dateStringA);
//     final DateTime dateTimeB = DateFormat('dd/MM/yy hh:mm:ss a').parse(dateStringB);
//     final comparisonResult = dateTimeB.compareTo(dateTimeA); // Sort in descending order
//     return comparisonResult;
//   });
// }

Map<String, QueryDocumentSnapshot> allNotes = {};

void insertNote(String docId, QueryDocumentSnapshot note) {
  allNotes[docId] = note;

  // Sort the notes after adding the new note
  allNotes = Map.fromEntries(allNotes.entries.toList()
    ..sort((a, b) {
      bool aIsPinned = a.value['pin'] ?? false;
      bool bIsPinned = b.value['pin'] ?? false;

      if (aIsPinned && !bIsPinned) {
        return -1; // a comes before b
      } else if (!aIsPinned && bIsPinned) {
        return 1; // b comes before a
      }

      final String dateStringA = a.value['creation_date'] as String;
      final String dateStringB = b.value['creation_date'] as String;
      final DateTime dateTimeA = DateFormat('dd/MM/yy hh:mm:ss a').parse(dateStringA);
      final DateTime dateTimeB = DateFormat('dd/MM/yy hh:mm:ss a').parse(dateStringB);
      return dateTimeB.compareTo(dateTimeA); // Sort in descending order
    }));
}

void moveNote(String newId, String docId, QueryDocumentSnapshot note) {
  allNotes[newId] = note;
  allNotes.remove(docId);

  // Sort the notes after adding the new note
  allNotes = Map.fromEntries(allNotes.entries.toList()
    ..sort((a, b) {
      bool aIsPinned = a.value['pin'] ?? false;
      bool bIsPinned = b.value['pin'] ?? false;

      if (aIsPinned && !bIsPinned) {
        return -1; // a comes before b
      } else if (!aIsPinned && bIsPinned) {
        return 1; // b comes before a
      }

      final String dateStringA = a.value['creation_date'] as String;
      final String dateStringB = b.value['creation_date'] as String;
      final DateTime dateTimeA = DateFormat('dd/MM/yy hh:mm:ss a').parse(dateStringA);
      final DateTime dateTimeB = DateFormat('dd/MM/yy hh:mm:ss a').parse(dateStringB);
      return dateTimeB.compareTo(dateTimeA); // Sort in descending order
    }));
}

