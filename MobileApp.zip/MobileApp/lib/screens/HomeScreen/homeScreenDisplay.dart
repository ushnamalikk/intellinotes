// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:myapp/screens/Notes%20Display/noteview.dart';
import 'package:myapp/screens/Notes%20Display/notecard.dart';
import 'package:myapp/screens/HomeScreen/store_notes.dart';
import 'package:myapp/screens/widgets/Encryption/note_service.dart';

// Defining the state for the home screen notes display widget
class HomeScreenNotesDisplay extends StatefulWidget {
  final String userId;
  final TextEditingController searchController;
  final Function()? refreshHomeScreen;
  bool isGridView;

  HomeScreenNotesDisplay({
    required this.searchController,
    required this.userId,
    required this.isGridView,
    this.refreshHomeScreen,
    Key? key,
  }) : super(key: key);

  @override
  _HomeScreenNotesDisplayState createState() => _HomeScreenNotesDisplayState();
}

class _HomeScreenNotesDisplayState extends State<HomeScreenNotesDisplay> {
  List<String> categoryNames = [];
  int currentPage = 1;
  int notesPerPage = 10;

  Future<List<QueryDocumentSnapshot>> fetchFilteredNotes(
      BuildContext context) async {
    QuerySnapshot categorySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.userId)
        .collection("Categories")
        .get();

    categoryNames =
        categorySnapshot.docs.map((doc) => doc['Name'] as String).toList();
    if (allNotes.isEmpty) {
      for (QueryDocumentSnapshot categoryDoc in categorySnapshot.docs) {
        QuerySnapshot notesSnapshot =
            await categoryDoc.reference.collection('Notes').get();
        List<QueryDocumentSnapshot> notes = notesSnapshot.docs;

        for (QueryDocumentSnapshot note in notes) {
          String docId = note.id;
          allNotes[docId] = note;
        }
      }

      allNotes = Map.fromEntries(allNotes.entries.toList()
        ..sort((a, b) {
          bool aIsPinned = a.value['pin'] ?? false;
          bool bIsPinned = b.value['pin'] ?? false;

          if (aIsPinned && !bIsPinned) {
            return -1; // a comes before b
          } else if (!aIsPinned && bIsPinned) {
            return 1; // b comes before a
          }

          final String dateStringA = a.value['creation_date'] as String;
          final String dateStringB = b.value['creation_date'] as String;
          final DateTime dateTimeA =
              DateFormat('dd/MM/yy hh:mm:ss a').parse(dateStringA);
          final DateTime dateTimeB =
              DateFormat('dd/MM/yy hh:mm:ss a').parse(dateStringB);
          return dateTimeB.compareTo(dateTimeA); // Sort in descending order
        }));
    }

    return allNotes.values.where((noteDoc) {
      final titleLower = noteDoc['note_title'].toString().toLowerCase();
      final decryptedContent = NoteService().decrypt(noteDoc['note_content']);
      final contentLower = decryptedContent.toString().toLowerCase();
      final queryLower = widget.searchController.text.toLowerCase();
      return titleLower.contains(queryLower) ||
          contentLower.contains(queryLower);
    }).toList();
  }

  Widget buildNotes(
      BuildContext context, List<QueryDocumentSnapshot> filteredNotes) {
    return widget.isGridView
        ? GridView(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
            ),
            children: filteredNotes.map((note) {
              return buildNoteCard(context, note);
            }).toList(),
          )
        : ListView(
            children: filteredNotes.map((note) {
              return buildNoteCard(context, note);
            }).toList(),
          );
  }

  Widget buildNoteCard(BuildContext context, QueryDocumentSnapshot note) {
    return NoteCard(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NoteView(
              doc: note,
              categoryName: note['categoryName'],
              userId: widget.userId,
              homeOrNot: true,
              refreshHomeScreen: widget.refreshHomeScreen,
              categoryList: categoryNames,
            ),
          ),
        );
      },
      note: note,
      userId: widget.userId,
      categoryName: note['categoryName'],
      docId: note.reference.id, // Change note.id to note.reference.id
      homeOrNot: true, // Update homeOrNot to true
      isGrid: widget.isGridView,
      refreshHomeScreen: widget.refreshHomeScreen,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: FutureBuilder<List<QueryDocumentSnapshot>>(
        future: fetchFilteredNotes(context),
        builder: (context,
            AsyncSnapshot<List<QueryDocumentSnapshot>> notesSnapshot) {
          if (notesSnapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (notesSnapshot.hasError) {
            return Text('Errors: ${notesSnapshot.error}');
          }
          if (notesSnapshot.data!.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 80.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    // Replace this with your actual logo widget
                    const Icon(Icons.article_outlined,
                        size: 90.0, color: Colors.grey),
                    Padding(
                      padding: const EdgeInsets.only(
                          top: 10.0), // Adjust the top padding as needed
                      child: Text(
                        'No Notes. Click + button to add new notes',
                        style: TextStyle(
                          fontSize: 16.0,
                          color: Colors
                              .grey, // You would define this method in your AppStyle class
                          fontFamily: GoogleFonts.poppins().fontFamily,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          return buildNotes(context, notesSnapshot.data!);
        },
      ),
    );
  }
}
