// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:myapp/Classes/noteclass.dart';
import 'package:myapp/screens/categories/createCategoryNote.dart';
import 'package:myapp/screens/Deleted%20Notes/deletednotesreen.dart';
import 'package:myapp/screens/categories/categoriesList.dart';
import 'package:myapp/screens/ToDoList/todolist_screen.dart';
import 'package:myapp/screens/App%20Drawer/appDrawer.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:provider/provider.dart';
import 'homeScreenDisplay.dart';
import 'package:myapp/screens/HomeScreen/homeScreenNotifier.dart';
import 'dart:io';
import 'package:myapp/screens/Setting Screen/settingscreen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeScreen extends StatefulWidget {
  final String userId;
  bool? isGrid;
  final Function()?
      refreshHomeScreen; // Make the function optional by using Function()?

  HomeScreen(
      {Key? key, required this.userId, this.isGrid, this.refreshHomeScreen})
      : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Note> notes = [];
  TextEditingController searchController = TextEditingController();
  List<Note> filteredNotes = [];
  final FocusNode _focusNode = FocusNode();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  get isHomeScreen => true;

  @override
  void initState() {
    super.initState();
    widget.isGrid = widget.isGrid ?? true;
    filteredNotes = notes;
    deleteExpiredNotes(widget.userId);
    _loadUserImage();
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    final isRefreshRequired =
        Provider.of<HomeScreenNotifier>(context).refreshRequired;

    if (isRefreshRequired) {
      // Perform any necessary refresh actions here
      // For example, refetch data or update the state
      Provider.of<HomeScreenNotifier>(context, listen: false)
          .setRefreshRequired(false);
    }

    ImageProvider getImageProvider(String userImage) {
      if (userImage.startsWith('http')) {
        return NetworkImage(userImage);
      } else if (userImage != 'assets/images/image.jpeg') {
        return FileImage(File(userImage));
      } else {
        return AssetImage(userImage);
      }
    }

    return Scaffold(
      key: _scaffoldKey,
      drawer: appDrawer(context, widget.userId, "", homescreen: true),
      backgroundColor: AppStyle.getMainColor(isDarkMode),
      floatingActionButton: Container(
        margin: EdgeInsets.only(
          top: MediaQuery.of(context).size.height - (kToolbarHeight + 50),
          right: 12,
        ),
        child: SizedBox(
          height: 56,
          width: 56,
          child: FloatingActionButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => CreateCategoryNote(
                            categoryName: 'Uncategorized',
                            userId: widget.userId,
                            homeOrNot: true,
                            refreshHomeScreen: _refreshHomeScreen,
                          )),
                );
              },
              // ignore: sort_child_properties_last
              child: Icon(
                Icons.add,
                size: 30,
                color: AppStyle.getfloatingButtonColor(isDarkMode),
              ),
              backgroundColor:
                  AppStyle.getfloatingButtonBackgroundColor(isDarkMode)),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: AppStyle.getbottomBarColor(isDarkMode),
        shape: const CircularNotchedRectangle(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            Container(
              decoration: BoxDecoration(
                color: AppStyle.getbottomBarIconSelectionIndication(
                    isDarkMode), // A subtle white overlay indicating selection
                borderRadius:
                    BorderRadius.circular(8), // Rounded corners for aesthetic
              ),
              child: IconButton(
                icon: const Icon(Icons.article, size: 40),
                color: AppStyle.getbottomBarSelectedIconColor(isDarkMode),
                onPressed: () {},
              ),
            ),
            IconButton(
              icon: const Icon(Icons.category_outlined, size: 30),
              color: AppStyle.getbottomBarIconColor(isDarkMode),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => CategoriesList(
                            userId: widget.userId,
                        refreshHomeScreen: _refreshHomeScreen,
                          )),
                );
              },
            ),
            IconButton(
              icon: const Icon(FontAwesomeIcons.listCheck, size: 27),
              color: AppStyle.getbottomBarIconColor(isDarkMode),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => TaskListScreen(
                            userId: widget.userId,
                          )),
                );
              },
            ),
          ],
        ),
      ),
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Padding(
          padding: const EdgeInsets.only(
            top: 20.0,
            left: 16.0,
            right: 16.0,
            bottom: 16.0,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 0.0, top: 12.0), // Add padding as needed
                    child: IconButton(
                      icon: Icon(
                        Icons.menu,
                        color: AppStyle.getLeftDrawerColor(isDarkMode),
                        size: 36,
                      ),
                      onPressed: () {
                        _scaffoldKey.currentState?.openDrawer();
                      },
                    ),
                  ),

                  const SizedBox(width: 16), // Adjust the width as needed
                  Padding(
                    padding: const EdgeInsets.only(
                        top: 12.0), // Add padding from the top as needed
                    child: Text(
                      "All Notes",
                      style: AppStyle.topHeadingTextStyle(isDarkMode),
                    ),
                  ),
                  Spacer(),
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).push(
                        PageRouteBuilder(
                          opaque: false, // Make the route background transparent
                          pageBuilder: (BuildContext context, _, __) {
                            return GestureDetector(
                              onTap: () {
                                Navigator.pop(context); // Pop the route when tapped anywhere on the overlay
                              },
                              child: Container(
                                color: Colors.black54, // Semi-transparent background for better visibility
                                child: Center(
                                  child: ClipOval(
                                    child: Image(
                                      width: 270,
                                      height: 270,
                                      fit: BoxFit.cover, // Preserve aspect ratio and cover the entire area
                                      image: getImageProvider(userImage),
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      );
                    },
                    child: CircleAvatar(
                      radius: 21, // Adjust size as needed
                      backgroundColor: Colors.grey.shade300,
                      backgroundImage: getImageProvider(userImage),
                    ),
                  ),

                ],
              ),
              const SizedBox(
                height: 10,
              ),
              const Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
              ),
              const SizedBox(
                height: 10,
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50),
                  border: Border.all(
                   color: searchController.text.isNotEmpty && _focusNode.hasFocus
                    ? AppStyle.getFocusedSearchBarColor(isDarkMode)
                    : AppStyle.getSearchBarColor(isDarkMode),
                    width: 2,
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: searchController,
                        focusNode: _focusNode,
                        style:
                            TextStyle(color: AppStyle.getTextColor(isDarkMode)),
                        onChanged: (value) {
                          setState(() {});
                        },
                        decoration: InputDecoration(
                          hintText: 'Search notes',
                          hintStyle: TextStyle(
                              color:
                                  AppStyle.getSearchBarTextColor(isDarkMode)),
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: Icon(
                          widget.isGrid ?? true ? Icons.list : Icons.grid_view),
                      color: AppStyle.getnoteViewStyleColor(isDarkMode),
                      onPressed: () {
                        setState(() {
                          widget.isGrid = !(widget.isGrid ??
                              true); // Toggle the value of isGrid
                        });
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 0),
              Expanded(
                  child: HomeScreenNotesDisplay(
                searchController: searchController,
                userId: widget.userId,
                isGridView: widget.isGrid ?? true,
                refreshHomeScreen: _refreshHomeScreen,
              ))
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _loadUserImage() async {
    setState(() {
      userImage =
          'assets/images/image.jpeg'; // Replace with your placeholder image path
    });

    final prefs = await SharedPreferences.getInstance();
    final savedImagePath = prefs.getString('userImagePath_${widget.userId}');
    if (savedImagePath != null) {
      setState(() {
        userImage = savedImagePath;
      });
    }
  }

  void _refreshHomeScreen() {
    // Trigger a refresh of HomeScreen when called
    setState(() {});
  }
}

