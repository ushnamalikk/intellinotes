import 'package:flutter/foundation.dart';

class HomeScreenNotifier extends ChangeNotifier {
  bool refreshRequired = false;

  void setRefreshRequired(bool value) {
    refreshRequired = value;
    notifyListeners();
  }
}
