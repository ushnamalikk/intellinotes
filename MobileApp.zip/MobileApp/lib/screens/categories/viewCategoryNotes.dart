// ignore_for_file: must_be_immutable, library_private_types_in_public_api, use_key_in_widget_constructors

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/screens/categories/createCategoryNote.dart';
import 'package:myapp/screens/HomeScreen/homeScreen.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:provider/provider.dart';
import '../../Classes/noteclass.dart';
import '../widgets/style/app_style.dart';
import '../Deleted Notes/deletednotesreen.dart';
import '../ToDoList/todolist_screen.dart';
import '../App Drawer/appDrawer.dart';
import 'categoriesList.dart';
import 'categoryNotesDisplay.dart';

class ViewCategoryNotes extends StatefulWidget {
  final String categoryName;
  final String userId;
  bool? isGrid;

  ViewCategoryNotes(
      {required this.categoryName, required this.userId, this.isGrid});

  @override
  _ViewCategoryNotesState createState() => _ViewCategoryNotesState();
}

class _ViewCategoryNotesState extends State<ViewCategoryNotes> {
  List<Note> categoryNotes = [];
  late TextEditingController searchController;
  bool isAnyNoteSelected = false;
  List<Note> filteredNotes = [];
  List<String> categories = [];
  final FocusNode _focusNode = FocusNode();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    searchController = TextEditingController();
    filteredNotes = categoryNotes;
    deleteExpiredNotes(widget.userId);
    widget.isGrid = widget.isGrid ?? true;
  }

  void updateSelectionStatus(bool isSelected) {
    setState(() {
      isAnyNoteSelected = isSelected;
    });
  }

  // Method to handle cancel button press
  void handleCancel() {
    setState(() {
      isAnyNoteSelected = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    return Scaffold(
      key: _scaffoldKey,
      drawer: appDrawer(context, widget.userId, widget.categoryName),
      backgroundColor: AppStyle.getMainColor(isDarkMode),
      floatingActionButton: Container(
        margin: EdgeInsets.only(
          top: MediaQuery.of(context).size.height - (kToolbarHeight + 50),
          right: 12,
        ),
        child: SizedBox(
          height: 60,
          width: 60,
          child: FloatingActionButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => CreateCategoryNote(
                        categoryName: widget.categoryName,
                        userId: widget.userId)),
              );
            },
            // ignore: sort_child_properties_last
            child: Icon(
              Icons.add,
              size: 36,
              color: AppStyle.getaddNote_CategoryListButtonColor(isDarkMode),
            ),
            backgroundColor:
                AppStyle.getaddNote_CategoryListBoxColor(isDarkMode),
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: AppStyle.getbottomBarColor(isDarkMode),
        shape: const CircularNotchedRectangle(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            // This is the "Home" button that should appear active
            IconButton(
              icon: Icon(Icons.article_outlined,
                  size: 36, color: AppStyle.getbottomBarIconColor(isDarkMode)),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => HomeScreen(
                            userId: widget.userId,
                          )),
                );
              },
            ),

            IconButton(
              icon: const Icon(Icons.category_outlined, size: 32),
              color: AppStyle.getbottomBarIconColor(isDarkMode),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          CategoriesList(userId: widget.userId)),
                );
              },
            ),
            IconButton(
              icon: const Icon(FontAwesomeIcons.listCheck, size: 28),
              color: AppStyle.getbottomBarIconColor(isDarkMode),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => TaskListScreen(
                            userId: widget.userId,
                          )),
                );
              },
            ),
          ],
        ),
      ),
      body: GestureDetector(
        onTap: () {
          FocusScope.of(context).unfocus();
        },
        child: Padding(
          padding: const EdgeInsets.only(
            top: 30.0,
            left: 16.0,
            right: 16.0,
            bottom: 16.0,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  IconButton(
                    icon: Icon(
                      Icons.menu,
                      color: AppStyle.getLeftDrawerColor(isDarkMode),
                      size: 36,
                    ),
                    onPressed: () {
                      _scaffoldKey.currentState?.openDrawer();
                    },
                  ),
                  const SizedBox(width: 10), // Adjust the width as needed
                  Text(
                    widget.categoryName,
                    style: GoogleFonts.poppins(
                      color: AppStyle.getTextColor(isDarkMode),
                      fontWeight: FontWeight.normal,
                      fontSize: 32,
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              const Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
              ),
              const SizedBox(
                height: 10,
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50),
                  border: Border.all(
                    color: _focusNode.hasFocus
                        ? AppStyle.getFocusedSearchBarColor(isDarkMode)
                        : AppStyle.getSearchBarColor(isDarkMode),
                    width: 2,
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: searchController,
                        focusNode: _focusNode,
                        style:
                            TextStyle(color: AppStyle.getTextColor(isDarkMode)),
                        onChanged: (value) {
                          // Your existing search logic...
                        },
                        decoration: InputDecoration(
                          hintText: 'Search notes',
                          hintStyle: TextStyle(
                              color:
                                  AppStyle.getSearchBarTextColor(isDarkMode)),
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: Icon(
                          widget.isGrid ?? true ? Icons.list : Icons.grid_view),
                      color: AppStyle.getnoteViewStyleColor(isDarkMode),
                      onPressed: () {
                        setState(() {
                          widget.isGrid = !(widget.isGrid ??
                              true); // Toggle the value of isGrid
                        });
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 5),
              Expanded(
                  child: CategoryNotesDisplay(
                searchController: searchController,
                notes: categoryNotes, // Use your notes list
                userId: widget.userId,
                isGridView: widget.isGrid ?? true,
                categoryName: widget.categoryName,
              ))
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }
}
