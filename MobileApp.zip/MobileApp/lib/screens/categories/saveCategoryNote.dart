// ignore_for_file: invalid_return_type_for_catch_error, avoid_print

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:myapp/screens/HomeScreen/store_notes.dart';
import 'package:myapp/screens/widgets/Encryption/note_service.dart';
import '../widgets/Dialogue Boxes/add_category_dialogue.dart';

void saveCategoryNote(title_, body_, date, color_id, categoryName, userId,
    {refresh}) {
  updateCategoryDate(categoryName, userId);
  final title = title_;
  final body = body_;
  if (title.isNotEmpty || body.isNotEmpty) {
    FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection("Categories")
        .where("Name", isEqualTo: categoryName)
        .get()
        .then((QuerySnapshot querySnapshot) {
      if (querySnapshot.docs.isNotEmpty) {
        print("here");
        print(body);
        String encryptedContent = NoteService().encrypt(body);
        print(encryptedContent);
        String categoryId = querySnapshot.docs.first.id;
        FirebaseFirestore.instance
            .collection('users')
            .doc(userId)
            .collection("Categories")
            .doc(categoryId)
            .collection("Notes")
            .add({
          "note_title": title,
          "creation_date": date,
          "note_content": encryptedContent,
          "color_id": color_id,
          "categoryName": categoryName,
          "pin": false,
        }).then((value) async {
          QuerySnapshot notesSnapshot = await FirebaseFirestore.instance
              .collection('users')
              .doc(userId)
              .collection("Categories")
              .doc(categoryId) // Using the ID obtained from the categoryDoc
              .collection('Notes')
              .where(FieldPath.documentId, isEqualTo: value.id)
              .get();
          QueryDocumentSnapshot note = notesSnapshot.docs.first;
          insertNote(value.id, note);
          if (refresh != null) {
            refresh();
          }
        }).catchError((error) => print("Failed to add new Note due to $error"));
      } else {
        String date = DateFormat('dd/MM/yy hh:mm:ss a').format(DateTime.now());
        FirebaseFirestore.instance
            .collection('users')
            .doc(userId)
            .collection("Categories")
            .add({
          "Name": categoryName,
          "date": date,
        }).then((categoryDoc) {
          print("here");
          print(body);
          String encryptedContent = NoteService().encrypt(body);
          print(encryptedContent);
          FirebaseFirestore.instance
              .collection('users')
              .doc(userId)
              .collection("Categories")
              .doc(categoryDoc.id)
              .collection("Notes")
              .add({
            "note_title": title,
            "creation_date": date,
            "note_content": encryptedContent,
            "color_id": color_id,
            "categoryName": categoryName,
            "pin": false,
          }).then((value) async {
            QuerySnapshot notesSnapshot = await FirebaseFirestore.instance
                .collection('users')
                .doc(userId)
                .collection("Categories")
                .doc(categoryDoc
                    .id) // Using the ID obtained from the categoryDoc
                .collection('Notes')
                .where(FieldPath.documentId, isEqualTo: value.id)
                .get();
            QueryDocumentSnapshot note = notesSnapshot.docs.first;
            insertNote(value.id, note);
            if (refresh != null) {
              refresh();
            }
            print("New Note added to new category: ${categoryDoc.id}");
          }).catchError(
                  (error) => print("Failed to add new Note due to $error"));
        }).catchError((error) => print("Error creating new category: $error"));
        // print("Category not found: $categoryName");
      }
    }).catchError((error) => print("Error finding category: $error"));
  }
}
