import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:intl/intl.dart';
import 'package:myapp/screens/HomeScreen/homeScreen.dart';
import 'package:myapp/screens/ToDoList/todolist_screen.dart';
import 'package:myapp/screens/categories/createCategoryNote.dart';
import 'package:myapp/screens/categories/viewCategoryNotes.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:provider/provider.dart';
import 'package:myapp/screens/widgets/Dialogue%20Boxes/add_category_dialogue.dart';
import '../HomeScreen/store_notes.dart';


class CategoriesList extends StatefulWidget {
  final String userId;
  final Function()? refreshHomeScreen;

  CategoriesList({required this.userId, this.refreshHomeScreen});
  @override
  _CategoriesListState createState() => _CategoriesListState();
}

class _CategoriesListState extends State<CategoriesList> {
  bool isDarkMode = false;
  Set<String> selectedNotes = Set<String>(); // Track selected items
  TextEditingController searchController = TextEditingController();
  FocusNode _focusNode = FocusNode(); // Track selected items

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppStyle.getMainColor(isDarkMode),
        leading: Padding(
          padding: const EdgeInsets.only(
              top: 13.0, left: 10), // Adjust the top padding value as needed
          child: IconButton(
            icon: Icon(Icons.arrow_back,
                color: AppStyle.getBackArroworMenuColor(isDarkMode), size: 36),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => HomeScreen(
                          userId: widget.userId,
                        )),
              );
            },
          ),
        ),
        title: Padding(
          padding: const EdgeInsets.only(
            top: 30.0,
            bottom: 15.0,
          ), // Adjust the top padding value as needed
          child: Text(
            'Categories',
            style: AppStyle.topHeadingTextStyle(isDarkMode),
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(
            20.0, // Adjust the height for more or less space
          ),
          child:
              Container(), // This is essentially adding an invisible container to create space
        ),
      ),
      backgroundColor: AppStyle.getMainColor(isDarkMode),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(left: 16.0, right: 16.0, top: 10.0, bottom: 20.0),
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(50),
              border: Border.all(
                color: searchController.text.isNotEmpty && _focusNode.hasFocus
                    ? AppStyle.getFocusedSearchBarColor(isDarkMode)
                    : AppStyle.getSearchBarColor(isDarkMode),
                width: 2,
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: searchController,
                    focusNode: _focusNode,
                    style: TextStyle(color: AppStyle.getTextColor(isDarkMode)),
                    onChanged: (value) {
                      setState(() {});
                    },
                    decoration: InputDecoration(
                      hintText: 'Search categories',
                      hintStyle: TextStyle(
                        color: AppStyle.getSearchBarTextColor(isDarkMode),
                        fontFamily: 'Poppins', // Set the font family to Poppins
                      ),
                      border: InputBorder.none,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.search),
                  color: Colors.black,
                  onPressed: () {},
                ),
              ],
            ),
          ),
          Expanded(
            // Add this Expanded widget to contain the StreamBuilder
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('users')
                  .doc(widget.userId)
                  .collection("Categories")
                  .snapshots(),
              builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                }

                final List<QueryDocumentSnapshot> sortedDocuments =
                    snapshot.data!.docs;
                sortedDocuments.sort((a, b) {
                  final String dateStringA = a['date'] as String;
                  final String dateStringB = b['date'] as String;
                  final DateTime dateTimeA =
                      DateFormat('dd/MM/yy hh:mm:ss a').parse(dateStringA);
                  final DateTime dateTimeB =
                      DateFormat('dd/MM/yy hh:mm:ss a').parse(dateStringB);
                  final comparisonResult = dateTimeB
                      .compareTo(dateTimeA); // Sort in descending order
                  return comparisonResult;
                });

                // Filter categories based on search query
                final List<QueryDocumentSnapshot> filteredDocuments =
                    searchController.text.isEmpty
                        ? sortedDocuments
                        : sortedDocuments.where((doc) {
                            final String categoryName =
                                doc['Name'].toString().toLowerCase();
                            return categoryName
                                .contains(searchController.text.toLowerCase());
                          }).toList();
                if (filteredDocuments.isEmpty) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.only(bottom: 80.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Icon(Icons.category_outlined,
                              size: 90.0, color: Colors.grey),
                          Padding(
                            padding: EdgeInsets.only(top: 10.0),
                            child: Text(
                              'No Categories',
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.grey,
                                // Add your font family here
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }



                return CustomScrollView(
                  slivers: [
                    SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (context, index) {
                          DocumentSnapshot document = filteredDocuments[index];
                          Map<String, dynamic> data =
                              document.data() as Map<String, dynamic>;
                          String categoryName = data['Name'];

                          // Your existing UI code for displaying category list
                          return Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 10.0, horizontal: 16.0),
                            child: Slidable(
                              actionPane: const SlidableDrawerActionPane(),
                              actionExtentRatio: 0.2,
                              secondaryActions: <Widget>[
                                IconSlideAction(
                                  caption: 'Rename',
                                  color: AppStyle.rename,
                                  icon: Icons.edit,
                                  onTap: () async {
                                    await _confirmRename(context, categoryName);
                                  },
                                ),
                                IconSlideAction(
                                  caption: 'Delete',
                                  color: AppStyle.delete,
                                  icon: Icons.delete,
                                  onTap: () async {
                                    await _confirmDelete(context, categoryName);
                                  },
                                ),
                              ],
                              child: GestureDetector(
                                onTap: () {
                                  if (selectedNotes.isNotEmpty) {
                                    if (categoryName != "Uncategorized") {
                                      setState(() {
                                        if (selectedNotes
                                            .contains(categoryName)) {
                                          selectedNotes.remove(categoryName);
                                        } else {
                                          selectedNotes.add(categoryName);
                                        }
                                      });
                                    }
                                  } else {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => ViewCategoryNotes(
                                            userId: widget.userId,
                                            categoryName: categoryName),
                                      ),
                                    );
                                  }
                                },
                                onLongPress: () {
                                  if (categoryName != "Uncategorized") {
                                    setState(() {
                                      if (selectedNotes
                                          .contains(categoryName)) {
                                        selectedNotes.remove(categoryName);
                                      } else {
                                        selectedNotes.add(categoryName);
                                      }
                                    });
                                  }
                                },
                                child: Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.all(16.0),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20.0),
                                    border: Border.all(
                                        color:
                                            AppStyle.getCategoriesBoundaryColor(
                                                isDarkMode)),
                                    color: selectedNotes.contains(categoryName)
                                        ? AppStyle
                                            .getSelectedCategoriesNameColor(
                                                isDarkMode)
                                        : AppStyle
                                            .getNoselectedCategoriesNameColor(
                                                isDarkMode),
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        categoryName,
                                        style: TextStyle(
                                          color: AppStyle
                                              .getCategoriesNameTextColor(
                                                  isDarkMode),
                                          fontSize: 20.0,
                                        ),
                                      ),
                                      if (selectedNotes.isEmpty)
                                        GestureDetector(
                                          onTap: () {
                                            Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    CreateCategoryNote(
                                                  userId: widget.userId,
                                                  categoryName: categoryName,
                                                ),
                                              ),
                                            );
                                          },
                                          child: Container(
                                            padding: const EdgeInsets.all(8),
                                            decoration: BoxDecoration(
                                              shape: BoxShape.circle,
                                              color: AppStyle
                                                  .getaddNote_CategoryListBoxColor(
                                                      isDarkMode),
                                            ),
                                            child: Icon(
                                              Icons.add,
                                              color: AppStyle
                                                  .getaddNote_CategoryListButtonColor(
                                                      isDarkMode),
                                            ),
                                          ),
                                        ),
                                      if (categoryName == "Uncategorized" &&
                                          selectedNotes.isNotEmpty)
                                        Container(
                                          padding: const EdgeInsets.all(6),
                                          decoration: const BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: Colors
                                                .green, // Green color for the lock icon
                                          ),
                                          child: const Icon(
                                            Icons.lock_outline_rounded,
                                            color: Colors.white,
                                            size: 25,
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                        childCount: filteredDocuments.length,
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(right: 12.0, bottom: 0.0),
        child: selectedNotes.isEmpty
            ? FloatingActionButton(
                onPressed: () {
                  showAddCategoryDialog(context, widget.userId);
                },
                child: const Icon(Icons.add, size: 30),
                backgroundColor:
                    AppStyle.getfloatingButtonBackgroundColor(isDarkMode),
                foregroundColor: AppStyle.getfloatingButtonColor(isDarkMode),
              )
            : FloatingActionButton(
                onPressed: () {
                  List<String> keysToRemove = [];
                  for (var selectedNote in selectedNotes.toList()) {
                    allNotes.forEach((key, value) {
                      if ((value.data() as Map<String, dynamic>)?["categoryName"] == selectedNote) {
                        keysToRemove.add(key);
                      }
                    });
                  }
                  keysToRemove.forEach((key) {
                    allNotes.remove(key);
                  });
                  _deleteSelectedCategories(context);
                },
                child: const Icon(Icons.delete, size: 30),
                backgroundColor:
                    AppStyle.getfloatingButtonBackgroundColor(isDarkMode),
                foregroundColor: AppStyle.getfloatingButtonColor(isDarkMode),
              ),
      ),
      bottomNavigationBar: AnimatedSwitcher(
        duration: const Duration(milliseconds: 50),
        child: selectedNotes.isEmpty
            ? BottomAppBar(
                color: AppStyle.getbottomBarColor(isDarkMode),
                shape: const CircularNotchedRectangle(),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    IconButton(
                      icon: Icon(Icons.article_outlined,
                          size: 36,
                          color: AppStyle.getbottomBarIconColor(isDarkMode)),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => HomeScreen(
                                    userId: widget.userId,
                                  )),
                        );
                      },
                    ),
                    Container(
                      decoration: BoxDecoration(
                        color: AppStyle.getbottomBarIconSelectionIndication(
                            isDarkMode),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: IconButton(
                        icon: const Icon(Icons.category_outlined, size: 38),
                        color:
                            AppStyle.getbottomBarSelectedIconColor(isDarkMode),
                        onPressed: () {},
                      ),
                    ),
                    IconButton(
                      icon: Icon(FontAwesomeIcons.listCheck,
                          size: 28,
                          color: AppStyle.getbottomBarIconColor(isDarkMode)),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  TaskListScreen(userId: widget.userId)),
                        );
                      },
                    ),
                  ],
                ),
              )
            : const SizedBox(), // If selectedNotes is not empty, hide the BottomAppBar
      ),
    );
  }

  void _deleteCategory(BuildContext context, String categoryName) {
    FirebaseFirestore.instance
        .collection('users')
        .doc(widget.userId)
        .collection('Categories')
        .where('Name', isEqualTo: categoryName)
        .get()
        .then((querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        doc.reference.delete();
      });
      setState(() {
        selectedNotes.remove(categoryName);
      });
    }).catchError((error) {
      showErrorMessage(context, 'Failed to delete category. Please try again.');
    });
  }

  Future<void> _deleteSelectedCategories(BuildContext context) async {
    selectedNotes.forEach((categoryName) {
      _deleteCategory(context, categoryName);
    });
    setState(() {
      selectedNotes.clear();
    });
  }

  Future<bool> _confirmDelete(BuildContext context, String categoryName) async {
    return await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirm Deletion'),
          content: Text('Are you sure you want to delete $categoryName?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(false);
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                _deleteCategory(context, categoryName);
                Navigator.of(context).pop(true);
              },
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );
  }

  Future<bool> _confirmRename(BuildContext context, String categoryName) async {
    TextEditingController renameController = TextEditingController();
    renameController.text = categoryName;

    return await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Rename Category'),
          content: TextField(
            controller: renameController,
            decoration:
                const InputDecoration(hintText: 'Enter New Category Name'),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(false);
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                String newCategoryName = renameController.text.trim();
                if (newCategoryName.isNotEmpty) {
                  _renameCategory(context, categoryName, newCategoryName);
                } else {
                  showErrorMessage(context, 'Category name cannot be empty.');
                }
              },
              child: const Text('Rename'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _renameCategory(
      BuildContext context, String oldCategoryName, String newCategoryName) async {
    if (oldCategoryName.toLowerCase() == newCategoryName.toLowerCase()) {
      Navigator.of(context).pop();
    }
    await FirebaseFirestore.instance
        .collection('users')
        .doc(widget.userId)
        .collection('Categories')
        .where('Name', isEqualTo: newCategoryName.toLowerCase())
        .get()
        .then((querySnapshot) async {
      if (querySnapshot.docs.isEmpty) {
        await FirebaseFirestore.instance
            .collection('users')
            .doc(widget.userId)
            .collection('Categories')
            .where('Name', isEqualTo: oldCategoryName)
            .get()
            .then((querySnapshot) {
          querySnapshot.docs.forEach((doc) async {

            QuerySnapshot notesSnapshot = await doc.reference.collection('Notes').get();
            notesSnapshot.docs.forEach((noteDoc) async {
              // Update each note's categoryName to newCategoryName
              await noteDoc.reference.update({'categoryName': newCategoryName});
              QuerySnapshot notesSnapshot = await FirebaseFirestore.instance
                  .collection('users')
                  .doc(widget.userId)
                  .collection("Categories")
                  .doc(doc.id) // Using the ID obtained from the categoryDoc
                  .collection('Notes')
                  .where(FieldPath.documentId, isEqualTo: noteDoc.id)
                  .get();
              QueryDocumentSnapshot note = notesSnapshot.docs.first;
              insertNote(noteDoc.id, note);
              widget.refreshHomeScreen!();
            });

            await doc.reference.update({'Name': newCategoryName});
          });
        }).catchError((error) {
          showErrorMessage(
              context, 'Failed to rename category. Please try again.');
        });
      } else {
        showErrorMessage(context, 'Category with the new name already exists.');
      }
    }).catchError((error) {
      showErrorMessage(context, 'Failed to rename category. Please try again.');
    });
    Navigator.of(context).pop();
  }
}
