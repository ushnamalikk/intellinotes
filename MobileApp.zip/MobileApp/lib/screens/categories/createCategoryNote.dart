// ignore_for_file: must_be_immutable, avoid_print

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart'; // Import DateFormat class
import 'package:myapp/screens/categories/saveCategoryNote.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:myapp/screens/Note/note_options.dart';

import '../widgets/Dialogue Boxes/add_category_dialogue.dart';

class CreateCategoryNote extends StatefulWidget {
  final String userId;
  String categoryName;
  final bool? homeOrNot;
  final Function()? refreshHomeScreen;

  CreateCategoryNote({
    Key? key,
    required this.categoryName,
    required this.userId,
    this.homeOrNot,
    this.refreshHomeScreen,
  }) : super(key: key);

  @override
  State<CreateCategoryNote> createState() => _CreateNoteState();
}

class _CreateNoteState extends State<CreateCategoryNote> {
  int colorId = 7;
  String date = DateFormat('dd/MM/yy hh:mm:ss a').format(DateTime.now().subtract(Duration(days: 2)));
  TextEditingController titleController = TextEditingController();
  TextEditingController mainController = TextEditingController();
  int wordcount = 0;
  bool showColorPicker = false; // State to control visibility of color picker
  bool showNoteOptions = false; // State to control visibility of note options
  String? _selectedCategory;
  List<String> categoryList = [];


  @override
  void initState() {
    super.initState();
    fetchCategoryNames();
    _selectedCategory = widget.categoryName;
  }

  Future<void> fetchCategoryNames() async {
    try {
      QuerySnapshot categorySnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.userId)
          .collection("Categories")
          .get();

      List<String> names =
          categorySnapshot.docs.map((doc) => doc['Name'] as String).toList();
      setState(() {
        categoryList = names; // Update categoryList with fetched category names
      });
    } catch (e) {
      print("Error fetching categories: $e");
      // Handle error if fetching categories fails
    }
  }

  @override
  void dispose() {
    titleController.dispose();
    mainController.dispose();
    super.dispose();
  }

  void _onCategorySelected(String? newValue, bool newCat) {
    setState(() {
      if (newCat) {
        _selectedCategory = newValue;
        widget.categoryName = _selectedCategory!;
      } else {
        _selectedCategory = widget.categoryName;
        Navigator.of(context).pop();
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => CreateCategoryNote(
                    categoryName: _selectedCategory!,
                    userId: widget.userId,
                    homeOrNot: true,
                  )),
        );
      }
    });
  }

  void updateWordCount() {
    setState(() {
      wordcount = mainController.text
          .split(RegExp(r'\s+'))
          .where((s) => s != "")
          .length;
    });
  }

  void saveNote() {
    saveCategoryNote(
      titleController.text.trim(),
      mainController.text.trim(),
      date,
      colorId,
      _selectedCategory!,
      widget.userId,
      refresh: widget.refreshHomeScreen,
    );
    // widget.refreshHomeScreen!();
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final colorBoxWidth = screenWidth / 7; // Adjust to display 7 items at once

    String abc = date;
    DateTime creationDate = DateFormat('dd/MM/yy hh:mm:ss a').parse(abc);
    DateTime now = DateTime.now();
    Duration difference = now.difference(creationDate);
    String formattedDate;
    if (difference.inHours < 24) {
      formattedDate = DateFormat('hh:mm a').format(creationDate); // Show only hours and minutes
    } else {
      formattedDate = DateFormat('dd/MM/yy hh:mm a').format(creationDate); // Show whole date and time
    }

    return Scaffold(
      backgroundColor: AppStyle.cardsColor[colorId],
      appBar: AppBar(
        backgroundColor: AppStyle.cardsColor[colorId],
        elevation: 0.0,
        toolbarHeight: 30,
        iconTheme: const IconThemeData(color: Colors.black),
        title: TextFormField(
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.only(
                top: 14.0), // Adjust the top padding as needed
            border: InputBorder.none,
            hintText: "Add a New Note",
            hintStyle: TextStyle(
              color: Colors.black.withOpacity(0.6),
              fontSize: 19,
              fontFamily: GoogleFonts.poppins().fontFamily,
            ),
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            final String title = titleController.text.trim();
            final String content = mainController.text.trim();
            if (title.isNotEmpty || content.isNotEmpty) {
              saveNote();
            }
            Navigator.of(context).pop();
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete, color: Colors.black),
            onPressed: () {
              deleteNoteAndDiscard(context);
            },
          ),
          IconButton(
            icon: const Icon(Icons.palette, color: Colors.black),
            onPressed: () {
              setState(() {
                showColorPicker =
                    !showColorPicker; // Toggle color picker visibility
              });
            },
          ),
          IconButton(
            icon: const Icon(Icons.android,
                color: Colors.black), // Robot icon for note options
            onPressed: () {
              setState(() {
                showNoteOptions =
                    !showNoteOptions; // Toggle note options visibility
              });
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: titleController,
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: 'Title',
                hintStyle: TextStyle(
                    color: Colors.black45,
                    fontSize: 28,
                    fontFamily: GoogleFonts.poppins().fontFamily),
              ),
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  fontFamily: GoogleFonts.poppins().fontFamily),
            ),
            if (widget.homeOrNot ?? false) ...[
              Container(
                height: 36,
                width: 142,
                decoration: BoxDecoration(
                  color: Colors.black45.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(
                      25.0), // Adjust the border radius as needed
                  border: Border.all(color: Colors.black45.withOpacity(0.7)),
                ),
                child: SingleChildScrollView(
                  physics:
                      const AlwaysScrollableScrollPhysics(), // Ensure the dropdown menu is always scrollable
                  child: DropdownButtonFormField<String>(
                    borderRadius: BorderRadius.circular(25),
                    value: _selectedCategory,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12.2,
                      height: 1.5,
                    ),
                    padding: EdgeInsets.zero, // Remove internal padding
                    icon: const Padding(
                      padding: EdgeInsets.only(
                          top: 0), // Add bottom padding to the dropdown arrow
                      child: Icon(
                          Icons.arrow_drop_down_sharp), // Dropdown arrow icon
                    ), // Dropdown arrow icon
                    iconSize: 15, // Adjust the icon size as needed
                    iconEnabledColor:
                        Colors.white, // Color of the dropdown arrow
                    dropdownColor: Colors.black45.withOpacity(
                        0.7), // Background color of the dropdown menu
                    decoration: const InputDecoration(
                      border: InputBorder
                          .none, // Remove the border around the dropdown field
                      contentPadding: EdgeInsets.fromLTRB(
                          14, 0, 10, 16), // Adjust the internal content padding
                    ),
                    items: [
                      DropdownMenuItem<String>(
                        value: _selectedCategory,
                        child: Text("$_selectedCategory"),
                      ),
                      ...categoryList
                          .where((category) => category != _selectedCategory)
                          .map((category) {
                        return DropdownMenuItem<String>(
                          value: category,
                          child: Text(
                            style: TextStyle(
                                fontFamily: GoogleFonts.poppins().fontFamily),
                            category,
                            overflow: TextOverflow
                                .ellipsis, // Ellipsis for long texts
                            maxLines: 1, // Display only one line of text
                          ),
                        );
                      }),
                      DropdownMenuItem<String>(
                        value: 'Create New Category',
                        child: Row(
                          children: [
                            const Icon(
                              Icons.add,
                              size: 15,
                            ), // Add the prefix icon here
                            const SizedBox(
                                width:
                                    8), // Add some spacing between the icon and text
                            Expanded(
                              child: Text(
                                'Add Category',
                                style: TextStyle(
                                    fontFamily:
                                        GoogleFonts.poppins().fontFamily),
                                overflow: TextOverflow
                                    .ellipsis, // Set overflow property
                                maxLines: 1, // Set maxLines property
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                    onChanged: (newValue) async {
                      String newCategory = newValue!;
                      if (newValue == 'Create New Category') {
                        print(newCategory);
                        newCategory =
                            await showAddCategoryDialog(context, widget.userId);
                        print(newCategory);
                        if (newCategory.isNotEmpty) {
                          categoryList.add(newCategory);
                          _onCategorySelected(newCategory, true);
                        } else {
                          _onCategorySelected(widget.categoryName, false);
                        }
                      } else {
                        _onCategorySelected(newCategory, true);
                      }
                      setState(() {});
                    },
                    isExpanded:
                        true, // Ensure the dropdown button expands to fit the content
                    menuMaxHeight: 300,
                  ),
                ),
              ),
            ],
            const SizedBox(height: 16.0),
            Text(formattedDate,
                style: TextStyle(
                    color: Colors.black45,
                    fontFamily: GoogleFonts.poppins().fontFamily)),
            const SizedBox(height: 8.0),
            Expanded(
              child: TextField(
                controller: mainController,
                onChanged: (value) => updateWordCount(),
                keyboardType: TextInputType.multiline,
                maxLines: null,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: 'Note something down',
                  hintStyle: TextStyle(
                      color: Colors.black45,
                      fontFamily: GoogleFonts.poppins().fontFamily),
                ),
                style: TextStyle(
                    color: Colors.black,
                    fontFamily: GoogleFonts.poppins().fontFamily),
              ),
            ),
            Align(
              alignment: Alignment.bottomRight,
              child: Visibility(
                visible: wordcount > 0,
                child: Text('$wordcount words',
                    style: TextStyle(
                        color: Colors.black45,
                        fontSize: 16,
                        fontFamily: GoogleFonts.poppins().fontFamily)),
              ),
            ),
            if (showColorPicker) ...[
              const SizedBox(height: 20), // Spacing before the color picker
              Container(
                height: 30, // Fixed height for the color picker
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: AppStyle.cardsColor.length,
                  separatorBuilder: (context, index) =>
                      const SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          colorId = index; // Update the selected color
                          showColorPicker =
                              true; // Optionally hide the picker after selection
                        });
                      },
                      child: Container(
                        width: colorBoxWidth -
                            8, // Adjust width as per requirement
                        decoration: BoxDecoration(
                          color: AppStyle.cardsColor[index],
                          borderRadius: BorderRadius.circular(100),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
            if (showNoteOptions) ...[
              NoteOptions(
                onParaphrase: (text) {},
                titleController: titleController,
                contentController: mainController,
                docId: '',
                userId: widget.userId,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

Future<void> deleteNoteAndDiscard(BuildContext context) async {
  final confirmed = await _showConfirmationDialog(context);
  if (confirmed != null && confirmed) {
    Navigator.pop(context);
  }
}

Future<bool?> _showConfirmationDialog(BuildContext context) async {
  return showDialog<bool>(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text("Discard Note?",
            style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
        content: Text("Are you sure you want to discard this note?",
            style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text("Cancel",
                style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text("Discard",
                style: TextStyle(fontFamily: GoogleFonts.poppins().fontFamily)),
          ),
        ],
      );
    },
  );
}
