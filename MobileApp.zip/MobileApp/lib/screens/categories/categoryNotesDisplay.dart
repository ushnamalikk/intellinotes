import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/Classes/noteclass.dart';
import 'package:myapp/screens/Notes%20Display/notecardCategory.dart';
import 'package:myapp/screens/Notes%20Display/noteview.dart';
import 'package:myapp/screens/widgets/Encryption/note_service.dart';

class CategoryNotesDisplay extends StatelessWidget {
  final String userId;
  final TextEditingController searchController;
  final List<Note> notes;
  final bool isGridView;
  final String categoryName;

  const CategoryNotesDisplay({
    required this.searchController,
    required this.notes,
    required this.userId,
    required this.isGridView,
    required this.categoryName,
    Key? key,
  }) : super(key: key);

  Future<List<String>> fetchCategoryNames() async {
    List<String> categoryNames = [];
    QuerySnapshot categorySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection("Categories")
        .get();

    categoryNames =
        categorySnapshot.docs.map((doc) => doc['Name'] as String).toList();
    return categoryNames;
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: FutureBuilder<List<String>>(
        future: fetchCategoryNames(),
        builder: (context, AsyncSnapshot<List<String>> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Text('Error: ${snapshot.error}');
          }
          if (snapshot.data!.isEmpty) {
            return const Center(child: Text('No categories found'));
          }

          return StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance
                .collection('users')
                .doc(userId)
                .collection("Categories")
                .where("Name", isEqualTo: categoryName)
                .snapshots(),
            builder: (context, AsyncSnapshot<QuerySnapshot> categorySnapshot) {
              if (categorySnapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (categorySnapshot.hasError) {
                return Text('Error: ${categorySnapshot.error}');
              }
              if (categorySnapshot.data!.docs.isEmpty) {
                return const Center(child: Text('Category not found'));
              }

              final categoryDoc = categorySnapshot.data!.docs.first;
              final categoryRef = categoryDoc.reference;

              return StreamBuilder<QuerySnapshot>(
                stream: categoryRef.collection('Notes').snapshots(),
                builder: (context, AsyncSnapshot<QuerySnapshot> notesSnapshot) {
                  if (notesSnapshot.connectionState ==
                      ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (notesSnapshot.hasError) {
                    return Text('Error: ${notesSnapshot.error}');
                  }
                  if (notesSnapshot.data!.docs.isEmpty) {
                    return Center(
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 80.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            // Replace this with your actual logo widget
                             const Icon(Icons.article_outlined,
                                size: 90.0, color: Colors.grey),
                            Padding(
                              padding: const EdgeInsets.only(
                                  top:
                                      10.0), // Adjust the top padding as needed
                              child: Text(
                                'No Notes. Click + button to add new notes',
                                style: TextStyle(
                                  fontSize: 16.0,
                                  color: Colors
                                      .grey, // You would define this method in your AppStyle class
                                  fontFamily: GoogleFonts.poppins().fontFamily,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ); // Set text color to black
                  }

                  final filteredNotes =
                      notesSnapshot.data!.docs.where((noteDoc) {
                    final titleLower =
                        noteDoc['note_title'].toString().toLowerCase();
                    final decryptedContent =
                        NoteService().decrypt(noteDoc['note_content']);
                    final contentLower =
                        decryptedContent.toString().toLowerCase();
                    final queryLower = searchController.text.toLowerCase();
                    return titleLower.contains(queryLower) ||
                        contentLower.contains(queryLower);
                  }).toList();

                  final sortedNotes = filteredNotes.toList();
                  sortedNotes.sort((a, b) {
                    // First, prioritize pinned notes
                    bool aIsPinned = a['pin'] ?? false;
                    bool bIsPinned = b['pin'] ?? false;

                    if (aIsPinned && !bIsPinned) {
                      return -1; // a comes before b
                    } else if (!aIsPinned && bIsPinned) {
                      return 1; // b comes before a
                    }

                    // If both are pinned or both are not pinned, sort by creation date
                    // Assuming creation_date is in a format that can be directly compared as strings
                    return b['creation_date'].compareTo(a['creation_date']);
                  });

                  return buildView(sortedNotes, context, snapshot.data!);
                },
              );
            },
          );
        },
      ),
    );
  }

  Widget buildView(List<QueryDocumentSnapshot> notes, BuildContext context,
      List<String> categoryNames) {
    if (isGridView) {
      return GridView(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
        ),
        children: notes
            .map((note) => _buildNoteCard(note, context, categoryNames))
            .toList(),
      );
    } else {
      return ListView(
        children: notes
            .map((note) => _buildNoteCard(note, context, categoryNames))
            .toList(),
      );
    }
  }

  Widget _buildNoteCard(
      QueryDocumentSnapshot note, context, List<String> categoryNames) {
    return NoteCardCatergory(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => NoteView(
              doc: note,
              categoryName: categoryName,
              userId: userId,
              categoryList: categoryNames,
            ),
          ),
        );
      },
      note: note,
      userId: userId,
      categoryName: note['categoryName'],
      docId: note.reference.id, // Change note.id to note.reference.id
      homeOrNot: false, // Update homeOrNot to true
      isGrid: isGridView,
    );
  }
}
