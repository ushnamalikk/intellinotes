// ignore_for_file: avoid_unnecessary_containers, prefer_const_constructors, sort_child_properties_last

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/screens/HomeScreen/homeScreen.dart';
import 'package:myapp/screens/ToDoList/add_task_screen.dart';
import 'package:intl/intl.dart';
import 'package:myapp/screens/categories/categoriesList.dart';
import 'package:myapp/screens/widgets/Dark Mode/dark_mode_provider.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:provider/provider.dart';
import 'package:myapp/screens/App%20Drawer/appDrawer.dart';
import 'package:awesome_notifications/awesome_notifications.dart';

class TaskListScreen extends StatefulWidget {
  final String userId;
  TaskListScreen({required this.userId});

  @override
  _TaskListScreenState createState() => _TaskListScreenState();
}

class _TaskListScreenState extends State<TaskListScreen> {
  void cancelTaskNotifications(String taskId) {
    List<int> notificationIdsToRemove = [];
    notificationIds.forEach((key, value) {
      if (key.startsWith('$taskId')) {
        AwesomeNotifications().cancel(value);
        notificationIdsToRemove.add(value);
      }
    });
    notificationIdsToRemove.forEach((id) {
      notificationIds.removeWhere((key, value) => value == id);
    });
  }

  void _markAsCompleted(DocumentSnapshot task) {
    var completedOn = Timestamp.now();
    var taskData = task.data() as Map<String, dynamic>;
    taskData['completedOn'] = completedOn;
    FirebaseFirestore.instance
        .collection('users')
        .doc(widget.userId)
        .collection('completed_tasks')
        .add(taskData)
        .then((docRef) {
      // Cancel notification for the completed task
      cancelTaskNotification(task.id);
    });
    FirebaseFirestore.instance
        .collection('users')
        .doc(widget.userId)
        .collection('active_tasks')
        .doc(task.id)
        .delete();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Task marked as completed successfully'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _deleteTask(DocumentSnapshot task, String collection) {
    FirebaseFirestore.instance
        .collection('users')
        .doc(widget.userId)
        .collection(collection)
        .doc(task.id)
        .delete()
        .then((value) {
      // Cancel notification for the deleted task
      cancelTaskNotification(task.id);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Task deleted successfully'),
        backgroundColor: Colors.green,
      ),
    );
  }

  StreamBuilder<QuerySnapshot> _buildTaskList(
      String collection, bool isCompleted) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    Stream<QuerySnapshot> taskStream;
    if (isCompleted) {
      taskStream = FirebaseFirestore.instance
          .collection('users')
          .doc(widget.userId)
          .collection(collection)
          .orderBy('completedOn', descending: true)
          .snapshots();
    } else {
      taskStream = FirebaseFirestore.instance
          .collection('users')
          .doc(widget.userId)
          .collection(collection)
          .orderBy('createdAt', descending: true)
          .snapshots();
    }
    return StreamBuilder<QuerySnapshot>(
      stream: taskStream,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          // return Center(
          // child: Text('No ${isCompleted ? 'completed' : 'active'} tasks',
          //     style: GoogleFonts.poppins(
          //         color: AppStyle.getTextColor(isDarkMode),
          //         fontWeight:
          //             FontWeight.normal)));

          return Center(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 80.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  // Replace this with your actual logo widget
                  const Icon(Icons.task_alt_sharp,
                      size: 50.0, color: Colors.grey),
                  Padding(
                    padding: const EdgeInsets.only(
                        top: 10.0), // Adjust the top padding as needed
                    child: Text(
                      'No ${isCompleted ? 'completed' : 'active'} tasks',
                      style: TextStyle(
                        fontSize: 16.0,
                        color: Colors
                            .grey, // You would define this method in your AppStyle class
                        fontFamily: GoogleFonts.poppins().fontFamily,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ); // Set text color to black
        }

        return ListView(
          shrinkWrap: true,
          physics:
              AlwaysScrollableScrollPhysics(), // Make the list always scrollable
          children: snapshot.data!.docs.map((DocumentSnapshot document) {
            Map<String, dynamic> task = document.data() as Map<String, dynamic>;

            // Determine if the task is active or completed based on isCompleted flag
            bool isActive = !isCompleted;

            return Dismissible(
              key: Key(document.id),
              background: Container(
                  color: Colors.red,
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  child: const Icon(Icons.delete, color: Colors.white)),
              direction: DismissDirection.endToStart,
              onDismissed: (direction) => _deleteTask(document, collection),
              child: Card(
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                child: ListTile(
                  onLongPress: () {
                    if (isActive) {
                      // Modal sheet for active tasks
                      showModalBottomSheet(
                        context: context,
                        builder: (BuildContext context) {
                          return Container(
                            child: Wrap(
                              children: <Widget>[
                                ListTile(
                                  leading: Icon(Icons.check_circle),
                                  title: Text('Mark as completed'),
                                  onTap: () {
                                    _markAsCompleted(
                                        document); // Mark the task as completed
                                    Navigator.pop(
                                        context); // Dismiss the bottom sheet after the action
                                  },
                                ),
                                ListTile(
                                  leading: Icon(Icons.delete),
                                  title: Text('Delete task'),
                                  onTap: () {
                                    _deleteTask(document,
                                        collection); // Delete the task
                                    Navigator.pop(
                                        context); // Dismiss the bottom sheet after the action
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      );
                    } else {
                      // Modal sheet for completed tasks
                      showModalBottomSheet(
                          context: context,
                          builder: (BuildContext context) {
                            return Container(
                              child: Wrap(
                                children: <Widget>[
                                  ListTile(
                                    leading: Icon(Icons.delete),
                                    title: Text('Delete task'),
                                    onTap: () {
                                      _deleteTask(document,
                                          'completed_tasks'); // Delete the task
                                      Navigator.pop(
                                          context); // Dismiss the bottom sheet after the action
                                    },
                                  ),
                                ],
                              ),
                            );
                          });
                    }
                  },

                  title: Text(task['title'],
                      style: GoogleFonts.poppins(
                          fontWeight: FontWeight.bold,
                          color: Colors.black)), // Set text color to black
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(task['details'],
                          style: GoogleFonts.poppins(
                              color: Colors.black)), // Set text color to black
                      const SizedBox(height: 4),
                      isActive
                          ? Text(
                              'Target Date: ${DateFormat('dd/MM/yyyy HH:mm').format(task['date'].toDate())}', // For active tasks, show target date and time
                              style: GoogleFonts.poppins(
                                  color:
                                      Colors.black), // Set text color to black
                            )
                          : Text(
                              'Completed On: ${DateFormat('dd/MM/yyyy HH:mm').format(task['completedOn'].toDate())}', // Convert Firestore Timestamp to DateTime and format it
                              style: GoogleFonts.poppins(
                                  color:
                                      Colors.black), // Set text color to black
                            ),
                    ],
                  ),
                  trailing: isCompleted
                      ? const Icon(Icons.check_circle,
                          color: Colors.green) // Completed task icon in grey
                      : IconButton(
                          icon: Icon(Icons.check_circle_outline,
                              color: Colors.green),
                          onPressed: () => _markAsCompleted(document),
                        ),
                  onTap:
                      null, // Removed the onTap function to prevent the entire tile from marking the task as complete
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                color: Color(task['color']),
              ),
            );
          }).toList(),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 72.0,
        leading: Builder(
          builder: (context) => Padding(
            padding: const EdgeInsets.only(
                left: 10.0, top: 2), // Adjust the padding value as needed
            child: IconButton(
              icon: Icon(Icons.menu,
                  color: AppStyle.getBackArroworMenuColor(isDarkMode)),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
        ),
        title: Align(
          alignment: Alignment(-1.0, -0.9),
          child: Text(
            'To-Do List',
            style: GoogleFonts.poppins(
              fontSize: 32.0,
              color: AppStyle.getTextColor(isDarkMode),
            ),
          ),
        ),
        iconTheme: IconThemeData(size: 35),
        backgroundColor: AppStyle.getMainColor(isDarkMode),
      ),
      drawer: appDrawer(context, widget.userId, ""),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Active Tasks',
              style: TextStyle(
                fontFamily: GoogleFonts.poppins().fontFamily,
                fontSize: 22,
                fontWeight: FontWeight.w500,
                color: AppStyle.getTextColor(isDarkMode),
              ),
            ),
          ),
          Expanded(
            child: Container(
              child: _buildTaskList('active_tasks', false),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Completed Tasks',
              style: TextStyle(
                fontFamily: GoogleFonts.poppins().fontFamily,
                fontSize: 22,
                fontWeight: FontWeight.w500,
                color: AppStyle.getTextColor(isDarkMode),
              ),
            ),
          ),
          Expanded(
            child: Container(
              child: _buildTaskList('completed_tasks', true),
            ),
          ),
        ],
      ),
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(right: 12.0, bottom: 0.0),
        child: FloatingActionButton(
          onPressed: () {
            showModalBottomSheet(
              context: context,
              builder: (BuildContext context) {
                return Container(
                  padding: const EdgeInsets.all(16.0),
                  child: ToDoListScreen(
                    userId: widget.userId,
                  ),
                );
              },
            );
          },
          child: Icon(Icons.add,
              color: AppStyle.getfloatingButtonColor(isDarkMode), size: 30),
          backgroundColor:
              AppStyle.getfloatingButtonBackgroundColor(isDarkMode),
        ),
      ),
      backgroundColor: AppStyle.getMainColor(isDarkMode),
      bottomNavigationBar: BottomAppBar(
        color: AppStyle.getbottomBarColor(isDarkMode),
        shape: CircularNotchedRectangle(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            IconButton(
              icon: Icon(Icons.article_outlined, size: 33),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => HomeScreen(
                            userId: widget.userId,
                          )),
                );
              },
            ),
            IconButton(
              icon: Icon(Icons.category_outlined, size: 29),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => CategoriesList(
                            userId: widget.userId,
                          )),
                );
              },
            ),
            Container(
              decoration: BoxDecoration(
                color: Colors.white24,
                borderRadius: BorderRadius.circular(8),
              ),
              child: IconButton(
                icon: Icon(FontAwesomeIcons.listCheck, size: 33),
                color: Colors.white,
                onPressed: () {},
              ),
            ),
          ],
        ),
      ),
      resizeToAvoidBottomInset: false,
    );
  }
}
