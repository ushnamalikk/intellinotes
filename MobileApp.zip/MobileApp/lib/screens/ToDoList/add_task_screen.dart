import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:myapp/main.dart';
import 'package:awesome_notifications/awesome_notifications.dart';

final Color lightPink = Color(0xFFF4B5B2);
final Color lightBlue = Color(0xFFB2CCFF);
final Color lightYellow = Color(0xFFFFE599);
Map<String, int> notificationIds = {}; // Map to store task IDs and corresponding notification IDs

void scheduleTaskNotification(Map<String, dynamic> task, String taskId) {
  String title = "Task Reminder:";
  int notificationId = DateTime.now().millisecondsSinceEpoch.remainder(100000);
  DateTime dueDate = (task['date'] as Timestamp).toDate();
  DateTime now = DateTime.now();
  Duration timeUntilDue = dueDate.difference(now);
  String body;

  DateTime notificationTime;
  if (timeUntilDue.inHours >= 24) {
    notificationTime = dueDate.subtract(Duration(hours: 24));
    body = "Your task '${task['title']}' is due in 24 hours!";
  } else if (timeUntilDue.inHours >= 1) {
    notificationTime = dueDate.subtract(Duration(hours: 1));
    body = "Your task '${task['title']}' is due in 1 hour!";
  } else if (timeUntilDue.inMinutes >= 10) {
    notificationTime = dueDate.subtract(Duration(minutes: 10));
    body = "Your task '${task['title']}' is due in 10 minutes!";
  } else {
    notificationTime = now.add(Duration(minutes: 1));
    body = "Your task '${task['title']}' is due very soon!";
  }
  if (notificationTime.isBefore(now) || notificationTime.isAfter(dueDate)) {
    notificationTime = now.add(Duration(seconds: 10)); // Add a little buffer time to ensure notification can be scheduled
  }

  createNotification(notificationId, title, body, notificationTime);
  notificationIds['$taskId'] = notificationId;
}


void cancelTaskNotification(String taskId) {
  if (notificationIds.containsKey('$taskId')) {
    int notificationId = notificationIds['$taskId']!;
    AwesomeNotifications().cancel(notificationId);
    notificationIds.remove('$taskId'); // Remove task ID from the map
  }
}

void createNotification(int notificationId, String title, String body, DateTime scheduledTime) {
  AwesomeNotifications().createNotification(
    content: NotificationContent(
      id: notificationId,
      channelKey: 'basic_channel',
      title: title,
      body: body,
      notificationLayout: NotificationLayout.Default,
    ),
    schedule: NotificationCalendar.fromDate(date: scheduledTime),
  );
}



class ToDoListScreen extends StatefulWidget {
  final String userId;
  ToDoListScreen({required this.userId});

  @override
  _ToDoListScreenState createState() => _ToDoListScreenState();
}

class _ToDoListScreenState extends State<ToDoListScreen> {
  final TextEditingController _taskController = TextEditingController();
  final TextEditingController _detailsController = TextEditingController();
  DateTime _selectedDate = DateTime.now();
  Color _selectedColor = Color(0xFFF4B5B2); // Pastel blue as default
  void _addTask(BuildContext context) {
    final String title = _taskController.text.trim();
    final String details = _detailsController.text.trim();
    final DateTime dueDate = _selectedDate;

    if (title.isNotEmpty || details.isNotEmpty) {
      final DateTime minimumTime = DateTime.now().add(Duration(minutes: 1));
      if (_selectedDate.isAfter(minimumTime)) {
        FirebaseFirestore.instance.collection('users').doc(widget.userId).collection('active_tasks').add({
          'title': title,
          'details': details,
          'date': Timestamp.fromDate(dueDate),
          'color': _selectedColor.value,
          'createdAt': Timestamp.now(),
        }).then((documentReference) {
          String taskId = documentReference.id;
          Map<String, dynamic> taskData = {
            'title': title,
            'date': Timestamp.fromDate(dueDate),
          };
          AwesomeNotifications().createNotification(
              content: NotificationContent(
                id: DateTime.now().millisecondsSinceEpoch.remainder(100000),
                channelKey: 'basic_channel',
                title: 'Task Added Successfully',
                body: "Your task '${title}' has been added and is due on ${dueDate.toString()}",
                notificationLayout: NotificationLayout.Default,
              ),
          );
          scheduleTaskNotification(taskData, taskId);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Task added to the list'),
              backgroundColor: Colors.green, // Set background color to red
              duration: Duration(seconds: 1), // Se
            ),
          );
          Navigator.pop(context);
        }).catchError((error) {
          print('Error adding task: $error');
        });
        _taskController.clear();
        _detailsController.clear();
        setState(() {
          _selectedDate = DateTime.now();
          _selectedColor = Color(0xFFB2CCFF);
        });
      } else {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Invalid Time'),
            content: Text('Please select a time at least two minutes ahead of the current time.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context); // Pop once
                },
                child: Text('OK'),
              ),
            ],
          ),
        );
      }
    } else {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Empty Task'),
          content: Text('Please add a title or details before saving.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('OK'),
            ),
          ],
        ),
      );
    }
  }



  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(), // Set the first selectable date to the current date
      lastDate: DateTime(2101),
    );

    if (pickedDate != null && pickedDate != _selectedDate) {
      final TimeOfDay? pickedTime = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.fromDateTime(_selectedDate),
      );

      if (pickedTime != null) {
        final DateTime pickedDateTime = DateTime(
          pickedDate.year,
          pickedDate.month,
          pickedDate.day,
          pickedTime.hour,
          pickedTime.minute,
        );

        final DateTime minimumTime = DateTime.now().add(Duration(minutes: 1));
        if (pickedDateTime.isAfter(minimumTime)) {
          setState(() {
            _selectedDate = pickedDateTime;
          });
        } else {
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Invalid Time'),
              content: Text('Please select a time at least two minutes ahead of the current time.'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text('OK'),
                ),
              ],
            ),
          );
        }
      }
    }
  }

  Widget _colorPicker() {
    final List<Color> pastelColors = [
      Color(0xFFF4B5B2), // Light pink
      Color(0xFFB2CCFF), // Light blue
      Color(0xFFFFE599), // Light yellow
      Color(0xFFC6EFCE), // Light green
    ];

    Color defaultColor = pastelColors[0];

    // Function to update the color in Firestore
    void updateColorInFirestore(Color color) {
      FirebaseFirestore.instance.collection('users').doc(widget.userId).collection('active_tasks').doc('your_document_id').update({
        'color': color.value.toString(), // Store color as a string.
      });
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8.0),
          child: Text(
            'Choose Color',
            style: GoogleFonts.poppins(
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              for (Color color in pastelColors)
                GestureDetector(
                  onTap: () {
                    setState(() => _selectedColor = color);
                    updateColorInFirestore(_selectedColor);
                  },
                  child: Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: color,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.black,
                        width: 2,
                      ),
                    ),
                  ),
                ),
              SizedBox(width: 10),
              GestureDetector(
                onTap: () {
                  // Open the color picker dialog
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: const Text('Pick a color'),
                        content: SingleChildScrollView(
                          child: ColorPicker(
                            pickerColor: _selectedColor,
                            onColorChanged: (color) => setState(() => _selectedColor = color),
                            showLabel: true,
                            pickerAreaHeightPercent: 0.8,
                            enableAlpha: false, // Disable alpha channel
                          ),
                        ),
                        actions: <Widget>[
                          ElevatedButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                              setState(() => _selectedColor = defaultColor);
                              updateColorInFirestore(_selectedColor);
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Theme.of(context).primaryColor,
                            ),
                            child: const Text('Cancel'),
                          ),
                          ElevatedButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                              updateColorInFirestore(_selectedColor); // Update the color in Firestore
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.black,
                            ),
                            child: const Text('Save'),
                          ),
                        ],
                      );
                    },
                  );
                },
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: _selectedColor,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: Colors.black,
                      width: 2,
                    ),
                  ),
                  child: const Icon(Icons.palette, color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add new task', style: GoogleFonts.poppins(color: Colors.black)),
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _taskController,
              decoration: InputDecoration(
                labelText: 'Title',
                hintText: 'ex: Clean the kitchen',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            SizedBox(height: 20.0),
            TextField(
              controller: _detailsController,
              decoration: InputDecoration(
                labelText: 'More Details',
                hintText: 'ex: Do the dishes, clean the fridge and pantry',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
              maxLines: 3,
            ),
            SizedBox(height: 20.0),
            GestureDetector(
              onTap: () => _selectDate(context),
              child: AbsorbPointer(
                child: TextFormField(
                  decoration: InputDecoration(
                    labelText: 'Date',
                    hintText: 'Tap on date input to change it',
                    suffixIcon: Icon(Icons.calendar_today),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  controller: TextEditingController(
                    text: DateFormat('dd/MM/yyyy').format(_selectedDate),
                  ),
                ),
              ),
            ),
            SizedBox(height: 20.0),
            _colorPicker(),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () => _addTask(context),
              child: Text('Save', style: TextStyle(fontSize: 16.0)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
                padding: EdgeInsets.symmetric(vertical: 12.0),
              ),
            ),

          ],
        ),
      ),
    );
  }
}



