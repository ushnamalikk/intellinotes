import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:myapp/screens/widgets/Dialogue%20Boxes/add_category_dialogue.dart';
import 'package:myapp/screens/HomeScreen/store_notes.dart';
import 'package:myapp/screens/widgets/Encryption/note_service.dart';

Future<void> updateNote(String docId, String title, String content,
    String userId, String categoryName,
    {refresh = null}) async {
  updateCategoryDate(categoryName, userId);

  if (title.isEmpty && content.isEmpty) {
    // Both title and content are empty, delete the note and return
    await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection("Categories")
        .where("Name",
            isEqualTo:
                categoryName) // Use where clause to filter by categoryName
        .get()
        .then((QuerySnapshot querySnapshot) async {
      if (querySnapshot.docs.isNotEmpty) {
        // Assuming there's only one category with this name
        var categoryDoc = querySnapshot.docs.first;
        await categoryDoc.reference
            .collection("Notes")
            .doc(docId)
            .delete()
            .then((_) {
          allNotes.remove(docId);
          refresh();
          print('Note deleted successfully');
        }).catchError((error) {
          print("Failed to delete note: $error");
        });
      } else {
        print("Category $categoryName not found");
      }
    }).catchError((error) {
      print("Failed to fetch category: $error");
    });
  } else {
    // Title or content is not empty, proceed with updating the note
    await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection("Categories")
        .where("Name",
            isEqualTo:
                categoryName) // Use where clause to filter by categoryName
        .get()
        .then((QuerySnapshot querySnapshot) async {
      if (querySnapshot.docs.isNotEmpty) {
        // Assuming there's only one category with this name
        var categoryDoc = querySnapshot.docs.first;
        String categoryId = querySnapshot.docs.first.id;
        print(content);
        String encryptedContent = NoteService().encrypt(content);
        await categoryDoc.reference.collection("Notes").doc(docId).update({
          "note_title": title,
          "note_content": encryptedContent,
          "creation_date":
              DateFormat('dd/MM/yy hh:mm:ss a').format(DateTime.now()),
        }).then((value) async {
          QuerySnapshot notesSnapshot = await FirebaseFirestore.instance
              .collection('users')
              .doc(userId)
              .collection("Categories")
              .doc(categoryId) // Using the ID obtained from the categoryDoc
              .collection('Notes')
              .where(FieldPath.documentId, isEqualTo: docId)
              .get();
          QueryDocumentSnapshot note = notesSnapshot.docs.first;
          insertNote(docId, note);
          if (refresh != null) {
            refresh();
          }
        }).catchError((error) {
          print("Failed to update note: $error");
        });
      } else {
        print("Category $categoryName not found");
      }
    }).catchError((error) {
      print("Failed to fetch category: $error");
    });
  }
}
