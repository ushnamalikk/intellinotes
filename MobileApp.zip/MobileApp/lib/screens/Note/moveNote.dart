// ignore_for_file: use_build_context_synchronously

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:myapp/screens/widgets/Encryption/note_service.dart';

import '../HomeScreen/store_notes.dart';

Future<void> selectCategoryForMove(
    BuildContext context,
    String userId,
    String docId,
    QueryDocumentSnapshot note,
    String categoryName,
    bool homeOrNot,
    Function()? refreshHomeScreen) async {
  List<String> categories = await getCategories(userId);

  String? selectedCategory = await showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text('Select Category'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: categories.length,
            itemBuilder: (BuildContext context, int index) {
              return ListTile(
                title: Text(categories[index]),
                onTap: () {
                  Navigator.pop(context, categories[index]);
                },
              );
            },
          ),
        ),
      );
    },
  );

  if (selectedCategory != null && selectedCategory != categoryName) {
    // print("YYAYYAY");
    // print(NoteService().decrypt(note['note_content']));
    await moveNoteToCategory(
      userId,
      docId,
      selectedCategory,
      categoryName,
      note['note_title'],
      NoteService().decrypt(note['note_content']),
      note['color_id'],
      note['pin'],
      refresh: refreshHomeScreen,
    );

    if (homeOrNot) {
      refreshHomeScreen!();
    }
  }
}

Future<List<String>> getCategories(String userId) async {
  List<String> categories = [];

  await FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection("Categories")
      .get()
      .then((QuerySnapshot querySnapshot) {
    querySnapshot.docs.forEach((doc) {
      categories.add(doc['Name']);
    });
  });

  return categories;
}

Future<QueryDocumentSnapshot> moveNoteToCategory(
    String userId,
    String docId,
    String selectedCategory,
    String categoryName,
    String noteTitle,
    String noteContent,
    int colorId,
    bool pinStatus,
    {refresh = null}) async {
  // print("HAHHAHAH");
  // print(noteContent);
  final encryptedContent = NoteService().encrypt(noteContent);
  // print(encryptedContent);
  Map<String, dynamic> noteData = {
    'note_title': noteTitle,
    'note_content': encryptedContent,
    'color_id': colorId,
    'creation_date': DateFormat('dd/MM/yy hh:mm:ss a').format(DateTime.now()),
    'categoryName': selectedCategory,
    'pin': pinStatus,
  };

  // Add the note to the selected category
  QuerySnapshot categoryQuery = await FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .collection("Categories")
      .where("Name", isEqualTo: selectedCategory)
      .get();
  if (categoryQuery.docs.isNotEmpty) {
    var categoryDoc = categoryQuery.docs.first;
    String categoryId = categoryQuery.docs.first.id;
    DocumentReference newNoteRef =
        await categoryDoc.reference.collection('Notes').add(noteData);
    QuerySnapshot notesSnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection("Categories")
        .doc(categoryId) // Using the ID obtained from the categoryDoc
        .collection('Notes')
        .where(FieldPath.documentId, isEqualTo: newNoteRef.id)
        .get();
    QueryDocumentSnapshot note = notesSnapshot.docs.first;
    moveNote(newNoteRef.id, docId, note);
    if (refresh != null) {
      refresh();
    }

    // Delete the note from the original category
    await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection("Categories")
        .where("Name", isEqualTo: categoryName)
        .get()
        .then((QuerySnapshot categorySnapshot) {
      if (categorySnapshot.docs.isNotEmpty) {
        var categoryDoc2 = categorySnapshot.docs.first;
        categoryDoc2.reference
            .collection("Notes")
            .doc(docId)
            .delete()
            .then((value) {
          print("Note deleted successfully from category $categoryName");
        }).catchError((error) {
          print("Failed to delete note from original category: $error");
        });
      } else {
        print("Category $categoryName not found");
        throw Exception(
            "Category $categoryName not found"); // Throw an exception
      }
    }).catchError((error) {
      print("Failed to get categories: $error");
      throw Exception("Failed to get categories: $error"); // Throw an exception
    });

    // Get the newly added note and return its QueryDocumentSnapshot
    QuerySnapshot newNoteQuery = await newNoteRef.parent.get();
    return newNoteQuery.docs.first;
  } else {
    print("Category $selectedCategory not found");
    throw Exception(
        "Category $selectedCategory not found"); // Throw an exception
  }
}
