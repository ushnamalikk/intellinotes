
// // ai_options.dart
// import 'package:flutter/material.dart';
// import 'package:myapp/screens/GPT%20Features/api_service.dart';
// import 'package:myapp/screens/Note/response_dialogue.dart';
// import 'package:myapp/Classes/noteclass.dart';
//
// class AiOptions extends StatefulWidget {
//   final TextEditingController titleController;
//   final TextEditingController contentController;
//   final String docId;
//   final String userId;
//   final VoidCallback onClose;
//
//   const AiOptions({
//     required this.titleController,
//     required this.contentController,
//     required this.docId,
//     required this.userId,
//     required this.onClose,
//     Key? key,
//   }) : super(key: key);
//
//   @override
//   _AiOptionsState createState() => _AiOptionsState();
// }
//
// class _AiOptionsState extends State<AiOptions> {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       width: MediaQuery.of(context).size.width,
//       padding: EdgeInsets.symmetric(vertical: 12.0),
//       decoration: _boxDecoration(),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//         children: [
//           _iconButton(Icons.repeat, () => _performAiAction('Paraphrase')),
//           _iconButton(Icons.short_text, () => _performAiAction('Summarize')),
//           _iconButton(Icons.title, () => _performAiAction('Generate Title')),
//         ],
//       ),
//     );
//   }
//
//   IconButton _iconButton(IconData iconData, VoidCallback onPressed) {
//     return IconButton(
//       icon: Icon(iconData, color: Colors.white),
//       onPressed: onPressed,
//     );
//   }
//
//   BoxDecoration _boxDecoration() {
//     return BoxDecoration(
//       color: Colors.black,
//       borderRadius: BorderRadius.circular(8.0),
//       boxShadow: [
//         BoxShadow(
//           color: Colors.black26,
//           blurRadius: 4.0,
//           offset: Offset(0, 2),
//         ),
//       ],
//     );
//   }
//
//   void _performAiAction(String action) {
//     String text = widget.contentController.text;
//     Note note = Note(title: widget.titleController.text, content: text);
//     int wordCount = note.getWordCount(text);
//
//     switch (action) {
//       case 'Paraphrase':
//         ApiService.paraphraseText(text, wordCount).then((response) {
//           Navigator.pop(context); // Close the modal bottom sheet
//           showResponseDialog(context, "Paraphrase", response, widget.contentController);
//         });
//         break;
//       case 'Summarize':
//         ApiService.summarizeText(text, wordCount).then((response) {
//           Navigator.pop(context); // Close the modal bottom sheet
//           showResponseDialog(context, "Summarize", response, widget.contentController);
//         });
//         break;
//       case 'Generate Title':
//         ApiService.generateTitle(text).then((response) {
//           Navigator.pop(context); // Close the modal bottom sheet
//           showResponseDialog(context, "Generate Title", response, widget.titleController);
//         });
//         break;
//       default:
//         throw Exception('Unknown AI action: $action');
//     }
//   }
// }

