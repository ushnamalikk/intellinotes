import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

Future<void> checkCategoryExistsAndAdd(BuildContext context, String userId, String categoryName) async {
  try {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection('Categories')
        .where('Name', isEqualTo: categoryName)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      // Category exists, no need to add it
      return;
    } else {
      // Category doesn't exist, add it
      await addCategoryToFirebase(context, userId, categoryName);
      Navigator.of(context).pop(); // Assuming you want to close a dialog or screen
    }
  } catch (error) {
    print('Error checking category existence: $error');
    throw error; // Propagate the error
  }
}

Future<void> addCategoryToFirebase(BuildContext context, String userId, String categoryName) async {
  try {
    await FirebaseFirestore.instance.collection('users')
        .doc(userId).collection('Categories').add({
      'Name': categoryName,
      'date': DateFormat('dd/MM/yy hh:mm:ss a').format(DateTime.now()),
    });
    print('Category added successfully');
  } catch (error) {
    print('Failed to add category: $error');
    throw error; // Propagate the error
  }
}