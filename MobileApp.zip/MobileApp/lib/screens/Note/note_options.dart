import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/screens/GPT%20Features/api_service.dart';
import 'package:myapp/screens/GPT%20Features/response_dialogue.dart';
import 'package:myapp/Classes/noteclass.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';

import '../widgets/style/app_style.dart';

class NoteOptions extends StatefulWidget {
  final Function(String) onParaphrase;
  final TextEditingController titleController;
  final TextEditingController contentController;
  final String docId;
  final String userId;

  const NoteOptions({
    required this.onParaphrase,
    required this.titleController,
    required this.contentController,
    required this.docId,
    required this.userId,
    Key? key,
  }) : super(key: key);

  @override
  _NoteOptionsState createState() => _NoteOptionsState();
}

class _NoteOptionsState extends State<NoteOptions> {
  bool isGPTExpanded = false;
  bool isLoading = false;
  bool showAiOptions = false;
  bool showSettingsOptions = false;
  bool showColorPicker = false; // New state to control color picker visibility
  int colorId = 0; // Index of the selected color
  double colorBoxWidth = 40.0;

  void toggleSettingsOptions() {
    if (!isLoading) { // Prevent toggling while actions are in progress
      setState(() {
        showSettingsOptions = !showSettingsOptions;
        if (showSettingsOptions) {
          // If we're showing the settings, make sure the GPT options are hidden
          showAiOptions = false;
        }
      });
    }
  }

  void toggleGPTExpanded() {
    setState(() {
      isGPTExpanded = !isGPTExpanded;
    });
  }

  void toggleAiOptions() {
    setState(() {
      showAiOptions = !showAiOptions;
    });
  }

  void toggleColorPicker() {
    setState(() {
      showColorPicker = !showColorPicker;
    });
  }




  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        buildMainOptions(context),
        if (showAiOptions) buildAiOptions(context),
        // buildAiOptions(context),
        // buildSettingsOptions(context),
        // buildColorPicker(context),
      ],
    );
  }



  Widget buildMainOptions(BuildContext context) {
      return AnimatedOpacity(
        opacity: showAiOptions ? 0.0 : 1.0,
        duration: Duration(milliseconds: 300),
        child: Container(
          height: 70,
          width: MediaQuery.of(context).size.width,
          decoration: boxDecoration(),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              iconButton(Icons.auto_awesome, toggleAiOptions),
            ],
          ),
        ),
      );
  }

  IconButton iconButton(IconData iconData, VoidCallback onPressed, {bool isCloseButton = false}) {
    Color iconColor = isLoading ? Colors.white.withOpacity(0.5) : Colors.white; // Use faded color when isLoading is true
    Widget icon = Icon(iconData, color: iconColor, size: isCloseButton ? 16 : 24); // Smaller icon size for close button

    if (isCloseButton) {
      icon = Container(
        width: 30, // Smaller total width for the circle border
        height: 30, // Smaller total height for the circle border
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: iconColor, width: 2), // Adjust border width if necessary
        ),
        child: Center(child: icon), // The cross icon itself
      );
    }

    return IconButton(
      icon: icon,
      onPressed: isLoading ? null : onPressed, // Disable button if isLoading is true
      padding: EdgeInsets.all(isCloseButton ? 4 : 16), // Reduced padding for close button
      constraints: BoxConstraints(
        minWidth: isCloseButton ? 30 : 48,  // Smaller constraints for close button
        minHeight: isCloseButton ? 30 : 48, // Smaller constraints for close button
      ),
    );
  }

  Widget buildSettingsOptions(BuildContext context) {
    return AnimatedPositioned(
      duration: Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      bottom: showSettingsOptions ? 0 : -60, // Slides in and out from the bottom
      left: 0,
      right: 0,
      child: AnimatedOpacity(
        opacity: showSettingsOptions ? 1.0 : 0.0, // Fades in and out
        duration: Duration(milliseconds: 300),
        child: Container(
          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.symmetric(vertical: 12.0),
          decoration: boxDecoration(),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              iconButton(Icons.delete, () {
                // TODO: Implement delete functionality
              }),
              iconButton(Icons.lock, () {
                // TODO: Implement lock functionality
              }),
              iconButton(Icons.push_pin, () {
                // TODO: Implement pin functionality
              }),
              iconButton(Icons.close, toggleSettingsOptions, isCloseButton: true), // This is the close button
            ],
          ),
        ),
      ),
      onEnd: () {
        // Reset any state or perform any actions once the animation is finished, if necessary
      },
    );
  }



  Widget buildAiOptions(BuildContext context) {
    return AnimatedPositioned(
      duration: Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      bottom: showAiOptions ? 0 : -60, // Adjust the offset to the height of your button container
      left: 0,
      right: 0,
      child: Container(
        width: MediaQuery.of(context).size.width,
        padding: EdgeInsets.symmetric(vertical: 0.0),
        decoration: boxDecoration(),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly, // Use spaceEvenly for even distribution
          children: [
            // iconButton(Icons.repeat,  () => performAiAction(context, 'Paraphrase', widget.contentController)),
            GestureDetector(
              onTap: () => performAiAction(context, 'Paraphrase', widget.contentController),
              child: Container(
                color: Colors.black,
                width: 70,
                height: 58,
                child: Image.asset('lib/icons/paraphrase.png'),
              ),
            ),
            // iconButton(Icons.short_text, () => performAiAction(context, 'Summarize', widget.contentController)),
            GestureDetector(
              onTap: () => performAiAction(context, 'Summarize', widget.contentController),
              child: Container(
                color: Colors.black,
                width: 56,
                height: 56,
                child: Image.asset('lib/icons/summarize.png'),
              ),
            ),
            GestureDetector(
              onTap: () => performAiAction(context, 'Generate Title', widget.contentController),
              child: Container(
                color: Colors.black,
                width: 82,
                height: 70,
                child: Image.asset('lib/icons/generate.png'),
              ),
            ),
            // iconButton(Icons.title, () => performAiAction(context, 'Generate Title', widget.contentController)),
            iconButton(Icons.close, toggleAiOptions, isCloseButton: true), // Specify this is the close button
          ],
        ),
      ),
      onEnd: () {},
    );
  }


  BoxDecoration boxDecoration() {
    return BoxDecoration(
      color: Colors.black,
      borderRadius: BorderRadius.circular(18.0),
      boxShadow: [
        BoxShadow(
          color: Colors.black26,
          blurRadius: 4.0,
          offset: Offset(0, 2),
        ),
      ],
    );
  }
  void performAiAction(BuildContext context, String action, TextEditingController controller) async {
    String text = controller.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'The note is empty. Please add some text.',
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.black,
        ),
      );
      return;
    }

    // Check if text has less than 10 words
    List<String> words = text.split(' ');
    if (words.length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'The text is too short. Please provide at least 10 words.',
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.black,
        ),
      );
      return;
    }

    // Disable the GPT buttons
    setState(() {
      isLoading = true;
    });

    // Perform GPT action based on selected text
    Note note = Note(title: widget.titleController.text, content: text);
    int wordCount = note.getWordCount(text);

    String? selectedText = getSelectedText(controller);
    if (selectedText != null && selectedText.isNotEmpty) {
      text = selectedText;
      wordCount = note.getWordCount(selectedText);
    }

    switch (action) {
      case 'Paraphrase':
        ApiService.paraphraseText(text, wordCount).then((response) {
          showResponseDialog(context, "Paraphrase", response, controller);
          // Re-enable the GPT buttons after response
          setState(() {
            isLoading = false;
          });
        });
        break;
      case 'Summarize':
        ApiService.summarizeText(text, wordCount).then((response) {
          showResponseDialog(context, "Summarize", response, controller);
          // Re-enable the GPT buttons after response
          setState(() {
            isLoading = false;
          });
        });
        break;
      case 'Generate Title':
        ApiService.generateTitle(text).then((response) {
          showResponseDialog(context, "Generate Title", response, controller);
          // Re-enable the GPT buttons after response
          setState(() {
            isLoading = false;
          });
        });
        break;
    }
  }


  String? getSelectedText(TextEditingController controller) {
    if (controller.selection.start != controller.selection.end) {
      int start = controller.selection.start;
      int end = controller.selection.end;
      return controller.text.substring(start, end);
    }
    return null;
  }
}
