import 'package:firebase_auth/firebase_auth.dart';
import 'package:myapp/screens/widgets/show_toast.dart';

// Service class for Firebase Authentication
class FirebaseAuthService {
  // Firebase authentication instance
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Method to sign up with email and password
  Future<User?> signUpWithEmailAndPassword(String email, String password) async {

    try {
      // Create user with email and password
      UserCredential credential =await _auth.createUserWithEmailAndPassword(email: email, password: password);
      return credential.user;
      // Return user from credential
    } on FirebaseAuthException catch (e) {

      // Handle FirebaseAuthException
      if (e.code == 'email-already-in-use') {
        showToast(message: 'The email address is already in use.');
      } else {
        showToast(message: 'An error occurred: ${e.code}');
      }
    }
    // Return null if user creation fails
    return null;

  }

  // Method to sign in with email and password

  Future<User?> signInWithEmailAndPassword(String email, String password) async {

    try {
      // Sign in user with email and password
      UserCredential credential =await _auth.signInWithEmailAndPassword(email: email, password: password);
      // Return user from credential
      return credential.user;
    } on FirebaseAuthException catch (e) {
      // Handle FirebaseAuthException
      if (e.code == 'user-not-found' || e.code == 'wrong-password') {
        showToast(message: 'Invalid email or password.');
      } else {
        showToast(message: 'An error occurred: ${e.code}');
      }

    }
    // Return null if sign-in fails
    return null;

  }


  // Method to check if the input string is a valid email
  bool isEmail(String input) {
    final emailRegex = RegExp(r'^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$');
    return emailRegex.hasMatch(input);
  }

}
