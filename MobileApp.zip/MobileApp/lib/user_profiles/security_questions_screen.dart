import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/user_profiles/reset_password.dart';


// Screen to handle security question verification
class SecurityQuestionScreen extends StatefulWidget {
  const SecurityQuestionScreen({Key? key}) : super(key: key);

  @override
  _SecurityQuestionScreenState createState() => _SecurityQuestionScreenState();
}

class _SecurityQuestionScreenState extends State<SecurityQuestionScreen> {
  TextEditingController usernameController = TextEditingController();
  TextEditingController answerController = TextEditingController(); // Controller for the answer field
  String? username;
  String? securityQuestion;
  String? correctAnswer;

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;

    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.only(top: 11.0, left: 12),
          child: IconButton(
            icon: Icon(
              Icons.arrow_back,
              size: 30,
              color: AppStyle.getBackArroworMenuColor(isDarkMode),
            ),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ),
        title: Padding(
          padding: const EdgeInsets.only(top: 12.0),
          child: Text(
            'Reset Password',
            style: TextStyle(
              fontSize: 23.0,
              fontFamily: 'Poppins',
              color: isDarkMode ? Colors.white : Colors.black,
              fontWeight: FontWeight.normal,
            ),
          ),
        ),
        backgroundColor: AppStyle.getMainColor(isDarkMode),
      ),
      backgroundColor: AppStyle.getMainColor(isDarkMode),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Enter Your Username:',
              style: TextStyle(
                fontSize: 16.0,
                fontFamily: 'Poppins',
                color: isDarkMode ? Colors.white : Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
            TextField(
              controller: usernameController,
              style: TextStyle(
                fontSize: 14.0,
                fontFamily: 'Poppins',
                color: isDarkMode ? Colors.white : Colors.black,
                fontWeight: FontWeight.normal,
              ),
              decoration: InputDecoration(
                labelText: 'Username',
                labelStyle: TextStyle(
                  fontSize: 16.0,
                  fontFamily: 'Poppins',
                  color: isDarkMode ? Colors.white : Colors.black,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                setState(() {
                  securityQuestion = null; // Reset security question when clicking "Next"
                });
                await fetchSecurityQuestion(); // Fetch security question based on username
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(
                    isDarkMode ? Colors.white : Color.fromARGB(255, 30, 56, 74) // Set button background color based on dark mode
                ),
              ),
              child: Text(
                'Next',
                style: TextStyle(
                  color: isDarkMode ? Colors.black : Colors.white, // Set button text color based on dark mode
                  fontFamily: 'Poppins', // Apply Poppins font family
                ),
              ),
            ),
            SizedBox(height: 20),
            if (securityQuestion != null)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    securityQuestion!,
                    style: TextStyle(
                      fontSize: 16.0,
                      fontFamily: 'Poppins',
                      color: isDarkMode ? Colors.white : Colors.black,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                  TextField(
                    controller: answerController,
                    style: TextStyle(
                      fontSize: 14.0,
                      fontFamily: 'Poppins',
                      color: isDarkMode ? Colors.white : Colors.black,
                      fontWeight: FontWeight.normal,
                    ),
                    onChanged: (value) {},
                    decoration: InputDecoration(labelText: 'Answer',labelStyle: TextStyle(
                      fontSize: 14.0,
                      fontFamily: 'Poppins',
                      color: isDarkMode ? Colors.white : Colors.black,
                      fontWeight: FontWeight.normal,
                    )),

                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      if (isAnswerCorrect()) {
                        // Navigate to reset password screen if the answer is correct
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ResetPassword(username: username!),
                          ),
                        );
                      } else {
                        // Show error message if the answer is incorrect
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              "Incorrect Answer!",
                              style: GoogleFonts.poppins(), // Apply Poppins font style for the error message
                            ),
                            backgroundColor: Colors.red, // Set background color to red for error message
                            duration: Duration(seconds: 2), // Set duration for the error message
                          ),
                        );
                      }
                    },
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(
                          isDarkMode ? Colors.white : Color.fromARGB(255, 30, 56, 74) // Set button background color based on dark mode
                      ),
                    ),
                    child: Text(
                      'Submit',
                      style: TextStyle(
                        color: isDarkMode ? Colors.black : Colors.white, // Set button text color based on dark mode
                        fontFamily: 'Poppins', // Apply Poppins font family
                      ),
                    ),
                  ),
                ],
              ),
            if (securityQuestion == null)
              SizedBox(height: 20), // Spacer to maintain the layout
          ],
        ),
      ),
    );
  }

  // Fetch security question from Firestore based on the provided username
  Future<void> fetchSecurityQuestion() async {
    username = usernameController.text;

    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('username', isEqualTo: username)
          .get();

      if (snapshot.docs.isNotEmpty) {
        final userId = snapshot.docs.first.id;
        final securityQuestionSnapshot = await FirebaseFirestore.instance
            .collection('security_questions')
            .doc(userId)
            .get();

        if (securityQuestionSnapshot.exists) {
          setState(() {
            securityQuestion = securityQuestionSnapshot.data()?['selected_question'];
            correctAnswer = securityQuestionSnapshot.data()?['answer'];
          });
        }
      } else {
        // Show error message if user is not found
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              "User not Found!",
              style: GoogleFonts.poppins(), // Apply Poppins font style for the error message
            ),
            backgroundColor: Colors.red, // Set background color to red for error message
            duration: Duration(seconds: 2), // Set duration for the error message
          ),
        );
      }
    } catch (e) {
      print('Error fetching security question: $e');
    }
  }

  // Check if the provided answer matches the correct answer
  bool isAnswerCorrect() {
    return answerController.text == correctAnswer;
  }
}
