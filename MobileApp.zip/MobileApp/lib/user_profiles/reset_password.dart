import 'package:flutter/material.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/screens/widgets/show_toast.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:myapp/user_profiles/login.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_fonts/google_fonts.dart';

// Widget to reset the password
class ResetPassword extends StatelessWidget {
  final String username;
  TextEditingController newPasswordController = TextEditingController();
  TextEditingController confirmNewPasswordController = TextEditingController();

  // Constructor to initialize username
  ResetPassword({required this.username});

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;

    return Scaffold(
      appBar: AppBar(
        // Back button in the app bar
        leading: Padding(
          padding: const EdgeInsets.only(top: 11.0, left: 12),
          child: IconButton(
            icon: Icon(Icons.arrow_back,
                size: 30, color: AppStyle.getBackArroworMenuColor(isDarkMode)),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ),
        // Title of the page
        title: Padding(
          padding: const EdgeInsets.only(top: 12.0),
          child: Text(
            'Set New Password',
            style: TextStyle(
              fontSize: 23.0,
              fontFamily: GoogleFonts.poppins().fontFamily,
              color: isDarkMode ? Colors.white : Colors.black,
              fontWeight: FontWeight.normal,
            ),
          ),
        ),
        // Background color of the app bar
        backgroundColor: AppStyle.getMainColor(isDarkMode),
      ),
      // Background color of the page
      backgroundColor: AppStyle.getMainColor(isDarkMode),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                // Text form field for entering new password
                TextFormField(
                  controller: newPasswordController,
                  decoration: InputDecoration(
                    labelText: 'New Password',
                    prefixIcon: Icon(Icons.lock_open,
                        color: AppStyle.getTextColor(isDarkMode)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: const Color.fromARGB(255, 179, 0, 0),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: AppStyle.getFocusedPasswordBoxColor(
                            isDarkMode),
                      ),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: Colors.red,
                      ),
                    ),
                    focusedErrorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: AppStyle.getFocusedPasswordBoxColor(
                            isDarkMode),
                      ),
                    ),
                    errorStyle: GoogleFonts.poppins(
                      fontSize: 12.0,
                      color: Colors.red,
                    ),
                    labelStyle: GoogleFonts.poppins(
                      color: AppStyle.getTextColor(isDarkMode),
                    ),
                  ),
                  style: TextStyle(
                    color: AppStyle.getTextColor(isDarkMode),
                  ),
                  cursorColor: AppStyle.getTextColor(isDarkMode),
                  obscureText: true,
                  validator: (value) {
                    // Validation for new password
                    if (value == null || value.isEmpty) {
                      return 'Please enter a new password';
                    }
                    if (value.length < 6) {
                      return 'Password must be at least 6 characters long';
                    }
                    if (!RegExp(r'(?=.*[A-Z])').hasMatch(value)) {
                      return 'Password must contain at least one uppercase letter';
                    }
                    if (!RegExp(r'(?=.*\d)').hasMatch(value)) {
                      return 'Password must contain at least one number';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                // Text form field for confirming new password
                TextFormField(
                  controller: confirmNewPasswordController,
                  decoration: InputDecoration(
                    labelText: 'Confirm New Password',
                    prefixIcon: Icon(Icons.lock_outline,
                        color: AppStyle.getTextColor(isDarkMode)),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: Color.fromARGB(255, 227, 51, 51),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: AppStyle.getFocusedPasswordBoxColor(
                            isDarkMode),
                      ),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: Colors.red,
                      ),
                    ),
                    focusedErrorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      borderSide: BorderSide(
                        color: AppStyle.getFocusedPasswordBoxColor(
                            isDarkMode),
                      ),
                    ),
                    errorStyle: GoogleFonts.poppins(
                      fontSize: 12.0,
                      color: Colors.red,
                    ),
                    labelStyle: GoogleFonts.poppins(
                      color: AppStyle.getTextColor(isDarkMode),
                    ),
                  ),
                  style: TextStyle(
                    color: AppStyle.getTextColor(isDarkMode),
                  ),
                  cursorColor: AppStyle.getTextColor(isDarkMode),
                  obscureText: true,
                  validator: (value) {
                    // Validation for confirming new password
                    if (value != newPasswordController.text) {
                      return 'Passwords do not match';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 20),
                // Button to set the new password
                ElevatedButton(
                  onPressed: () async {
                    String newPassword = newPasswordController.text.trim();
                    String confirmNewPassword =
                    confirmNewPasswordController.text.trim();

                    if (newPassword.isEmpty || confirmNewPassword.isEmpty) {
                      // Show toast message if any field is empty
                      showToast(message: "Please enter both fields");
                      return;
                    }

                    if (newPassword != confirmNewPassword) {
                      // Show toast message if passwords do not match
                      showToast(message: "Passwords do not match");
                      return;
                    }

                    if (newPassword.length < 6) {
                      // Show toast message if password length is less than 6 characters
                      showToast(
                          message: "Password must be at least 6 characters long");
                      return;
                    }

                    if (!RegExp(r'(?=.*[A-Z])').hasMatch(newPassword)) {
                      // Show toast message if password does not contain an uppercase letter
                      showToast(
                          message:
                          "Password must contain at least one uppercase letter");
                      return;
                    }

                    if (!RegExp(r'(?=.*\d)').hasMatch(newPassword)) {
                      // Show toast message if password does not contain a number
                      showToast(
                          message: "Password must contain at least one number");
                      return;
                    }

                    try {
                      SharedPreferences prefs =
                      await SharedPreferences.getInstance();
                      String? oldPassword = prefs.getString(username);

                      if (oldPassword == null) {
                        // Show toast message if old password is not found in shared preferences
                        showToast(
                            message:
                            "Old password not found in shared preferences");
                        return;
                      }
                      // Sign in with the old password
                      UserCredential userCredential =
                      await FirebaseAuth.instance
                          .signInWithEmailAndPassword(
                        email: username + '@intellinotes.com',
                        password: oldPassword,
                      );
                      AuthCredential credential =
                      EmailAuthProvider.credential(
                          email: username + '@intellinotes.com',
                          password: oldPassword);
                      // Reauthenticate the user
                      await userCredential.user!
                          .reauthenticateWithCredential(credential);
                      // Update the password
                      await userCredential.user!.updatePassword(newPassword);
                      // Remove old password from shared preferences and add the new one
                      prefs.remove(username);
                      await prefs.setString(username, newPassword);
                      // Show toast message for successful password update
                      showToast(message: "Password successfully updated");
                      // Navigate back to login page after password update
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => LoginPage()),
                      );
                    } catch (e) {
                      // Show toast message for any error occurred during password update
                      showToast(message: "Error updating password: $e");
                    }
                  },
                  // Button style
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(
                      isDarkMode
                          ? Colors.white
                          : Color.fromARGB(255, 30, 56, 74),
                    ),
                  ),
                  // Button text
                  child: Text(
                    'Set New Password',
                    style: TextStyle(
                      color: isDarkMode ? Colors.black : Colors.white,
                      fontFamily: 'Poppins',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
