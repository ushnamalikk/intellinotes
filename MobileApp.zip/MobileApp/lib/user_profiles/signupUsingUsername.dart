import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:myapp/user_profiles/login.dart';
import 'package:myapp/user_profiles/auth_service.dart';
import 'package:myapp/screens/HomeScreen/homeScreen.dart';
import 'package:myapp/screens/widgets/form_container.dart';
import 'package:myapp/screens/widgets/show_toast.dart';
import 'package:myapp/screens/MainPage/mainPage.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Widget for the sign-up page
class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key}) : super(key: key);

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final FirebaseAuthService _auth = FirebaseAuthService();

  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool isSigningUp = false;

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    return Scaffold(
      backgroundColor: AppStyle.getMainColor(isDarkMode),
      body: SingleChildScrollView(
        child: Container(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 150),
                  // Header Text
                  Padding(
                    padding: const EdgeInsets.only(bottom: 0.0),
                    child: Text(
                      "Create Account,",
                      style: TextStyle(color: isDarkMode ? Colors.white : Colors.black,fontSize: 36, fontWeight: FontWeight.bold, fontFamily: GoogleFonts.poppins().fontFamily,),
                    ),
                  ),
                  const SizedBox(height: 10,),
                  // Subtitle Text
                  Text(
                    "Sign up to get started!",
                    style: TextStyle(fontSize: 20, color: isDarkMode ? Colors.grey : Colors.grey.shade600,fontFamily: GoogleFonts.poppins().fontFamily,),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Username",
                        style: TextStyle(
                          color: isDarkMode ? Colors.white : Colors.black,
                          fontSize: 16,
                          fontFamily: GoogleFonts.poppins().fontFamily,
                        ),
                      ),
                      const SizedBox(height: 8),
                      // Username Form Field
                      FormContainerWidget(
                        icon: Icons.person,
                        controller: _usernameController,
                        hintText: "Username",
                         hintTextStyle: const TextStyle(
                          fontFamily: 'Poppins',
                        ),
                        isPasswordField: false,
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Password",
                        style: TextStyle(
                          color: isDarkMode ? Colors.white : Colors.black,
                          fontSize: 16,
                          fontFamily: GoogleFonts.poppins().fontFamily,
                        ),
                      ),
                      const SizedBox(height: 8),
                      // Password Form Field
                      FormContainerWidget(
                        controller: _passwordController,
                        hintText: "Password",
                         hintTextStyle: const TextStyle(
                          fontFamily: 'Poppins', // Specify Poppins font
                        ),
                        isPasswordField: true,
                        icon: Icons.vpn_key,
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  // Sign Up Button
                  GestureDetector(
                    onTap: () async {
                      await _savePassword();
                      _validateAndSignUp();
                    },
                    // Divider and "or" Text
                    child: Container(
                      width: double.infinity,
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [ Color.fromARGB(255, 54, 84, 106),Color(0xFF80D0C7) ],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: isSigningUp
                            ? const CircularProgressIndicator(color: Colors.white,)
                            : Text(
                          "Sign Up",
                          style: TextStyle(
                              color: Colors.white, fontWeight: FontWeight.bold, fontFamily: GoogleFonts.poppins().fontFamily,),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Divider(
                          thickness: 1,
                          color: isDarkMode ? Colors.grey.shade400 :  Colors.grey.shade600,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: Text(
                          'or',
                          style: TextStyle(
                            color: isDarkMode ? Colors.grey.shade400 :  Colors.grey.shade600,
                            fontFamily: GoogleFonts.poppins().fontFamily,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Divider(
                          thickness: 1,
                          color: isDarkMode ? Colors.grey.shade400 :  Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  // Google Sign-In Button
                  GestureDetector(
                    onTap: _signInWithGoogle,
                    child: Container(
                      width: double.infinity,
                      height: 50,
                      decoration: BoxDecoration(
                        color: isDarkMode ? Colors.white : Colors.grey.shade600,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.grey.shade300),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.2),
                            spreadRadius: 2,
                            blurRadius: 4,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: _buildGoogleSignInButton(isDarkMode),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const SizedBox(height: 20),
                  const SizedBox(height: 20),
                  const SizedBox(height: 20),
                  const SizedBox(height: 20),
                  // Already have an account? Login Link
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Already have an account?",
                        style: TextStyle(
                          color: isDarkMode ? Colors.white : Colors.black,
                          fontFamily: GoogleFonts.poppins().fontFamily,
                        ),
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(builder: (context) => const LoginPage()),
                                (route) => false,
                          );
                        },
                        child: Text(
                          "Login",
                          style: TextStyle(
                            color: isDarkMode ? Colors.blue :  const Color.fromARGB(255, 0, 51, 102),
                            fontWeight: FontWeight.bold,
                            fontFamily: GoogleFonts.poppins().fontFamily,
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Widget for Google Sign-In Button
  Widget _buildGoogleSignInButton(bool isDarkMode) {
    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset('assets/images/google.webp', height: 32.0),
              const SizedBox(width: 13),
              Text(
                "Continue with Google",
                style: TextStyle(
                  fontSize: 16,
                  color: isDarkMode ? Colors.grey.shade600: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontFamily: GoogleFonts.poppins().fontFamily,
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  // Save username and password to local storage
  Future<void> _savePassword() async {
    String username = _usernameController.text.trim();
    String password = _passwordController.text.trim();

    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(username, password);
  }

  // Validate form fields and initiate sign-up process
  Future<void> _validateAndSignUp() async {
    String username = _usernameController.text.trim();
    String password = _passwordController.text.trim();

    if (username.isEmpty) {
      showToast(message: "Please enter your username");
      return;
    }

    List<String> usernames = [];

    try {
      QuerySnapshot querySnapshot = await FirebaseFirestore.instance.collection('users').get();
      querySnapshot.docs.forEach((DocumentSnapshot document) {
        Map<String, dynamic> userData = document.data() as Map<String, dynamic>;
        if (userData.containsKey('username')) {
          String username = userData['username'];
          usernames.add(username);
        }
      });
    } catch (e) {
      print('Error retrieving usernames: $e');
    }

    if (usernames.contains(username)) {
      showToast(message: "Username $username is already taken");
      return;
    }

    if (password.isEmpty || password.length < 6) {
      showToast(message: "Password must be at least 6 characters long");
      return;
    }

    if (!containsUppercase(password)) {
      showToast(message: "Weak Password: must contain at least one uppercase letter and one number");
      return;
    }

    if (!containsNumber(password)) {
      showToast(message: "Weak Password: must contain at least one uppercase letter and one number");
      return;
    }

    _signUp(username, password);
  }

  // Check if the password contains uppercase letters
  bool containsUppercase(String value) {
    return RegExp(r'[A-Z]').hasMatch(value);
  }

  // Check if the password contains numbers
  bool containsNumber(String value) {
    return RegExp(r'\d').hasMatch(value);
  }

  // Perform the sign-up process
  void _signUp(String username, String password) async {

    setState(() {
      isSigningUp = true;
    });

    User? user = await _auth.signUpWithEmailAndPassword(username + '@intellinotes.com', password);

    setState(() {
      isSigningUp = false;
    });

    if (user != null) {
      String userId = user.uid;
      FirebaseFirestore.instance.collection('users').doc(userId).set({
        'username': username,
        'email': username + '@intellinotes.com',
        'isGmail': false,
      });
      showToast(message: "User is successfully created");
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => GetStartedPage(userId: userId)),
      );
    } else {
      showToast(message: "Some error happened");
    }
  }

  // Handle Google Sign-In
  _signInWithGoogle() async {
    final GoogleSignIn googleSignIn = GoogleSignIn();
    final FirebaseAuth firebaseAuth = FirebaseAuth.instance;

    try {
      // Sign out the current user (if any)
      await googleSignIn.signOut();

      final GoogleSignInAccount? googleSignInAccount = await googleSignIn.signIn();

      if (googleSignInAccount != null) {
        final GoogleSignInAuthentication googleSignInAuthentication =
        await googleSignInAccount.authentication;

        final AuthCredential credential = GoogleAuthProvider.credential(
          idToken: googleSignInAuthentication.idToken,
          accessToken: googleSignInAuthentication.accessToken,
        );

        final UserCredential userCredential =
        await firebaseAuth.signInWithCredential(credential);

        if (userCredential.user != null) {
          final String userId = userCredential.user!.uid;

          final String email = googleSignInAccount.email;
          final String username = email.split('@').first;

          FirebaseFirestore.instance.collection('users').doc(userId).set({
            'username': username,
            'email': email,
            'isGmail': true,
          });

          // Navigate to the HomeScreen with the userId
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => HomeScreen(userId: userId)),
          );
        } else {
          // Handle case where userCredential.user is null
          showToast(message: "Sign in with Google failed. Please try again.");
        }
      } else {
        // Handle case where googleSignInAccount is null
        showToast(message: "Google sign in cancelled or failed.");
      }
    } catch (e) {
      print(e);
      showToast(message: "Some error occurred while signing in with Google. $e");
    }
  }
}
