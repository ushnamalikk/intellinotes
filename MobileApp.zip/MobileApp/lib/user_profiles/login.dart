import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:myapp/screens/widgets/Dark%20Mode/dark_mode_provider.dart';
import 'package:myapp/user_profiles/auth_service.dart';
import 'package:myapp/screens/HomeScreen/homeScreen.dart';
import 'package:myapp/screens/widgets/form_container.dart';
import 'package:myapp/screens/widgets/show_toast.dart';
import 'package:myapp/user_profiles/signupUsingUsername.dart';
import 'package:myapp/screens/widgets/style/app_style.dart';
import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/user_profiles/security_questions_screen.dart';

// Widget for the login page
class LoginPage extends StatefulWidget {
  const LoginPage({Key? key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool _isSigning = false;
  final FirebaseAuthService _auth = FirebaseAuthService();
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  TextEditingController _usernameOrEmailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  @override
  void dispose() {
    _usernameOrEmailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Provider.of<DarkModeProvider>(context).isDarkMode;
    return Scaffold(
      backgroundColor: AppStyle.getMainColor(isDarkMode),
      body: SingleChildScrollView(
        child: Container(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 150),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 0.0),
                    // Header Text
                    child: Text(
                      "Welcome Back,",
                      style: TextStyle(
                        fontSize: 36,
                        fontWeight: FontWeight.bold,
                        color: isDarkMode ? Colors.white : Colors.black,
                        fontFamily: GoogleFonts.poppins().fontFamily,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 1,
                  ),
                  // Subtitle Text
                  Text(
                    "Log in to continue!",
                    style: TextStyle(
                      fontSize: 20,
                      color: isDarkMode ? Colors.grey : Colors.grey.shade600,
                      fontFamily: GoogleFonts.poppins().fontFamily,
                    ),
                  ),

                  const SizedBox(
                    height: 30,
                  ),
                  // Username Form Field
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Username",
                        style: TextStyle(
                          color: isDarkMode ? Colors.white : Colors.black,
                          fontSize: 16,
                          fontFamily: GoogleFonts.poppins().fontFamily,
                        ),
                      ),
                      const SizedBox(height: 8),
                      FormContainerWidget(
                        icon: Icons.person,
                        controller: _usernameOrEmailController,
                        hintText: "Enter Username",
                        hintTextStyle: const TextStyle(
                          fontFamily: 'Poppins', // Specify Poppins font
                        ),
                        isPasswordField: false,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your username or email';
                          }
                          return null;
                        },
                      ),
                    ],
                  ),

                  const SizedBox(
                    height: 10,
                  ),
                  // Password Form Field
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Password",
                        style: TextStyle(
                          color: isDarkMode ? Colors.white : Colors.black,
                          fontSize: 16,
                          fontFamily: GoogleFonts.poppins().fontFamily,
                        ),
                      ),
                      const SizedBox(height: 8),
                      FormContainerWidget(
                        icon: Icons.vpn_key,
                        controller: _passwordController,
                        hintText: "Enter Password",
                        hintTextStyle: const TextStyle(
                          fontFamily: 'Poppins', // Specify Poppins font
                        ),
                        isPasswordField: true,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your password';
                          }
                          if (value.length < 6) {
                            return 'Password must be at least 6 characters long';
                          }
                          return null;
                        },
                      ),
                    ],
                  ),

                  // Forgot Password Link
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: _forgotPassword,
                      child: Text(
                        "Forgot password?",
                        style: TextStyle(
                          color: isDarkMode
                              ? Colors.blue
                              : const Color.fromARGB(255, 0, 51, 102),
                          fontFamily: GoogleFonts.poppins().fontFamily,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(
                    height: 20,
                  ),
                  // Sign In Button
                  GestureDetector(
                    onTap: _signIn,
                    child: Container(
                      width: double.infinity,
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [
                            Color.fromARGB(255, 54, 84, 106), // Light blue
                            Color(0xFF80D0C7)
                          ],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: _buildButtonContent(_isSigning, "Log In"),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  // Divider and "or" Text
                  Row(
                    children: <Widget>[
                      Expanded(
                        child: Divider(
                          thickness: 1,
                          color: isDarkMode
                              ? Colors.grey.shade400
                              : Colors.grey.shade600,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8.0),
                        child: Text(
                          'or',
                          style: TextStyle(
                            color: isDarkMode
                                ? Colors.grey.shade400
                                : Colors.grey.shade600,
                            fontFamily: GoogleFonts.poppins().fontFamily,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Divider(
                          thickness: 1,
                          color: isDarkMode
                              ? Colors.grey.shade400
                              : Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  // Google Sign-In Button
                  GestureDetector(
                    onTap: () {
                      _signInWithGoogle();
                    },
                    child: Container(
                      width: double.infinity,
                      height: 50,
                      decoration: BoxDecoration(
                        color: isDarkMode ? Colors.white : Colors.grey.shade600,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.grey.shade300),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.2),
                            spreadRadius: 2,
                            blurRadius: 4,
                            offset: const Offset(0, 3),
                          ),
                        ],
                      ),
                      child: _buildGoogleSignInButton(isDarkMode),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const SizedBox(
                      height: 20),
                  const SizedBox(height: 20),
                  // Sign Up Link
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Don't have an account?",
                        style: TextStyle(
                          color: isDarkMode ? Colors.white : Colors.black,
                          fontFamily: GoogleFonts.poppins().fontFamily,
                        ),
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const SignUpPage()),
                            (route) => false,
                          );
                        },
                        child: Text(
                          "Sign Up",
                          style: TextStyle(
                            color: isDarkMode
                                ? Colors.blue
                                : const Color.fromARGB(255, 0, 51, 102),
                            fontWeight: FontWeight.bold,
                            fontFamily: GoogleFonts.poppins().fontFamily,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Widget to show button content based on the sign-in state
  Widget _buildButtonContent(bool isSigning, String text) {
    return Center(
      child: isSigning
          ? const CircularProgressIndicator(
              color: Colors.white,
            )
          : Text(
              text,
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
                fontFamily: GoogleFonts.poppins().fontFamily,
              ),
            ),
    );
  }

  // Widget to build Google Sign-In Button
  Widget _buildGoogleSignInButton(bool isDarkMode) {
    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset('assets/images/google.webp', height: 32.0),
              const SizedBox(width: 13),
              Text(
                "Sign in with Google",
                style: TextStyle(
                  fontSize: 16,
                  color: isDarkMode ? Colors.grey.shade600 : Colors.white,
                  fontWeight: FontWeight.bold,
                  fontFamily: GoogleFonts.poppins().fontFamily,
                ),
              ),
            ],
          )
        ],
      ),
    );
  }

  // Function to handle forgot password action
  void _forgotPassword() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SecurityQuestionScreen(),
      ),
    );
  }

  // Function to validate email format
  bool isEmailValid(String email) {
    final emailRegex = RegExp(r'^[\w.-]+@([\w-]+\.)+[\w-]{2,4}$');
    return emailRegex.hasMatch(email);
  }

  // Function to check if the input is an email
  bool _isEmail(String input) {
    return isEmailValid(input);
  }

  // Function to handle sign-in process
  void _signIn() async {
    if (_validateFields()) {
      setState(() {
        _isSigning = true;
      });

      String usernameOrEmail = _usernameOrEmailController.text;
      String password = _passwordController.text;

      User? user;
      if (_isEmail(usernameOrEmail)) {
        user =
            await _auth.signInWithEmailAndPassword(usernameOrEmail, password);
      } else {
        final userQuery = await FirebaseFirestore.instance
            .collection('users')
            .where('username', isEqualTo: usernameOrEmail)
            .limit(1)
            .get();

        if (userQuery.docs.isNotEmpty) {
          final userData = userQuery.docs.first.data() as Map<String, dynamic>;
          final email = userData['email'] as String;
          final isGmail = userData['isGmail'] as bool;

          if (!isGmail) {
            try {
              user = await _auth.signInWithEmailAndPassword(email, password);
            } catch (e) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Error signing in. Please try again later.'),
                  backgroundColor: Colors.red,
                ),
              );
            }
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Incorrect Username'),
                backgroundColor: Colors.red,
              ),
            );
          }
        }
      }

      setState(() {
        _isSigning = false;
      });

      if (user != null) {
        String userId = user.uid;
        showToast(message: "User is successfully signed in");
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => HomeScreen(userId: userId)),
        );
      } else {
        print("Asd");
        showToast(message: "Invalid username or password");
      }
    }
  }

  // Function to validate form fields
  bool _validateFields() {
    String usernameOrEmail = _usernameOrEmailController.text;
    String password = _passwordController.text;

    if (usernameOrEmail.isEmpty) {
      showToast(message: "Please enter your username or email");
      return false;
    }

    if (password.isEmpty || password.length < 6) {
      showToast(message: "Password must be at least 6 characters long");
      return false;
    }

    return true;
  }

  // Function to handle Google Sign-In
  void _signInWithGoogle() async {
    final GoogleSignIn _googleSignIn = GoogleSignIn();

    try {
      await _googleSignIn.signOut();
      final GoogleSignInAccount? googleSignInAccount =
          await _googleSignIn.signIn();

      if (googleSignInAccount != null) {
        final GoogleSignInAuthentication googleSignInAuthentication =
            await googleSignInAccount.authentication;

        final AuthCredential credential = GoogleAuthProvider.credential(
          idToken: googleSignInAuthentication.idToken,
          accessToken: googleSignInAuthentication.accessToken,
        );

        final UserCredential userCredential =
            await FirebaseAuth.instance.signInWithCredential(credential);

        final String userId = userCredential.user!.uid;

        final String email = googleSignInAccount.email;
        final String username = email.split('@').first;

        FirebaseFirestore.instance.collection('users').doc(userId).set({
          'username': username,
          'email': email,
          'isGmail': true,
        });

        await _firebaseAuth.signInWithCredential(credential);
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => HomeScreen(userId: userId)),
        );
      }
    } catch (e) {
      showToast(message: "some error occured $e");
    }
  }
}


