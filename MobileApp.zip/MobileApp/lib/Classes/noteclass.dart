import 'package:cloud_firestore/cloud_firestore.dart';

class Note {
  String title;
  String content;

  Note({
    required this.title,
    required this.content,
  });

  int getWordCount(String content) {
    return content.isNotEmpty ? content.trim().split(RegExp(r'\s+')).length : 0;
  }

  factory Note.fromSnapshot(DocumentSnapshot snapshot) {
    return Note(
      title: snapshot['note_title'],
      content: snapshot['note_content'],
    );
  }

  factory Note.fromDocument(QueryDocumentSnapshot<Object?> doc) {
    return Note(
      title: doc['note_title'] as String,
      content: doc['note_content'] as String,
    );
  }

}
