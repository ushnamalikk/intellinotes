import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:myapp/screens/HomeScreen/homeScreenNotifier.dart';
import 'package:myapp/screens/HomeScreen/homeScreen.dart';
import 'package:myapp/screens/widgets/Dark Mode/dark_mode_provider.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';
import 'package:myapp/user_profiles/login.dart';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:permission_handler/permission_handler.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

Future<void> requestUserPermission() async {
  AwesomeNotifications().isNotificationAllowed().then((isAllowed) {
    if (!isAllowed) {
      showDialog(
        context: navigatorKey.currentContext!,
        builder: (context) => AlertDialog(
          title: Text('Allow Notifications'),
          content: Text('Our app would like to send you notifications'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Don\'t Allow'),
            ),
            TextButton(
              onPressed: () => AwesomeNotifications()
                  .requestPermissionToSendNotifications()
                  .then((_) => Navigator.pop(context)),
              child: Text('Allow'),
            ),
          ],
        ),
      );
    }
  });
}

Future<void> checkAndRequestPermission() async {
  if (await Permission.scheduleExactAlarm.isPermanentlyDenied) {
    openAppSettings();
  } else if (!await Permission.scheduleExactAlarm.isGranted) {
    await Permission.scheduleExactAlarm.request();
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  // await ImagePreloader.preloadImage(context, 'lib/icons/summarize.png');
  if (!await Permission.scheduleExactAlarm.isGranted) {
    openAppSettings();
  }
  AwesomeNotifications().initialize(
    null,
    [
      NotificationChannel(
        channelKey: 'basic_channel',
        channelName: 'Basic notifications',
        channelDescription: 'Notification channel for basic tests',
        importance: NotificationImportance.High,
        playSound: true,
      ),
    ],
    debug: true,
  );
  runApp(const MyAppWrapper());
}

class MyAppWrapper extends StatelessWidget {
  const MyAppWrapper({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    requestUserPermission(context);  // Calling within the build method ensures context is available
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => DarkModeProvider()),
        ChangeNotifierProvider(create: (_) => HomeScreenNotifier()),
      ],
      child: const MyApp(),
    );
  }

  Future<void> requestUserPermission(BuildContext context) async {
    AwesomeNotifications().isNotificationAllowed().then((isAllowed) {
      if (!isAllowed) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Allow Notifications'),
            content: const Text('Our app would like to send you notifications'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Don\'t Allow'),
              ),
              TextButton(
                onPressed: () => AwesomeNotifications()
                    .requestPermissionToSendNotifications()
                    .then((_) => Navigator.pop(context)),
                child: const Text('Allow'),
              ),
            ],
          ),
        );
      }
    });
  }
}


class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IntelliNotes',
      theme: ThemeData(
        primarySwatch: Colors.lightBlue,
        brightness: Brightness.dark, // Default brightness
      ),
      home: FutureBuilder(
        future: FirebaseAuth.instance.authStateChanges().first,
        builder: (context, AsyncSnapshot<User?> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(
                child: CircularProgressIndicator(),
              ),
            );
          } else if (snapshot.hasData && snapshot.data != null) {
            // User is signed in, navigate to HomeScreen
            return ChangeNotifierProvider(
              create: (_) => HomeScreenNotifier(), // Provide HomeScreenNotifier
              child: HomeScreen(userId: snapshot.data!.uid),
            );
          } else {
            // User is not signed in, navigate to LoginPage
            return const LoginPage();
          }
        },
      ),
    );
  }
}

